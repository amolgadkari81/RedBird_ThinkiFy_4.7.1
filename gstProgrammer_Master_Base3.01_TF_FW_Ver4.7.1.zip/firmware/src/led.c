//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    LED.c
//    LED and Motor control interface
//
//  Last Edit Date:  Sept  3 2017   JRL Updates for Rev B Board
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */
#include "system_config.h"
#include "app.h"
#include "led.h"
#include "globals.h"
/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */



void All_LEDS_OFF( void )
{
      LEDCopy = 0;
      MaintainFrontPanelLEDs();  
}


void All_LEDS_ON( void )
{
    LEDCopy = 0XFF;
    TestingLEDs = 30;              // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
    MaintainFrontPanelLEDs();  
}


void TwinkleLEDs( void )
{
    TestingLEDs = 30;              // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.

    SetFrontPanelLEDs(LED1,2);    // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED2,4);    // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED3,6);    // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED4,8);    // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED5,10);   // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED6,12);   // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED7,14);   // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
    SetFrontPanelLEDs(LED8,16);   // Send Which LED and a command On/Off/Time.   LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8.   0 = off, 255 = On, All else: Auto extinguish with 1-254 tenth second on time.
}