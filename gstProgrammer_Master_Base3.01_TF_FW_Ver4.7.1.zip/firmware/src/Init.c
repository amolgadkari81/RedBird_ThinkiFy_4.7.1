//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    Init.c
//    Initialization stuff.  
//
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include "system_definitions.h"
#include "app.h"
#include "globals.h"

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */
uint8_t __attribute__(( aligned(16) )) txData[] = { 0, 0 };
uint8_t __attribute__(( aligned(16) )) rxData[sizeof (txData )];
uint8_t txDataSize = sizeof (txData );

//int global_data;

//*****************************************************************************
//  Function:
//    void Wait_For_USB( void )
//
//  Remarks:
//    See prototype in app.h.
//*****************************************************************************
void INIT_BEFORE_USB(void)
{
uint8_t  level = 0;
uint8_t  i = 0;
uint16_t LoopCounter;
  
    
    //Set all PIC Pins to their desired power up state.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, ATT_LE, HIGH); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, BANNER_ENABLE, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, CAM_TRIG, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, CAM_TEACH, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, CAMERA_ENABLE, REGULATOR_ON); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, DA_CS, HIGH);                  
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, LED_DAT, LOW);                   
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, LED_RCLK, LOW); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, LED_SCLK, LOW); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, RFID_ENABLE, REGULATOR_ON);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TEMP_CS, HIGH);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP10, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP12, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP13, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP16, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP17, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP24, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP30, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP31, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP32, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP33, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP40, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP45, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP46, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP47, LOW);    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP48, LOW);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP52, LOW);        
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, LOW);         
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP72, LOW); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP73, LOW);        
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, TP79, LOW);         
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP81, LOW);         
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP82, LOW); 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP84, LOW);         
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP86, LOW); 
   
    level = 0;
    if(FRAMRead8(0) == 0xAA)  level++;    // First 4 Bytes contain specific numbers that are not likely to be there from hardware fault triggered unintended writes to Flash Memory.
    if(FRAMRead8(1) == 0x55)  level++;
    if(FRAMRead8(2) == 0xC3)  level++;
    if(FRAMRead8(3) == 0xE8)  level++;
    if(level != 4)                        // If the values in locations 0-3 are not as expected then stuff these factory defaults in the FRAM.
    {
        FRAMWrite8(0,0xAA);      // Evidence that the FRAM has been initialized.     pass in uint16_t Address and uint8_t WhatToWrite.
        FRAMWrite8(1,0x55);      // Evidence that the FRAM has been initialized.     These are just random unlikely numbers 
        FRAMWrite8(2,0xC3);      // Evidence that the FRAM has been initialized.     Change one of the values to cause the FRAM to be filled with a new default set
        FRAMWrite8(3,0xE8);      // Evidence that the FRAM has been initialized.
        FRAMWrite8(4,0x00);      // Mark Polarity.  0 Mark is enabled when asserted.   1 Mark is disabled when asserted.
        FRAMWrite8(5,0x00);      // Punch Polarity. 0 Punch is enabled when asserted.  1 Punch is disabled when asserted.    
        FRAMWrite8(6,0x00);      // MSB AnalogAttStart. 16 bit The D/A setting that selects the voltage at which the Analog Attenuator starts to respond.  
        FRAMWrite8(7,0x00);      // LSB                 Lower the voltage the highest output signal level.  Typically .7 Volts
        FRAMWrite8(8,0x00);      // MSB AnalogAttEnd.   16 bit The D/A setting that selects the voltage at which the Analog Attenuator stops responding.
        FRAMWrite8(9,0x00);      // LSB                 Lower the voltage the highest output signal level.  Typically 1.7 Volts
        FRAMWrite8(10,0xFE);     // SaLowRange;         Step attenuator setting for the low power range
        FRAMWrite8(11,0x23);     // SaMidRange;         Step attenuator setting for the mid power range
        FRAMWrite8(12,0x00);     // SaHiRange;          Step attenuator setting for the highest power range
        FRAMWrite8(13,0x00);     //                 
        FRAMWrite8(14,0x00);     //                 
        FRAMWrite8(15,0x00);     //                 
        FRAMWrite8(16,0x00);     //                 
        FRAMWrite8(17,0x00);     //                 
        FRAMWrite8(18,0x00);     //                 
        FRAMWrite8(19,0x00);     //                 
        FRAMWrite8(20,0x00);     //                 
    }       
    
    if ( FRAMRead8(4) ) // Address 4 is Mark Polarity.  
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, HIGH); // If 1 then Mark is disabled when asserted.  We enable the driver to disable the mark peripheral.
        BitfieldInversions |= 0x01;                                  // Bit 0  Mark, Bit 1 Punch.   0 No Invert, 1 = Invert
    }
    else // If 0 then Mark is Enabled when asserted.
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, LOW);  // We Disable the driver to disable the mark peripheral.
        BitfieldInversions &= 0xFE;                                  // Bit 0  Mark, Bit 1 Punch,   0 No Invert, 1 = Invert
    }
    
    if ( FRAMRead8(5) ) // Address 5 is Punch Polarity    
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, HIGH);
        BitfieldInversions |= 0x02;                                  // Bit 0  Mark, Bit 1 Punch,   0 No Invert, 1 = Invert
    }
    else
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, LOW);
        BitfieldInversions &= 0xFD;                                  // Bit 0  Mark, Bit 1 Punch,   0 No Invert, 1 = Invert
    }

    AnalogAttStart = FRAMRead8(6);          // 16 bit The D/A setting that selects the voltage at which the Analog Attenuator starts to respond.  Lower the voltage the highest output signal level.  Typically .7 Volts
    AnalogAttStart = AnalogAttStart << 8;   // Shift up to make room for the LSB
    AnalogAttStart += FRAMRead8(7);         // Add in the LSB    

    AnalogAttEnd = FRAMRead8(8);            // 16 bit The D/A setting that selects the voltage at which the Analog Attenuator stops responding.   Lower the voltage the highest output signal level.  Typically 1.7 Volts
    AnalogAttEnd = AnalogAttEnd << 8;
    AnalogAttEnd += FRAMRead8(9);           // Add in the LSB

    SaLowRange = FRAMRead8(10);             // Step attenuator setting for the low power range
    SaMidRange = FRAMRead8(11);             // Step attenuator setting for the mid power range
    SaHiRange  = FRAMRead8(12);             // Step attenuator setting for the high power range

    PlayPause = 0;        // 0 = pause.  1 = Play.    
    
    TestingLEDs = 2;      // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
    All_LEDS_OFF();       //Turn off all led's

    for ( LoopCounter = 0; LoopCounter < MAXSERBUF; LoopCounter++ ) // Start with empty buffers.
    {
        //Uart1RxBuf[LoopCounter] = 0; // Holds received characters from JADAK
        //Uart2RxBuf[LoopCounter] = 0; // Holds received characters from WiFi
        Uart3RxBuf[LoopCounter] = 0; // Holds received characters from RFID
        Uart4RxBuf[LoopCounter] = 0; // Holds received characters from Camera
        Uart5RxBuf[LoopCounter] = 0; // Holds received characters from Debug Port SP5 (J14))
        //Uart1TxBuf[LoopCounter] = 0; // Holds received characters from JADAK
        //Uart2TxBuf[LoopCounter] = 0; // Holds received characters from WiFi
        Uart3TxBuf[LoopCounter] = 0; // Holds received characters from RFID
        Uart4TxBuf[LoopCounter] = 0; // Holds received characters from Camera
        Uart5TxBuf[LoopCounter] = 0; // Holds received characters from Debug Port SP5 (J14))
    }

    //Uart1CRGot = 0;     // Bool True if we just received a CR on the Specified UART
    //Uart2CRGot = 0;     // Bool True if we just received a CR on the Specified UART
    Uart3CRGot = 0;     // Bool True if we just received a CR on the Specified UART
    Uart4CRGot = 0;     // Bool True if we just received a CR on the Specified UART
    Uart5CRGot = 0;     // Bool True if we just received a CR on the Specified UART

    //Uart1RXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    //Uart2RXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart3RXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart4RXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart5RXpointer = 0; // uint8_t Points to the next character location available to hold a new received character

    //Uart1TXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    //Uart2TXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart3TXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart4TXpointer = 0; // uint8_t Points to the next character location available to hold a new received character
    Uart5TXpointer = 0; // uint8_t Points to the next character location available to hold a new received character

    Uart5Headpointer = 0;         // Points to the next character location available to hold an incoming character
    Uart5Tailpointer = 0;         // Points to the next character that gets sent.
    
    AverageTemperature = 0;       // Holds an averaged temperature from the TC77 sensor.  Read once a second.

    MemoryUnlock = 0;             // Initialized to 0 upon power on reset.  Gets set upon button 1 when dip switch is set correctly.   If set, then the flash can be erased and written.

    LabelEncoderTics = 0;         // Global uint16_t Counts number of encoder tics since last new label detection.

    GetMAC();                     // Refresh the MacArray[] variable.

    // Command 0x1C encoder setups.
    EncoderStyle = 2;             // 0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
    EncoderEdgePolarity = 1;      // 0 = Detect Falling Edge.   1 = Detect Rising edge.
    EncoderTimerRollovers = 0;    // Global uint16_t Counts roll overs of the timer used to measure velocity.

    PendingHostEventNotice = 0;   // This holds an event notice that needs to be sent after the USB message that is currently being assembled is sent.

    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_3);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_3);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_3);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_3);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_2);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_2);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_2);    // Clear Banner Interrupt flag
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_2);    // Clear Banner Interrupt flag
   
    OldTestModeState = TESTMODEIDLE;       // Holds the mode that was active the last time thru the loop.  
    
    CalCounter = 0;        // Temp for Cal routine      
    SetRfAttDAC(0xFFFF);   // Send FFFF to cause the Power Up command to be sent
    SetRfAttDAC(0xFFFE);   // Send FFFE to cause the Select internal Reference command to be sent.

    Button1State = 0;      // 0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.
    Button2State = 0;      // 0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.
    SelfTestEnables = 0;   // for PCB self test stuff.   Tests are in the Fast and Slow test functions.

    LastRequestedRA = 99;  // if the currently needed RA is the same as this then we don't have to send it to the TR-65.
    
    DumpArray = 0;         // Temp CAL Debug use.
    TestingLEDs = 0;       // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.

        
    VersionMajor = 3;
    VersionMinor = 21; //AG
    VersionYear  = 20;
    VersionMonth = 3; // AG
    VersionDay   = 26; // AG
    
    // Ver3.21 Mar 22 2019 Amol G     Changed TR65TriggerLen to 9mS settling time for ThikiFy
    // Ver3.20 Mar 22 2019 Amol G     Added commands to support ThinkiFy FW version 4.7.1 and replaced all RO0 with RO1
    // Ver3.10 Jun 6  2019 Amol G     Added logic for EPC filter check (TAG ID filter command 0x1A)
    // Ver2.15 Mar 30 2019  J.Little   Slowed CAL a bit. Set power up defaults for 960MHz, +20dB Read power, EPC Read... Simple test.  Dip Switch = 0, Switch SW3 starts test, SW4 Stops test.   Set Encoder 50X times the speed of Banner.
    // Ver2.14 May 8  2018  J.Little   fixed position offset where punch and marker fired one label too late.
    // Ver2.13 May 7  2018  J.Little   Added support for tester position offset
    // Ver2.12 Apr 7  2018  J.Little   Fixed Punch bug.
    // Ver2.11 Apr 1  2018  J.Little   Double fails and multiple E3's after a failed label.
    // Ver2.10 Apr 1  2018  J.Little   Punch array cleanup.  Changed Name from GST Programmer to Redbird Reader.
    // Ver2.9  Mar 25 2018  J.Little   Fixed bug in calibration.
    // Ver2.8  Mar 21 2018  J.Little   Punch flight correction.   Dual punch flight compensation counters to support two consecutive failed labels.
    // Ver2.7  Mar 7  2018  J.Little   Fixed Web Velocity
    // Ver2.6  Feb 26 2018  J.Little   Added WEBVelocity as Self test H
    // Ver2.5  Feb 11 2018  J.Little   Changed from 0 to 5 for Min RA Calibration setting.  Changed TR-65 IQ0 to IQ1, P033 to P131
    // Ver2.4  Jan 30 2018  J.Little   Improved cal to increase accuracy.
    // Ver2.3  Jan  8 2018  J.Little   Slowed cal to increase accuracy.   Fixed Trigerfiltermax and trigerfiltermin use in 0x1D
    // Ver2.2  Dec 23 2017  J.Little   Added Calibration verification.   Merged Fixes/enhancements made in Greenville last week.
    // Ver2.1  Nov 21 2017  J.Little   Improved calibration accuracy.   
    // Ver2.0  Nov 12 2017  J.Little   Changes for rev B PCB.
    // Ver1.1  Jun 17 2017  J.Little   Fixed returns of 0x15 & 0x1D.  Fixed 0XE5 Over run problem when not testing.
    // Ver1.0  Aug  6 2016  B.Martin   Original release
    
  
}