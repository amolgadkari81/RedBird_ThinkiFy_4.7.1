//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    Miscellaneous.c
//    
//
//  Last Edit Date:  Sept  3 2017   JRL Updates for Rev B Board
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************

#include "system_config.h"
#include "led.h"

uint8_t reversebyte(uint8_t b)
{
   b = (b & 0xF0) >> 4 | (b & 0x0F) << 4;
   b = (b & 0xCC) >> 2 | (b & 0x33) << 2;
   b = (b & 0xAA) >> 1 | (b & 0x55) << 1;
   
   return b;
    
}


/* *****************************************************************************
 End of File
 */
