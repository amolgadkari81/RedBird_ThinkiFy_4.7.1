//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//  File Name:
//    Calibrate.c
//    all the Calibration functions  
//
//  Last Edit Date:  Oct   3 2016   JRL    Clean up after calibration debug.
//  Last Edit Date:  Sept 10 2016   JRL 
//  *****************************************************************************
//
// The Host PC program must add a function on their program to check if the freq and power level has a valid cal recipe each time they request it.
// Optionally, they could search the table upon power up and draw a Safe Operating Area chart for each tester. 
//
// The attenuators should have 65.35dB adjustment range.   We should be able to find recipies from -25dB up to +30dB.  
// Leakage thru the circulators prevents the entire 63dB range to about 30-40 db.
// Cycle thru all Digital to Analog converter values for the analog attenuator to find where the attenuator enters its linear range.   
// Save the values as:  AnalogAttStart and AnalogAttEnd.   
// These are the min and max values to which the Analog attenuator will ever be set.
// Programmer is in the Temp chamber set to ambient temperature (Lid open).  
// The first step in Calibration is to adjust the power levels using the resistive PADS on the RF PCB so that we have at least +31dB at the output connector.
// with minimum variable attenuation at room temperature across all frequencies.  Optimum +31dB to 35dB.
// The TR-65 power level change over a 33C temperature range with RA=0.   22C 16.43dB, 55C 16.19dB for a  .24dB decrease
// The TR-65 power level change over a 33C temperature range with RA=16.  22C  6.10dB, 55C  4.68dB for a 1.42dB decrease
// Use serial command CA to determine start and end DA values for the Analog Attenuator.
// For each temperature...
// Calibrate from the lowest power to the highest power.   The CAL table in FLASH Memory will have the lower power levels first.
// Calibrate in two steps.  -25 to +10dB with no attenuator on the power head.  Then from +10 to +30dB with a 30dB attenuator on the power head.
// We start with the Analog attenuator set to AnalogAttStart and Step attenuator set to 96. This should be the lowest RF output power available.
// Setting the Step attenuator for more attenuation doesn't lower the min power, it just limits the upper end.
// We then measure each RF frequency to be calibrated.   Lowest frequency to the highest frequency.
// Seek all power levels from -25 to +10dB using the Analog attenuator. These values are saved in a CAL table.
// if the minimum power is already exceeded with Analog attenuator set at max attenuaton then just save the Attenuator settings, FAD, RAD, and the CAL error.
// If power is too low then decrement the attenuation one step at a timeuntil the target power level is passed.  Save the Attenuator settings, FAD, RAD, and the CAL error.   
// Repeat until power is calibrated up to +10dB in .1dB steps.
// Add 30dB attenuator, Set RA to 0, SA to 0, and seek power levels +10 to +30dB.
// increment temperature and get next set of calibration recipes.
// 
// To use CAL table.
// Find the closest matching temperature. Find the closest frequency. calculate Address offsets.  Get RA, SA, and AA.   
//
// There are 550 power levels and 51 frequencies.  There are 16 Bytes saved per CAL record.  This means we need 448,800 (0x06D920) bytes per temperature.
// Temperature 0 is saved at offset 0, Temperature 1 has a 0x100000 offset, Temperature 2 has a 0x200000 offset, Temperature 3 has a 0x300000 offset.
// To find address:
// (Temp * 0x10000) + (Frequency * 0x4000 ) + (Power * 0x10) = Physical FLASH Address for the cal record.
// This wastes memory between each segment, but the calculations are easy.

// ************************************************************************** 
// ************************************************************************** 
// Section: Included Files                                                    
// ************************************************************************** 
// ************************************************************************** 
#include "system_config.h"
//#include <stdint.h>
//#include <stdbool.h>
//#include <stddef.h>
//#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "peripheral/usart/plib_usart.h"
//#include "peripheral/devcon/plib_devcon.h"
//#include "system/debug/sys_debug.h"

// ************************************************************************** 
// ************************************************************************** 
// Section: Global Data                                        
// ************************************************************************** 
// ************************************************************************** 

uint8_t  FindFreqElement(uint32_t);          // returns the ID number of the CaldFreq (Calibrated Frequencies) table element that is closest to the (uint32) requested frequency.
void     CalibrateRFID(uint8_t);             // Pass in 0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
void     SaveCalRecordtoFlash(uint32_t,uint8_t,uint8_t,uint16_t,uint16_t,uint16_t,uint16_t); // Write CAL record to Flash.  Pass in FlashAddress,SA,RA,AA,FAD,RAD,PwrErr); 
void     GetCalRecordFromFlash(uint32_t);    // Get a CAL record from Flash.  Pass in a structure that contains an address and we will fill in the missing info.

// These are used to determine which element of the cal table is used for any frequency that might be requested by user
// Calibrated Frequencies Table.  This is the list of frequencies that are calibrated.
const uint32_t CaldFreqs[51] = {
860000000,
862000000,864000000,866000000,868000000,870000000,
872000000,874000000,876000000,878000000,880000000,
882000000,884000000,886000000,888000000,890000000,
892000000,894000000,896000000,898000000,900000000,
902000000,904000000,906000000,908000000,910000000,
912000000,914000000,916000000,918000000,920000000,
922000000,924000000,926000000,928000000,930000000,
932000000,934000000,936000000,938000000,940000000,
942000000,944000000,946000000,948000000,950000000,
952000000,954000000,956000000,958000000,960000000
};



/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

uint8_t FindFreqElement(uint32_t ReqFreq)    // returns number of the CalcFreq table element that is closest to the requested frequency.
{
static uint32_t SearchFreq;                  // Temporary storage
static uint8_t  LoopCounter;

    SearchFreq = ReqFreq;

    if(SearchFreq < CaldFreqs[0])
    {    
        Send0XE5EventNoticeToHost(0x08);     // Send USB Event Notice to HOST.  Requested frequency is lower than any calibrated frequency.
        return(0);                           // The first element is the best.
    } 
    
    if(SearchFreq == CaldFreqs[0])
        return(0);                           // The first element is the best.
    
    for(LoopCounter = 1 ; LoopCounter < 51 ; LoopCounter++)     // Start at the second freq since we tested the first one already.
    {
        if(SearchFreq == CaldFreqs[LoopCounter])                // Have we found the search freq.
            return(LoopCounter);

        if(SearchFreq < CaldFreqs[LoopCounter])                 // Have we passed the search freq.
        {
            if( ( CaldFreqs[LoopCounter] - SearchFreq ) < (SearchFreq - CaldFreqs[LoopCounter-1]) )
                return(LoopCounter);                          // The current freq being tested is the best.
            else
                return(LoopCounter-1);                          // The current freq being tested is the best.                
        }
    }
    
    Send0XE5EventNoticeToHost(0x08);     // Send USB Event Notice to HOST.  Requested frequency is higher than any calibrated frequency.
    return(51);    
}


// CALTABLE is stored in a FLASH Memory IC that has 256 Byte pages.  Auto incrementing type writes and Reads can not cross the 256 byte page boundries.
// There are 16 bytes per record.  Therefore 16 records fit evenly in the 256 byte page.  
// As long as we don't write more than one record at a time then we don't have to worry about the page size.
//
// CALTABLE has 551 entries per Frequency per temperature; Enough space for all power levels from +30dB to -25dB in tenth dB steps.  We store the LOWEST power first.
// There are 51 2 MHz channels between (and including) 860 and 960 MHz.  We store the lowest frequency first
// We calibrate at 4 temperatures.  we store the lowest temperature first.
// The RA, AA, and SA data in the CAL table can be thought of as a recipe to request the desired power level.
// Each CAL entry contains 8 Bit SA, 8 bit RA, 16 Bit AA, 16 Bit FAD, 16 bit RAD, 16 Bit Power Error.    We use 16 Bytes per record to keep things on even page boundries.
// There are 551 power levels per frequency.     551 * 8       =   4,408 Bytes for all of the power levels in one frequency
// there are 50 frequencies per temperature      50  * 4408    = 220,400 Bytes per temperature range  (0x035CF0 bytes)
// there are 4 temperatures per set.             4   * 220,400 = 881,600 Bytes per table.
//
// Temp 0 - 3.    Corresponding to <25, 25-29, 30-35, >35 degrees C.
// Freq 0 - 50    860MHz + n * 2MHz.    0 = 860, 1 = 862, 2 = 864, 3 = 866, 4 = 868, 5 = 870MHz... 51 = 960
// Pwr  0 - 551   -25dB to +30dB in 1/10 dB Steps.  0 = -25dB, 1 = -24.9dB, 2 = -24.8dB...
//
// There are 220,400 values for each temperature.
// 
// We add a small buffer between sections to ensure that the pages start at the precise start of each page so the page boundries are not crossed when accessing 16 bit variables.
// 
// Frequencies  start on 16384   ( 0x004000 ) byte boundries.   Freq  0 starts at offset 0,   Freq 1 starts at 16384,   Freq 2 starts at  32768.  Freq 50 starts at  819200.(0xC8000)
// Temperatures start on 1048576 ( 0x100000 ) byte boundries.   Temp  0 starts at offset 0,   Temp 1 starts at 0x100000, Temp 2 starts at 0x200000, Temp 3 starts at 0x300000.  Last used address is 0x3FFFFF.
// 
// To find the address of a CAL record.
// (Temp * 0x10000) + (Frequency * 0x4000 ) + (Power * 0x10) = Physical FLASH Address for the cal record.
//
// Which temperature (0 through 3) * 0x10000.   Temperatures are <25, 25-29, 30-35, >35 degrees C.
// 
// Which Frequency (0 thru 49) * 0x4000.        Frequencies are: 86000,86200,86400,86600,86800,......up to 96000
//
// Which Power Level.
// Find offset into the table for the power level:
// We offset by 100 to keep all values positive
// multiply by 100 to make all values integer values.
// For example:
// to find the correct index for a requested pwr level of 12.2 dB
// ReqPwr +=100                        // Add 100 to keep all power levels positive
// ReqPwr = 112.2                      // Result
// ReqPwr *=10                         // Mult by 10 to make integer
// ReqPwr = 1122                       // Result
// temp = 1122 - 750                   // Add search from the first element to find difference.  7500 comes from -25dB + 100dB * 10
// temp = 372                          // Result  372 records from the start of the table.
// PowerOffset = temp * 16             // Mult by 16 because there's 16 Bytes in each record.  This results in the number of bytes between the start of the desired record and the first record of the section.
// Power offset = 5952 Bytes           // Result
//
// for example:    26 degrees C, 864000 MHz, +5.2dB
// Temperature offset = 1   * 65536  =     65536
// Frequency offset   = 2   * 16384   =    32768
// Power offset       = 302 * 16      =     4832
//                     Flash Address =    103135 (Sum) (Start of the 16 byte record)
//
// Flash Memory map   16M x 8 Flash Memory.  0x000000 - 0xFFFFFF 
// One recipe for each of the 551 power levels of each of the 51 Frequencies.  28,101 records of 8 bytes each ,or 224,808 bytes per temperature  
//
// 0X000000 Offset or Start of Temp 0 recepies.  
// 0X010000 Offset or Start of Temp 1 recepies. 
// 0X020000 Offset or Start of Temp 2 recepies. 
// 0X030000 Offset or Start of Temp 3 recepies. 
//
// 0X000000 SA     8 Bit Step attenuator   Temp 0, Freq 0, Power Level 0      (0 X 0x100000 ) + (0 X 0x4000) + (0 X 16)
// 0X000001 RA     8 Bit TR-65 attenuator   
// 0X000002 AA    16 Bit Analog attenuator
// 0X000004 FAD   16 Bit Forward Power Level
// 0X000006 RAD   16 Bit Reverse Power Level
// 0X000008 ERROR 16 Bit Cal error
// 0X00000A Unused 8 Bit
// 0X00000B Unused 8 Bit
// 0X00000C Unused 8 Bit
// 0X00000D Unused 8 Bit
// 0X00000E Unused 8 Bit
// 0X00000F Unused 8 Bit
// 0X000010 SA     8 Bit Step attenuator   Temp 0, Freq 0, Power Level 1      (0 X 0x100000 ) + (0 X 0x4000) + (1 X 16)
// 0X000011 RA     8 Bit TR-65 attenuator   
// 0X000012 AA    16 Bit Analog attenuator
// 0X000014 FAD   16 Bit Forward Power Level
// 0X000016 RAD   16 Bit Reverse Power Level
// 0X000018 ERROR 16 Bit Cal error
// 0X00001A Unused 8 Bit
// 0X00001B Unused 8 Bit
// 0X00001C Unused 8 Bit
// 0X00001D Unused 8 Bit
// 0X00001E Unused 8 Bit
// 0X00001F Unused 8 Bit

// Power Levels.
// -25.0dB = power level 0.   Power meter value = 750
// -24.9dB = power level 1.   Power meter value = 751
// -24.0dB = power level 10.  Power meter value = 760
// -10.0dB = power level 150. Power meter value = 900
//   0.0dB = power level 250. Power meter value = 1000
// +10.0dB = power level 350. Power meter value = 1100
// +20.0dB = power level 450. Power meter value = 1200
// +30.0dB = power level 550. Power meter value = 1300
// +30.5dB = power level 555. Power meter value = 1305




// *************************************************************************************************************************************************************************************
// Nudge style.  Continually called from main loop when calibrate is active.  
// CalPacer is 16 bits with one millisecond resolution.  It can be used to permit multi second delays between events.
// The linear range of the Analog Attenuator has already been determined.
// This function depends on the unit being at the specified stable temperature when it gets triggered.
// Global variable uint16_t LatestPwrReading: Continually refreshed by USB.  Power meter value sent in hundreths with 100dB offset.  +12.55dB sent as 11255.   -12.22 dB sent as 8778.
// Global variable CurrentCALChannel uint8 is continually updated to provide feedback to the host PC.
// Start with Lower power levels and step up to the higher power levels. 
//
void CalibrateRFID(uint8_t Command)           // Pass in 0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
{
static uint8_t   OldRASetting;                // Which RA Power level was sent last time.
static uint8_t   FLooper;                     // Frequency loop
static uint16_t  PLooper;                     // Power loop
//static uint16_t  CurrentAASetting;             // Which AA Power level is being used.
//static uint8_t   RunState;                     // Where we are in the process.
//static uint16_t  PwrError;
//static uint8_t   Counter = 0;

//ControlTP(49,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    if(Command == 0)                          // CalMode Controls CAL progress.   0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
        return;
        
    if(Command == 1)                          // Reset and restart calibration on the -25 to 0dB range.
    {
        ;
    }

    if(Command == 3)                          // Reset and restart calibration on the -15dB to +30dB range.
    {
        CurrentCALChannel = 0;                // Which Frequency is being Measured.  0..50
        CurrentCalTemperatureSet = CurrentTemperatureNum;         // Capture at the start of CAL.  Holds which temperature range is being calibrated.  0 = < 25.0.  1 = 25.0 to 29.9.  2 = 30.0 to 35.0.  3 = > 35.0
        CurrentRASetting = 19;                // Save it for the CAL table.
        sprintf(Uart3TxBuf,"RA%u\r\n",CurrentRASetting);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);    // set TR-65 attenuator
        PMPacer = 200;                        // Set delay for the TR-65 to process 
        DebugOut( sprintf(Uart5TxBuf, "-15dB to +30dB RF Cal Started. 15dB Attenuator needed. Temperature Range %d\r\n",CurrentCalTemperatureSet) );
        DebugOut( sprintf(Uart5TxBuf, "#,Freq,Addr,Pwr,SA,RA,AA,FAD,RAD,Err\n\r"));
        RunState = 0;                         // We will first Tune and set power level
        //LPRDumpArray[10];     // used in CAL routine to dump a high speed capture.
        DumpArray = 0;          // used in CAL routine to dump a high speed capture.
        NumSamples = 0;         // used in CAL routine to dump a high speed capture.
    }

    if(Command == 4)                                  // Run the calibration for the -15dB to +30dB range.
    {
        switch(RunState)
        {
            case 0:                                   // set new frequency.
                sprintf(Uart3TxBuf,"RF%lu\r\n",( CaldFreqs[CurrentCALChannel] / 10000));  ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
                CurrentAASetting = AnalogAttStart;    // Set for MAX attenuation.
                SetRfAttDAC(CurrentAASetting);        // Which AA Power level is being used.
                CurrentSASetting = SaHiRange;         // Ver2.9 Set to Max Attenuation as determined with the SSA command and the ST1 commands
                SetStepAttenuator(CurrentSASetting);  // Set the Step Attenuator.
                CurrentPowerSought = 850;             // (-15dB) Which power level are we searching for:  750 - 1300 corresponds to -25dB to +30dB.  In tenths with + 100dB offset. 750 = -25.0dB.  891 = -10.9dB.  1220 is +22.0dB
                PMPacer = 225;                        // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                RunState = 1;                         // next time we set RA power.
            break;

            case 1:                                   // set RA Attenuator
                sprintf(Uart3TxBuf,"RO3\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
                FailTimeout = 0;         // Used when waiting on a peripheral that might fail. prevents waiting forever.
                PMPacer = 500;           // Send and then let power meter settle.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                RunState = 2;            // zero the power meter counter
            break;

            case 2:                      // zero the counter so we know when we have new power reading.
                UpdatePowerMeter(1);     // Send Temperature and Frequency to power meter.
                PMPacer = 0;             // Decremented in the 1mS ISR -AND- the power meter USB parser 
                RunState = 3;            // next time wait for the power meters sample and save it.
            break;

            // LatestPwrReading.   Power in HUNDRETHS from power sensor. Sent with + 100dB offset.   Sent in units and two place decimal.   8910 = -10.90dB.  12200 is +22.00dB
            // CurrentPowerSought. Power in TENTHS.
            
            case 3:                                                          // Seek values on the lower side of the High range.
                if(NewPowerMeterValueAvailable)                              // Incremented when a new power meter value is received from the Host via USB.
                {
                    NewPowerMeterValueAvailable = 0; 
                    FailTimeout = 0;                                         // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    if( LatestPwrReading > (CurrentPowerSought * 10) )       // If we are higher in power than our target then save the recipe to the CAL table.
                    {
                        FlashAddress =( (CurrentCalTemperatureSet * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );
                        
                        CurrentFAD  = GetAD(0);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentFAD += GetAD(0); 
                        CurrentFAD = CurrentFAD / 16;                        // Some Filtering

                        CurrentRAD  = GetAD(1);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentRAD += GetAD(1); 
                        CurrentRAD = CurrentRAD / 16;                        // Some Filtering
                        
                        if(LatestPwrReading >  (CurrentPowerSought * 10) )   // Calculate the power error.
                            PwrError = (LatestPwrReading - (CurrentPowerSought * 10) );
                        else
                            PwrError = ( (CurrentPowerSought * 10) - LatestPwrReading);

                        if(PwrError>250)
                            PwrError = 250;
                        
                        SaveCalRecordtoFlash(FlashAddress, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError);     // Write CAL record to Flash.  Addr, SA, RA, AA, FAD, RAD, Err.
                        //DebugOut( sprintf(Uart5TxBuf, "3 Freq:%lu Addr:%lX Pwr:%lu SA:%u RA:%u AA:%lu FAD:%lu RAD:%lu Err:%lu \n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));
                        DebugOut( sprintf(Uart5TxBuf, "3,%lu,%lX,%lu,%u,%u,%lu,%lu,%lu,%lu\n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));

                        CurrentPowerSought++;                     // Increment CurrentPowerSought by one tenth dB.
                        if(CurrentPowerSought > 1300)             // 1300 corresponds to 30.0dB  If we get here then there's an error. We should have run out of Analog Attenuator by now.
                        {
                            DebugOut( sprintf(Uart5TxBuf, "CAL ERROR  Excessive power detected. C4 Runstate = %d CPS %ld LPR %ld \r\n",RunState,CurrentPowerSought,LatestPwrReading) );
                            RunState = 8;                         // Dump out 
                        }
                        
                        CurrentAASetting += 4;                    // The smaller the increment the more precise the calibration.  Increment setting to reduce attenuation and increase power.
                        SetRfAttDAC(CurrentAASetting);            // Which AA Power level is being used.                        
                        PMPacer = 225;                            // Decremented in the 1mS ISR. Guarantee a new power meter measurement
                        RunState = 2;                             // next time wait for the power meter delay then trigger a new measurement.
                    }
                    else                                          // Still looking for the correct power level.
                    {
                        CurrentAASetting += 4;                    // The smaller the increment the more precise the calibration.  Increment setting to reduce attenuation and increase power.
                        
                        if(CurrentAASetting > AnalogAttEnd)       // If we are already at the end of the analog attenuator.
                        {
                            CurrentAASetting = AnalogAttStart;    // Set back to the beginning for MAX attenuation.
                            SetRfAttDAC(CurrentAASetting);        // Which AA Power level is being used.
                            CurrentSASetting = SaMidRange;        // increase to the best value of attenuation determined with the SSA command and the ST1 commands
                            SetStepAttenuator(CurrentSASetting);  // Set the Step Attenuator.
                            PMPacer = 225;                        // Decremented in the 1mS ISR. give power meter time to settle after abrupt power change.
                            RunState = 4;                         // Seek values on the higher side of the high range.
                        }  
                        else
                        {
                            SetRfAttDAC(CurrentAASetting);        // Which AA Power level is being used.
                            PMPacer = 225;                        // Decremented in the 1mS ISR. Guarantee a delay between power meter transactions
                            RunState = 2;                         // next time wait for the power meter delay then trigger a new measurement.
                        }
                    }        
                }
                else
                {
                    FailTimeout++;
                    if(FailTimeout > 500)          // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    { 
                        DebugOut( sprintf(Uart5TxBuf, "Power Meter Timeout - C4 Runstate = %d \r\n",RunState));
                        RunState = 8;              // Dump out and go idle
                    }   
                    else
                    {
                        PMPacer = 225;             // try again in a few milliseconds.
                        RunState = 2;              // Trigger the power meter again. 
                    } 
                }
            break;

            case 4:                      // zero the counter so we know when we have new power reading.
                //UpdatePowerMeter(1);   // Send Temperature and Frequency to power meter.
                PMPacer = 0;             // Decremented in the 1mS ISR -AND- the power meter USB parser 
                RunState = 5;            // next time wait for the power meters sample and process it.
                //NewPowerMeterValueAvailable = 0; 
            break;
            
            case 5:                      // Seek values on the higher side of the high range.
                
                if(NewPowerMeterValueAvailable < 9)
                    LPRDumpArray[NewPowerMeterValueAvailable] = LatestPwrReading;    // Save all the values
                
                if(NewPowerMeterValueAvailable == 1)            // Let the power meter stabelize 
                    AveragePwrReading = LatestPwrReading;       // then reset the averaging.
                
                if(NewPowerMeterValueAvailable > 4)             // Incremented when a new power meter value is received from the Host via USB.
                {
                   
                    if(DumpArray)
                    {
                        DumpArray = 0;
                        DebugOut( sprintf(Uart5TxBuf, "%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu\n\r",LPRDumpArray[0],LPRDumpArray[1],LPRDumpArray[2],LPRDumpArray[3],LPRDumpArray[4],LPRDumpArray[5],LPRDumpArray[6],LPRDumpArray[7],LPRDumpArray[8],LPRDumpArray[9],AveragePwrReading));
                        LPRDumpArray[0] = LPRDumpArray[1] = LPRDumpArray[2] = LPRDumpArray[3] = LPRDumpArray[4] = LPRDumpArray[5] = LPRDumpArray[6] = LPRDumpArray[7] = LPRDumpArray[8] = LPRDumpArray[9] = 0;
                    }
                    
                    FailTimeout = 0;                                         // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    NewPowerMeterValueAvailable = 0; 
                    if( AveragePwrReading > (CurrentPowerSought * 10) )      // If we are higher in power than our target the we found the next setting.
                    {                                                        // Save whole set to CAL table. 
                        FlashAddress =( (CurrentCalTemperatureSet * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );

                        CurrentFAD  = GetAD(0);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentFAD += GetAD(0); 
                        CurrentFAD = CurrentFAD / 16;                        // Some Filtering

                        CurrentRAD  = GetAD(1);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentRAD += GetAD(1); 
                        CurrentRAD = CurrentRAD / 16;                        // Some Filtering
                        
                        if(AveragePwrReading > (CurrentPowerSought * 10) )   // Calculate the power error.
                            PwrError = (AveragePwrReading -  (CurrentPowerSought * 10) );
                        else
                            PwrError = ( (CurrentPowerSought * 10) - AveragePwrReading);

                        SaveCalRecordtoFlash(FlashAddress, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError);     // Write CAL record to Flash.  Addr, SA, RA, AA, FAD, RAD, Err.
                        //DebugOut( sprintf(Uart5TxBuf, "5 Freq:%lu Addr:%lX Pwr:%lu SA:%u RA:%u AA:%lu FAD:%lu RAD:%lu Err:%lu \n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));
                        DebugOut( sprintf(Uart5TxBuf, "5,%lu,%lX,%lu,%u,%u,%lu,%lu,%lu,%lu\n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));
                       
                        CurrentPowerSought++;                     // Get ready to look for the next power level.   

                        if(CurrentPowerSought > 1300)             // we should have run out of Analog Attenuator range by now.
                        {
                            DebugOut( sprintf(Uart5TxBuf, "CAL ERROR  Excessive power detected. C4 Runstate = %d \r\n",RunState) );
                            RunState = 8;                         // Dump out 
                        }
                        
                        CurrentAASetting += 4;                    // Increment setting to reduce attenuation and increase power.
                        SetRfAttDAC(CurrentAASetting);            // Set the attenuator to the AA Power level that is being used.
                        PMPacer = 225;                            // Decremented in the 1mS ISR. Guarantee a 50mS delay between power meter transactions
                        RunState = 4;                             // Seek values on the higher side of the high range.
                    }
                    else                                          // Still looking for the correct power level.
                    {
                        CurrentAASetting += 4;                    // Increment setting to reduce attenuation and increase power.

                        if(CurrentAASetting > AnalogAttEnd)       // If we are at the end of the analog attenuator then go to next range.
                        {      
                            CurrentAASetting = AnalogAttStart;    // Set back to the beginning for MAX attenuation.
                            SetRfAttDAC(CurrentAASetting);        // Which AA Power level is being used.
                            CurrentSASetting = SaLowRange;        // Ver2.9 Decrease Step attenuator to increase power;
                            SetStepAttenuator(CurrentSASetting);  // Set the Step Attenuator.
                            CurrentRASetting = 5;                 // Save it for the CAL table.
                            sprintf(Uart3TxBuf,"RA%u\r\n",CurrentRASetting);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);    // set TR-65 attenuator To min PERMITTED value
                            PMPacer = 500;                        // Decremented in the 1mS ISR. Give the TR-65 time to switch and settle.
                            RunState = 6;                         // Seek values on the highest side of the high range.
                        }   
                        else
                        {
                            SetRfAttDAC(CurrentAASetting);        // Set the attenuator to the AA Power level that is being used.  
                            PMPacer = 225;                        // Decremented in the 1mS ISR. Guarantee a few delay between power meter transactions
                            RunState = 4;                         // Seek values on the highest side of the high range.
                        }
                    }        
                }
                else
                {
                    FailTimeout++;
                    if(FailTimeout > 50000)          // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    { 
                        DebugOut( sprintf(Uart5TxBuf, "Power Meter Timeout - C4 Runstate = %d \r\n",RunState));
                        RunState = 8;                // Dump out and go idle
                    }   
                    else
                    {
                        PMPacer = 225;               // try again in a few milliseconds.
                        RunState = 4;                // Trigger the power meter again. 
                    }  
                }
            break;
            
            case 6:   
                UpdatePowerMeter(1);     // Send Temperature and Frequency to power meter.
                PMPacer = 0;             // Decremented in the 1mS ISR -AND- the power meter USB parser 
                RunState = 7;            // next time wait for the power meters sample and process it.
            break;
            
            case 7:                                             // Seek values on the higher side of the high range.
               
                if(NewPowerMeterValueAvailable < 9)
                    LPRDumpArray[NewPowerMeterValueAvailable] = LatestPwrReading;    // Save all the values
                
                if(NewPowerMeterValueAvailable == 1)            // Let the power meter stabelize 
                    AveragePwrReading = LatestPwrReading;       // then reset the averaging.
                
                if(NewPowerMeterValueAvailable > 4)             // Incremented when a new power meter value is received from the Host via USB.
                {

                    if(DumpArray)
                    {
                        DumpArray = 0;
                        DebugOut( sprintf(Uart5TxBuf, "%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu\n\r",LPRDumpArray[0],LPRDumpArray[1],LPRDumpArray[2],LPRDumpArray[3],LPRDumpArray[4],LPRDumpArray[5],LPRDumpArray[6],LPRDumpArray[7],LPRDumpArray[8],LPRDumpArray[9],AveragePwrReading));
                        LPRDumpArray[0] = LPRDumpArray[1] = LPRDumpArray[2] = LPRDumpArray[3] = LPRDumpArray[4] = LPRDumpArray[5] = LPRDumpArray[6] = LPRDumpArray[7] = LPRDumpArray[8] = LPRDumpArray[9] = 0;
                    }
                    
                    FailTimeout = 0;                          // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    NewPowerMeterValueAvailable = 0;          // zero the counter so we know when we have new power reading. 
                    if( ( AveragePwrReading > (CurrentPowerSought * 10) ) || (CurrentAASetting == AnalogAttEnd) )   // If we are higher in power than our target then we found the next setting.
                    {                                                                                              // or we are already at max power.   Save whole set to CAL table.  
                        FlashAddress =( (CurrentCalTemperatureSet * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );

                        CurrentFAD  = GetAD(0);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentFAD += GetAD(0); 
                        CurrentFAD = CurrentFAD / 16;                        // Some Filtering

                        CurrentRAD  = GetAD(1);                              // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                            CurrentRAD += GetAD(1); 
                        CurrentRAD = CurrentRAD / 16;                        // Some Filtering
                        
                        if(AveragePwrReading > (CurrentPowerSought * 10) )   // Calculate the power error.
                            PwrError = (AveragePwrReading -  (CurrentPowerSought * 10) );
                        else
                            PwrError = ( (CurrentPowerSought * 10) - AveragePwrReading);

                        SaveCalRecordtoFlash(FlashAddress, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError);     // Write CAL record to Flash.  Addr, SA, RA, AA, FAD, RAD, Err.
                        //DebugOut( sprintf(Uart5TxBuf, "7 Freq:%lu Addr:%lX Pwr:%lu SA:%u RA:%u AA:%lu FAD:%lu RAD:%lu Err:%lu \n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));
                        DebugOut( sprintf(Uart5TxBuf, "7,%lu,%lX,%lu,%u,%u,%lu,%lu,%lu,%lu\n\r",CaldFreqs[CurrentCALChannel]/10000, FlashAddress, CurrentPowerSought, CurrentSASetting, CurrentRASetting , CurrentAASetting, CurrentFAD, CurrentRAD, PwrError));
                       
                        CurrentPowerSought++;                         // get ready to look for the next power level.                        
                        if(CurrentPowerSought > 1300)                 // 1300 corresponds to 30.0dB  If we get here then we are done with this frequency.
                        {
                            CurrentCALChannel++;                      // Try for the next Frequency.
                            if(CurrentCALChannel > 50)
                            {
                                DebugOut( sprintf(Uart5TxBuf, "Calibration for current temperature range complete.\r\n\r\n"));   // All done, all saved.
                                sprintf(Uart3TxBuf,"RO0\r\n"); ReverseString(Uart3TxBuf);   Uart3TXpointer = strlen(Uart3TxBuf);
                                TestModeState = TESTMODEIDLE;         // Do Nothing.
                                RunState = 0;                         // go to idle mode
                                return;                            
                            }
                            else                                      // Set up for the next frequency
                            {
                                CurrentRASetting = 19;                // Save it for the CAL table.
                                sprintf(Uart3TxBuf,"RA%u\r\n",CurrentRASetting);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);    // set TR-65 attenuator
                                PMPacer = 225;                        // Decremented in the 1mS ISR. 
                                RunState = 0;                         // We will first Tune and set TR-65 power level
                            }
                        }
                        else
                        {
                            CurrentAASetting += 4;                    // Increment setting to reduce attenuation and increase power.
                            if(CurrentAASetting > AnalogAttEnd)       // If we are at the end of the analog attenuator then we are at max power.
                                CurrentAASetting = AnalogAttEnd;                            
                            PMPacer = 225;                            // Needed only to give the serial port message message time to transmit.
                            NewPowerMeterValueAvailable = 1;          // Fake out the power meter new value test.
                            RunState = 7;                             // Stay in this mode.
                        }
                    }
                    else                                          // Still looking for the correct power level.
                    {
                        CurrentAASetting += 4;                    // Increment setting to reduce attenuation and increase power.
                       
                        if(CurrentAASetting > AnalogAttEnd)       // If we are at the end of the analog attenuator then we are at the max power already.
                        {      
                            CurrentAASetting = AnalogAttEnd;      // Freeze at the max since the other attenuators are already set for max power.
                            PMPacer = 225;                        // Needed only to give the serial port message message time to transmit.
                            NewPowerMeterValueAvailable = 1;      // Fake out the power meter new value test.
                            RunState = 7;                         // Stay in this mode.
                        }   
                        else
                        {
                            SetRfAttDAC(CurrentAASetting);        // Which AA Power level is being used.
                            PMPacer = 225;                        // Needed only to give the serial port message message time to transmit.
                            RunState = 6;                         // Seek values on the highest side of the high range.                            
                        }
                    }        
                }
                else
                {
                    FailTimeout++;
                    if(FailTimeout > 50000)          // Used when waiting on a peripheral that might fail. prevents waiting forever.
                    { 
                        DebugOut( sprintf(Uart5TxBuf, "Power Meter Timeout - C4 Runstate = %d \r\n",RunState));
                        RunState = 8;                // go to idle mode
                    }   
                    else
                    {
                        PMPacer = 225;               // try again in a few milliseconds.
                        RunState = 6;                // Trigger the power meter again. 
                    }
                }
            break;            

            case 8:                     // Shutdown and bail out.
                sprintf(Uart3TxBuf,"RO0\r\n"); ReverseString(Uart3TxBuf);   Uart3TXpointer = strlen(Uart3TxBuf);   // Kill power to RFID
                TestModeState = TESTMODEIDLE;        // Do Nothing.
                RunState = 0;                        // go to idle mode
                return;  
            break;
        }        
    }

    if(Command == 8)                          // Command Controls CAL progress.   0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
    {
        DebugOut( sprintf(Uart5TxBuf, "Start Verification at the current temperature.\r\n\r\n"));
        DebugOut( sprintf(Uart5TxBuf, "Freq,Pwr,CFAD,CRAD,CErr,VFAD,VRAD,VErr,VPwr,SA,RA,AA \r\n"));    // Send Header

        sprintf(Uart3TxBuf,"RO3\r\n");  ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
        CurrentCALChannel = 0;                                  // Set first Freq
        CurrentPowerSought = 850;                               // (-15dB) Which power level are we searching for:  750 - 1300 corresponds to -25dB to +30dB.  In tenths with + 100dB offset. 750 = -25.0dB.  891 = -10.9dB.  1220 is +22.0dB
        FlashAddress =( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );
        GetCalRecordFromFlash(FlashAddress);                    // Get CAL record to Flash.  pass Addr.  It updates Globals: SA, RA, AA, FAD, RAD, & Err.
        OldRASetting = 99;                                      // Gurantee that it is different than the cal record so it will be sent.
        RunState = 0;                                           // Start at the beginning
    }

    if(Command == 9)                                            // Verify.
    {
        switch(RunState)
        {
        case 0:                                                 // Tune
            sprintf(Uart3TxBuf,"RF%lu\r\n",( CaldFreqs[CurrentCALChannel] / 10000));  ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            PMPacer = 250;                                      // Give TR-65 time to tune.
            RunState++;                                         // Go to next Step
        break;

        case 1:                                                 // Set Attenuators
            SetRfAttDAC(ACalRecord_AA);                         // Which AA Power level is being used.
            SetStepAttenuator(ACalRecord_SA);                   // Set the Step Attenuator.       
            PMPacer = 400;                                      // Attenuators time to settle.
            if(ACalRecord_RA != OldRASetting)
            {
                OldRASetting = ACalRecord_RA;                   // Save the new Power level for the next time.  perhaps we don't have to send every time.
                sprintf(Uart3TxBuf,"RA%u\r\n",ACalRecord_RA);  ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
                PMPacer = 550;                                  // Give TR-65 time to settle.
            }
            RunState++;                                         // Go to next Step
        break;
    
        case 2:                                                 // We tuned and set attenuators and waited.   Time to measure. 
            CurrentFAD  = GetAD(0);                             // Pass in selected channel; 0 = Forward, 1 = Reverse; 
            for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                CurrentFAD += GetAD(0); 
            CurrentFAD = CurrentFAD / 16;                       // Some Filtering

            CurrentRAD  = GetAD(1);                             // Pass in selected channel; 0 = Forward, 1 = Reverse; 
            for(LoopCounter = 0;LoopCounter<16;LoopCounter++)
                CurrentRAD += GetAD(1); 
            CurrentRAD = CurrentRAD / 16;                       // Some Filtering
 
            if(AveragePwrReading > (CurrentPowerSought * 10) )  // Calculate the power error.
                PwrError = (AveragePwrReading -  (CurrentPowerSought * 10) );
            else
                PwrError = ( (CurrentPowerSought * 10) - AveragePwrReading);
            //                                                                                Freq                               Pwr                CFAD          CRAD           CErr                VFAD        VRAD        VErr
            DebugOut( sprintf(Uart5TxBuf, "%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%u,%u,%lu\n\r",CaldFreqs[CurrentCALChannel]/10000,CurrentPowerSought,ACalRecord_FAD,ACalRecord_RAD,ACalRecord_PwrError,CurrentFAD, CurrentRAD, PwrError, AveragePwrReading, ACalRecord_SA,ACalRecord_RA,ACalRecord_AA));

            CurrentPowerSought++;                                      // go to the next power level
            if(CurrentPowerSought > 1300)                              // If we did all power levels for this frequency
            {
                CurrentPowerSought = 850;                              // Go back to the first power level
                CurrentCALChannel++;                                   // Go to the next frequency.
                if(CurrentCALChannel > 50)                             // If we did all the frequencies.
                    RunState = 3;                                      // Shut everything down and idle.
                else
                {
                     FlashAddress =( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );
                     GetCalRecordFromFlash(FlashAddress);              // Get CAL record to Flash.  pass Addr.  It updates Globals: SA, RA, AA, FAD, RAD, & Err.
                     RunState = 0;                                     // Tune to the next frequency.
                }
            }
            else
            {
                FlashAddress =( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );
                GetCalRecordFromFlash(FlashAddress);                    // Get CAL record to Flash.  pass Addr.  It updates Globals: SA, RA, AA, FAD, RAD, & Err.
                RunState = 1;                                           // Set Attenuators.
            }
        break;
   
        case 3:                                                         // We are done.   Shutdown and bail.
            DebugOut( sprintf(Uart5TxBuf, "Calibration verification for current temperature range complete.\r\n"));
            sprintf(Uart3TxBuf,"RO0\r\n"); ReverseString(Uart3TxBuf);   Uart3TXpointer = strlen(Uart3TxBuf);
            TestModeState = TESTMODEIDLE;         // Do Nothing.
            Command = 0;                          // Set up for Verification
            return;
        break;
        }
    }
}



void SaveCalRecordtoFlash(uint32_t FlashAddress , uint8_t SA , uint8_t RA , uint16_t AA , uint16_t FAD , uint16_t RAD , uint16_t PwrError)     // Write CAL record to Flash.
{
static uint8_t DatToSend;
static uint8_t WhatWasRead;
static uint8_t AddressMSB;    // Most   significant bits.
static uint8_t AddressLSB;    // Lower  significant Bits.
static uint8_t AddressXLB;    // Lowest significant bits.
static uint8_t LocalSA;       // Local copy of the data passed in.  Local copy is needed so we can get a pointer
static uint8_t LocalRA;       //
static uint8_t LocalAAMSB;    // 
static uint8_t LocalAALSB;    //
static uint8_t LocalFADMSB;   // 
static uint8_t LocalFADLSB;   // 
static uint8_t LocalRADMSB;   // 
static uint8_t LocalRADLSB;   // 
static uint8_t LocalERRMSB;   //
static uint8_t LocalERRLSB;   //

    DatToSend = 0x05;                                                     // Read Status Register 1   *** Check for BUSY ***
    WhatWasRead = 0x01;                                                   // Pretend we are busy for the entry into the test
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);          // Set FLASH Chip select LOW to select it.    
    while (WhatWasRead & 0x01)                                            // Start Reading the Status register at address 0x05. Bottom bit is the Busy Flag.  1 = busy
    {                                                                     // Wait here until the FLASH is done erasing the entire device.   40 - 200 seconds.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);         // 8 bits are shifted in when 8 bits are sent.  
    }
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, HIGH );     // Set Chip select back high to un-select it

    AddressMSB = (uint8_t)((FlashAddress & 0x00FF0000) >> 16);  // Most Sig
    AddressLSB = (uint8_t)((FlashAddress & 0x0000FF00) >> 8);   // Lower Sig
    AddressXLB = (uint8_t)(FlashAddress & 0x000000FF);          // extra low significiant

    if(FlashAddress & 0x0000000E)      // there's an error if we ever pass in address that does not start at the beginning of an 8 byte boundry.
        ;   // TODO blink a light or something
    
    LocalSA     = SA;                                                     // Get Local copies so a pointer is available.
    LocalRA     = RA;       
    LocalAAMSB  = (uint8_t)(( AA & 0xFF00) >> 8);  
    LocalAALSB  = (uint8_t) ( AA & 0x00FF);   
    LocalFADMSB = (uint8_t)((FAD & 0xFF00) >> 8);
    LocalFADLSB = (uint8_t) (FAD & 0x00FF); 
    LocalRADMSB = (uint8_t)((RAD & 0xFF00) >> 8);
    LocalRADLSB = (uint8_t) (RAD & 0x00FF); 
    LocalERRMSB = (uint8_t)((PwrError & 0xFF00) >> 8);
    LocalERRLSB = (uint8_t) (PwrError & 0x00FF);
    
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 6;                                                              // Create Write Enable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);                   // Send the command.
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, HIGH );           // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 2;                                                              // Create Write command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Write command.
    DRV_SPI0_BufferAddWriteRead(&AddressMSB, &WhatWasRead, 1);                  // Send the Most   significant bits of the address   This takes 30 to 50uS for the FLASH to process.
    DRV_SPI0_BufferAddWriteRead(&AddressLSB, &WhatWasRead, 1);                  // Send the Lower  significant bits of the address   Additional consecutive writes take 12uS each for the FLASH to process.
    DRV_SPI0_BufferAddWriteRead(&AddressXLB, &WhatWasRead, 1);                  // Send the Lowest significant bits of the address
    DRV_SPI0_BufferAddWriteRead(&LocalSA,    &WhatWasRead, 1);                  // Send the Step Attenuator data    
    DRV_SPI0_BufferAddWriteRead(&LocalRA,    &WhatWasRead, 1);                  // Send the TR-65 Attenuator data 
    DRV_SPI0_BufferAddWriteRead(&LocalAAMSB, &WhatWasRead, 1);                  // Send the Most  significant bits of Analog Attenuator data     
    DRV_SPI0_BufferAddWriteRead(&LocalAALSB, &WhatWasRead, 1);                  // Send the Most  significant bits of Analog Attenuator data
    DRV_SPI0_BufferAddWriteRead(&LocalFADMSB,&WhatWasRead, 1);                  // Send the Most  significant bits of FAD
    DRV_SPI0_BufferAddWriteRead(&LocalFADLSB,&WhatWasRead, 1);                  // Send the Least significant bits of FAD
    DRV_SPI0_BufferAddWriteRead(&LocalRADMSB,&WhatWasRead, 1);                  // Send the Most  significant bits of RAD
    DRV_SPI0_BufferAddWriteRead(&LocalRADLSB,&WhatWasRead, 1);                  // Send the Least significant bits of RAD
    DRV_SPI0_BufferAddWriteRead(&LocalERRMSB,&WhatWasRead, 1);                  // Send the RF Power Error MSB
    DRV_SPI0_BufferAddWriteRead(&LocalERRLSB,&WhatWasRead, 1);                  // Send the RF Power Error LSB    
    
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,HIGH );            // Set Chip select back high to un-select it
        
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 4;                                                              // Create Write Disable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);                   // Send the command.
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,HIGH );            // Set Chip select back high to un-select it
    
    return;      
}


void GetCalRecordFromFlash(uint32_t FlashAddress)        // Get CAL record to Flash.  Addr, SA, RA, AA, FAD, RAD, Err.
{
static uint8_t DatToSend;
static uint8_t WhatWasRead;
static uint8_t AddressMSB;    // Most   significant bits.
static uint8_t AddressLSB;    // Lower  significant Bits.
static uint8_t AddressXLB;    // Lowest significant bits.

    DatToSend = 0x05;                                                     // Read Status Register 1   *** Check for BUSY ***
    WhatWasRead = 0x01;                                                   // Pretend we are busy for the entry into the test
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);          // Set FLASH Chip select LOW to select it.    
    while (WhatWasRead & 0x01)                                            // Start Reading the Status register at address 0x05. Bottom bit is the Busy Flag.  1 = busy
    {                                                                     // Wait here until the FLASH is done erasing the entire device.   40 - 200 seconds.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);         // 8 bits are shifted in when 8 bits are sent.  
    }
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, HIGH );     // Set Chip select back high to un-select it

    AddressMSB = (uint8_t)((FlashAddress & 0x00FF0000) >> 16);
    AddressLSB = (uint8_t)((FlashAddress & 0x0000FF00) >> 8);
    AddressXLB = (uint8_t)(FlashAddress & 0x000000FF);

    if(FlashAddress & 0x00000007)      // there's an error if we ever pass in address that does not start at the beginning of an 8 byte boundry.
        ;   // TODO blink a light or something

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 3;                                                              // Create Read command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Read command.
    DRV_SPI0_BufferAddWriteRead(&AddressMSB, &WhatWasRead, 1);                  // Send the Most   significant bits of the address
    DRV_SPI0_BufferAddWriteRead(&AddressLSB, &WhatWasRead, 1);                  // Send the Lower  significant bits of the address
    DRV_SPI0_BufferAddWriteRead(&AddressXLB, &WhatWasRead, 1);                  // Send the Lowest significant bits of the address
    
    DatToSend = 0;                                                              // Create Clean Dummy Byte
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Step Attenuator data 
    ACalRecord_SA = WhatWasRead;                                                // Global uint8_t    Holds the Step  Attenuator setting for the requested Freq and Power level    
    
    DatToSend = 0;                                                              // Create Clean Dummy Byte
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Step Attenuator data 
    ACalRecord_RA = WhatWasRead;                                                // Global uint8_t    Holds the TR-65 Attenuator setting for the requested Freq and Power level    

    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Get the Analog Attenuator data    
    ACalRecord_AA = WhatWasRead;                                                // Global uint8_t    Holds the Analog Attenuator setting for the requested Freq and Power level   
    ACalRecord_AA = ACalRecord_AA << 8;                                         // Shift it up to make room for the LSBs
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Get the MSB Analog Attenuator data    
    ACalRecord_AA |= WhatWasRead;                                               // Add in the LSB  
    
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Most  significant bits of FAD
    ACalRecord_FAD = WhatWasRead;                                               // Global uint16_t   Holds the Forward AD reading that was measured at CAL verify time for the current Freq and Power level
    ACalRecord_FAD = ACalRecord_FAD << 8;                                       // Shift it up to make room for the LSBs
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Least significant bits of FAD
    ACalRecord_FAD |= WhatWasRead;                                              // Bring in the LSB of the word.
    
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Most  significant bits of RAD
    ACalRecord_RAD = WhatWasRead;                                               // Global uint16_t   Holds the Reverse AD reading that was measured at CAL verify time for the current Freq and Power level
    ACalRecord_RAD = ACalRecord_RAD << 8;                                       // Shift it up to make room for the LSBs
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Least significant bits of RAD
    ACalRecord_RAD |= WhatWasRead;                                              // Bring in the LSB of the word.    
    
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Most  significant bits of the power error
    ACalRecord_PwrError = WhatWasRead;                                          // Global uint16_t   Holds the power error reading that was measured at CAL verify time for the current Freq and Power level
    ACalRecord_PwrError = ACalRecord_PwrError << 8;                             // Shift it up to make room for the LSBs
    DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1);                    // Get the Least significant bits of power error
    ACalRecord_PwrError |= WhatWasRead;                                         // Bring in the LSB of the word.    
    
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,   HIGH );         // Set Chip select back high to un-select it

    return;      
}


//*** End of File***************************************************************


