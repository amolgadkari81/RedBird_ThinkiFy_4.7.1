//*******************************************************************************
//  C Source File
//
//  Company:
//    Grinder Switch Technologies.
//
//  File Name:
//    App.c
//    USB RX Parse and some USB TX routines
//
//  Last Edit Date:  Sept  3 2017   JRL Updates for Rev B Board
//  Last Edit Date:  Oct   3 2016   JRL    Clean up after calibration debug.
//  Last Edit Date:  Sept 10 2016   JRL
//*******************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "system_definitions.h"
#include "app.h"
#include "globals.h"
#include "led.h"
#include "peripheral/rtcc/plib_rtcc.h"


extern uint32_t CaldFreqs[];

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

void UpdatePowerMeter(uint8_t);                                // Build a USB message to send temp and Frequency to Power Meter
void Send0xE2Data(void);                                       // unsolicited response sent at the completion of a 0x0B command.
void Send0xE3Data(void);                                       // This function sends data to the host each time a 0x10 test is run.
void Send0xE4Data(uint8_t PassFail);                           // unsolicited response sent at the completion of a 0x18 Sensivity test command.
void SendFaultNoticeToHost(uint8_t);                           // Build a USB message to notify the HOST that a fault Occurred.   Pass in the Fault ID
void Send0XE5EventNoticeToHost(uint8_t);                       // Send USB Event Notice to HOST.   0x03 = Flash Erase Complete. 04 Command 0x10 setup complete.
void FlushLabelData(void);                                     // Delete the EPC and TID data from the last read.
uint8_t receiveDataBuffer[64] APP_MAKE_BUFFER_DMA_READY;       // Recieve data buffer
uint8_t transmitDataBuffer[64] APP_MAKE_BUFFER_DMA_READY;      // Transmit data buffer
uint8_t appCmd10Data_startTagID[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c}; // Start Tag ID for command 0x10
uint8_t bulkTagID[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c}; // Tag ID that will be used on the next bulk write.
void Send0xE4Data(uint8_t);                                    // unsolicited response sent at the completion of a 0x18 Sensivity test command.   pass in 1 for Pass, 0 for fail.
void Send0xE6PacketHS(void);                                   // Send the High Speed Data packet
void InitTR65Nudge(void);                                      // Sends all the commands needed to get the TR-65 initalized after a power up reset.  All LEDs will be on while in progress.
// *****************************************************************************

APP_DATA appData; // This structure should be initialized by the APP_Initialize function.

APP_DATETIME appDateTime;

APP_TRIGGERINPUTSETTINGS appCmd12Data; //This structure holds the application's command 0x12 data. it should be initialized by the APP_Initialize function.

APP_TRIGGEROUTPUTSETTINGS appCmd13Data;

APP_SETBULKWRITESETTINGS appCmd16Data;





// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

USB_DEVICE_HID_EVENT_RESPONSE APP_USBDeviceHIDEventHandler
(
        USB_DEVICE_HID_INDEX iHID,
        USB_DEVICE_HID_EVENT event,
        void * eventData,
        uintptr_t userData
        ) {
    USB_DEVICE_HID_EVENT_DATA_REPORT_SENT * reportSent;
    USB_DEVICE_HID_EVENT_DATA_REPORT_RECEIVED * reportReceived;

    /* Check type of event */
    switch (event) {
        case USB_DEVICE_HID_EVENT_REPORT_SENT:

            /* The eventData parameter will be USB_DEVICE_HID_EVENT_REPORT_SENT
             * pointer type containing details about the report that was
             * sent. */
            reportSent = (USB_DEVICE_HID_EVENT_DATA_REPORT_SENT *) eventData;
            if (reportSent->handle == appData.txTransferHandle) {
                // Transfer progressed.
                appData.hidDataTransmitted = true;
            }

            break;

        case USB_DEVICE_HID_EVENT_REPORT_RECEIVED:

            /* The eventData parameter will be USB_DEVICE_HID_EVENT_REPORT_RECEIVED
             * pointer type containing details about the report that was
             * received. */

            reportReceived = (USB_DEVICE_HID_EVENT_DATA_REPORT_RECEIVED *) eventData;
            if (reportReceived->handle == appData.rxTransferHandle) {
                // Transfer progressed.
                appData.hidDataReceived = true;
            }

            break;

        case USB_DEVICE_HID_EVENT_SET_IDLE:

            /* For now we just accept this request as is. We acknowledge
             * this request using the USB_DEVICE_HID_ControlStatus()
             * function with a USB_DEVICE_CONTROL_STATUS_OK flag */

            USB_DEVICE_ControlStatus(appData.usbDevHandle, USB_DEVICE_CONTROL_STATUS_OK);

            /* Save Idle rate recieved from Host */
            appData.idleRate = ((USB_DEVICE_HID_EVENT_DATA_SET_IDLE*) eventData)->duration;
            break;

        case USB_DEVICE_HID_EVENT_GET_IDLE:

            /* Host is requesting for Idle rate. Now send the Idle rate */
            USB_DEVICE_ControlSend(appData.usbDevHandle, & (appData.idleRate), 1);

            /* On successfully reciveing Idle rate, the Host would acknowledge back with a
               Zero Length packet. The HID function drvier returns an event
               USB_DEVICE_HID_EVENT_CONTROL_TRANSFER_DATA_SENT to the application upon
               receiving this Zero Length packet from Host.
               USB_DEVICE_HID_EVENT_CONTROL_TRANSFER_DATA_SENT event indicates this control transfer
               event is complete */

            break;
        default:
            // Nothing to do.
            break;
    }
    return USB_DEVICE_HID_EVENT_RESPONSE_NONE;
}

void APP_USBDeviceEventHandler(USB_DEVICE_EVENT event, void * eventData, uintptr_t context) {
    switch (event) {
        case USB_DEVICE_EVENT_RESET:
        case USB_DEVICE_EVENT_DECONFIGURED:

            /* Host has de configured the device or a bus reset has happened.
             * Device layer is going to de-initialize all function drivers.
             * Hence close handles to all function drivers (Only if they are
             * opened previously. */

            //BSP_LEDOn(APP_USB_LED_1);
            //BSP_LEDOn(APP_USB_LED_2);
            //BSP_LEDOff(APP_USB_LED_3);
            appData.deviceConfigured = false;
            appData.state = APP_STATE_WAIT_FOR_CONFIGURATION;
            break;

        case USB_DEVICE_EVENT_CONFIGURED:
            /* Set the flag indicating device is configured. */
            appData.deviceConfigured = true;

            /* Save the other details for later use. */
            appData.configurationValue = ((USB_DEVICE_EVENT_DATA_CONFIGURED*) eventData)->configurationValue;

            /* Register application HID event handler */
            USB_DEVICE_HID_EventHandlerSet(USB_DEVICE_HID_INDEX_0, APP_USBDeviceHIDEventHandler, (uintptr_t) & appData);

            /* Update the LEDs */
            //BSP_LEDOff(APP_USB_LED_1);  //Ver2.12
            //BSP_LEDOff(APP_USB_LED_2);  //Ver2.12
            //BSP_LEDOn(APP_USB_LED_3);   //Ver2.12

            break;

        case USB_DEVICE_EVENT_SUSPENDED:

            /* Switch on green and orange, switch off red */
            //BSP_LEDOff(APP_USB_LED_1);  //Ver2.12
            //BSP_LEDOn(APP_USB_LED_2);   //Ver2.12
            //BSP_LEDOn(APP_USB_LED_3);   //Ver2.12
            break;

        case USB_DEVICE_EVENT_POWER_DETECTED:

            /* VBUS was detected. We can attach the device */

            USB_DEVICE_Attach(appData.usbDevHandle);
            break;

        case USB_DEVICE_EVENT_POWER_REMOVED:

            /* VBUS is not available */
            USB_DEVICE_Detach(appData.usbDevHandle);
            break;

            /* These events are not used in this demo */
        case USB_DEVICE_EVENT_RESUMED:
        case USB_DEVICE_EVENT_ERROR:
        default:
            break;
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
 */


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize(void) {
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;

    appData.usbDevHandle = USB_DEVICE_HANDLE_INVALID;
    appData.deviceConfigured = false;
    appData.txTransferHandle = USB_DEVICE_HID_TRANSFER_HANDLE_INVALID;
    appData.rxTransferHandle = USB_DEVICE_HID_TRANSFER_HANDLE_INVALID;
    appData.hidDataReceived = false;
    appData.hidDataTransmitted = true;
    appData.receiveDataBuffer = &receiveDataBuffer[0];
    appData.transmitDataBuffer = &transmitDataBuffer[0];
    appData.ledflag = 0;

    MarkPunchActive = 0;          // The pass/fail indication will be stuffed into the MarkPunch array when set.  Typically reset (0) for Firmware triggered tests.

    TestingLEDs = 2;              // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
    All_LEDS_OFF(); //turn off all led's
    DRV_TMR0_Start(); // Start Timer 3 
    DRV_TMR1_Start(); // Start Timer 2 
    status = 0x00; //System status
    lastfault = 0; //last fault and command
    lastcommand = 0;
    RFChannel = 1; //Initial state for RF parameters
    // RFAttenuation = 0;
    StrapTestMode = 0;
    Counter1mS = 0;
    HSReaderTMTimer = 1000; //Set test mode timers to 1 second each at boot
    HSGPIOTMTimer = 1000;
    HSReaderCounter = 0; //Zero test mode counters
    HSGPIOCounter = 0;
    Banner1Count = 0; //Zero sensor counter

    /*Command 0x10 initialization*/
    appCmd10Data.testtype = READEPC;  // Test type 96bit EPC read to start with
    appCmd10Data.tagclass = EPC1GEN2; // EPC1 Gen 2
    appCmd10Data.antport = 1;         // Antenna port
    appCmd10Data.readpower = 1200;    // Read power ddbm = +20 dB
    appCmd10Data.readtimeout = 100;   // Read time out ms
    appCmd10Data.freq1 = 960000000;   // Frequency 1
    appCmd10Data.freq2 = 904000000;   // Frequency 2
    appCmd10Data.freq3 = 906000000;   // Frequency 3
    appCmd10Data.writepower = 1200;   // Write power = +20 dB
    appCmd10Data.writetimeout = 500;  // Write timeout
    appCmd10Data.writetype = 0;       // Write type

    /*Command 0x18 initialization*/
    appCmd18Data.ReadWrite = 0;        // uint8    0 = Read
    appCmd18Data.AntPort = 1;          // uint8    Always 1
    appCmd18Data.Freq = 902000000;     // uint32   902MHz
    appCmd18Data.MinPower = 900;       // uint16   -1dB
    appCmd18Data.MaxPower = 1100;      // uint16   +1dB
    appCmd18Data.SearchDepth = 25;     // uint8    25 steps
    appCmd18Data.Timeout = 50;         // uint16   50mS
    appCmd18Data.PassThreshold = 900;  // uint16   -1dB
    appCmd18Data.Options = 0;          // uint8    Use Current TAG ID every time
    appCmd18Data.CurrentPowerLevel;    // uint16.  Working Variable:  The current power level number being tested.   Add 750 to convert it back to the encoded dB.

    // Command 0x1d initialization
    appCmd1dData.triggerfiltermin = 0; // Number of encoder ticks to ignore trigger input (ticks).
    appCmd1dData.EncoderTicoffset = 0; // Number of encoder ticks to offset test start from trigger input (ticks).
    appCmd1dData.markeroffset = 0;     // Number of encoder ticks to offset marker start from trigger input (ticks).
    appCmd1dData.punchoffset = 0;      // Number of encoder ticks to offset punch start from trigger input (ticks).
    appCmd1dData.punchflight = 11;     // Flight time (in ms) for the punch.
    appCmd1dData.triggerfiltermax = 0; // Number of encoder ticks before input trigger is automatically inserted.

    // Command 0x11 initialization
    appCmd11Data.enable = 0;           // Enable / disable marker output.    0 disable, 1 = Mark Bad labels, 2 = Mark Good labels
    appCmd11Data.position = 0;         // This is the number of labels between the Antenna and the center of the mark tool.
    appCmd11Data.duration = 0;         // Duration in ms that marker fires for.
    appCmd11Data.offset = 0;           // Offset in ms that marker waits before firing after trigger is received.

    // Command 0x12 initialization
    appCmd12Data.Enable = 1;           // New label (Hardware) trigger input.  0 = Disabled, 1 = enabled
    appCmd12Data.edgetype = 1;         // Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).
    appCmd12Data.debounce = 0;         // Debounce time in ms. (Not yet supported)
    appCmd12Data.deaftics = 4;         // Further to debounce, how much longer not to react to input changes (ms).
    appCmd12Data.testoffset = 0;       // Number of ms to wait from trigger being received until test starts (ms).
    appCmd12Data.triggeroffset = 1;    // What causes a delay between Banner and test.  0 None, 1 mS delay, 2 Encoder Delay.  Uses the Encoder TICS from 0x1D and mS offset from this command.

    // Command 0x13 initialization   
    appCmd13Data.enable = 0;           // Enable / disable trigger input. (00 = Disable, 01 = Enable).
    appCmd13Data.edgetype = 0;         // Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).
    appCmd13Data.duration = 20;        // Duration in ms that output triggers. 0 means until next input trigger is received.

    // Command 0x14 initialization
    appCmd14Data.enable = 1;           // Enable / disable trigger input. (00 = Disable, 01 = Enable). Default changed to enabled.
    appCmd14Data.position = 0;         // Relative position of tester on web from arbitrary start position (00).

    // Command 0x15 initialization
    appCmd15Data.testpasscount = 0; // Number of test passes.
    appCmd15Data.testfailcount = 0; // Number of test failures.
    appCmd15Data.triggercount = 0;  // Number of test triggers.

    // Command 0x16 initialization
    appCmd16Data.antport = 1; // Antenna port configuration to use. 0 = No port, 1 = Tx1 RX1, 2 = Tx2 Rx2, 3 = Tx1 Rx2.
    appCmd16Data.writepower = 0; // Write power in centi-dBm. -1500 to 3000.
    appCmd16Data.writetimeout = 100; // Write command timeout in ms.
    appCmd16Data.frequency = 902000000; // Frequency to bulk write at. F in Hz.
    appCmd16Data.count = 10; // Number of triggers before performing a bulk write. (Set to 0 for no bulk write).
    appCmd16Data.writetype = 0; // 0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values.
    appCmd16Data.bulkTagID = &bulkTagID[0]; // Tag ID that will be used on the next bulk write.
    Enable0xE6Mode = 0; // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.

    // Command 0x20 initialization
    appCmd20Data.enable = 0;      // Enable/disable Punch output. 0 disable, 1 = Punch Bad 
    appCmd20Data.position = 3;    // This the number of labels between the Antenna and the center of the punch tool.
    appCmd20Data.duration = 3;    // Duration in ms that Punch fires for.
    appCmd20Data.offset = 0;      // Offset in ms that Punch waits before firing after trigger is received.
    appCmd20Data.OffsetSel = 0;   // What causes the Punch offset:  0 = 0x1D Punch offset Tics, 1 = 0x20 Punch offset mS

    Cmd21_LabelPitchTics = 35; // The Nominal pitch of the labels in tics.( Num tics from the leading edge of one label to the leading edge of the next label)
    Cmd21_NomLabelTics = 28;   // The Nominal tics that are expected per Label (leading edge to trailing edge of a single label)
    Cmd21_TicsPerInch = 50;    // The exact number of tics that will be sent for each 1.000 inch of Web length

    TestModeState = TESTMODEIDLE; // Stay in the IDLE mode until a command is received.
    TimeToBreak = 0; // Debug only

    EncoderDeafTimeReload = 0; // Used to ignore pulses from the encoder if they come quicker than planned.  This is the value that is set by the PC using command 0x1C

    PlayPause = 0; // 0 = pause.  1 = Play. for test 0x10

    InitTest0x10State = 0; // All the parts of getting test 0x10 setup.
    Test0x18State = 0; // All the parts of getting test 0x18 setup and run.
    Test0x6AState = 0; // All the parts of getting test 0x6A setup and run.

    InitTr65Once = 3; // Set to 3 on powerup.  The main line code will perform the init of the TR-65 three seconds after the unit comes out of reset.
    TR65InitStateMachine = 0; // Keeps up with where the state machine is.   0 = IDLE
    JustDidSensitivityTest = 0; // set in the Sensitivity test.  Lets us skip the wait for new label test when reentering test 0x10 after setting the attenuators.

}

/*******************************************************************************
  Function:
    void APP_DateTimeInitialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_DateTimeInitialize(void) {
    appDateTime.lane = 1;
    appDateTime.year = 16;
    appDateTime.month = 4;
    appDateTime.day = 25;
    appDateTime.hour = 15;
    appDateTime.minute = 16;
    appDateTime.second = 20;
    appDateTime.dtupdateflag = 0;

}

/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks(void) 
{
    // Check if device is configured.  See if it is configured with correct configuration value.
    switch (appData.state) 
    {
        case APP_STATE_INIT:

            /* Open the device layer */
            appData.usbDevHandle = USB_DEVICE_Open(USB_DEVICE_INDEX_0, DRV_IO_INTENT_READWRITE);

            if (appData.usbDevHandle != USB_DEVICE_HANDLE_INVALID) {
                /* Register a callback with device layer to get event notification (for end point 0) */
                USB_DEVICE_EventHandlerSet(appData.usbDevHandle, APP_USBDeviceEventHandler, 0);

                appData.state = APP_STATE_WAIT_FOR_CONFIGURATION;

                //Have to do this at least once while waiting for usb port to enumerate
                INIT_BEFORE_USB();

            } else {
                /* The Device Layer is not ready to be opened. We should try
                 * again later. */
            }

            break;

        case APP_STATE_WAIT_FOR_CONFIGURATION:

            if (appData.deviceConfigured == true) {
                /* Device is ready to run the main task */
                appData.hidDataReceived = false;
                appData.hidDataTransmitted = true;
                appData.state = APP_STATE_MAIN_TASK;

                /* Place a new read request. */
                USB_DEVICE_HID_ReportReceive(USB_DEVICE_HID_INDEX_0,
                        &appData.rxTransferHandle, appData.receiveDataBuffer, 64);
            }

            break;

        case APP_STATE_MAIN_TASK:

            if (!appData.deviceConfigured)  // Device is not configured
            {               
                appData.state = APP_STATE_WAIT_FOR_CONFIGURATION;
            }
            else if (appData.deviceConfigured) 
            {
                //////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////////////////////////////////////////////////////////////////////
                //  Runs each time thru loop.
                //////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////////////////////////////////////////////////////////////////////

                MainLoopStuff();             // Do all the Main Loop Stuff in the PCB_Peripherals.c File
                
                if (PendingHostEventNotice)                                  // if a notice is ready to go.
                {
                    Send0XE5EventNoticeToHost(PendingHostEventNotice);       // Send USB Event Notice to HOST.
                    PendingHostEventNotice = 0;                              // So it doesn't repeat forever.                           
                }
                
                TestStateMachine();          // Do all the test stuff needed by the programmer.

                if(TR65InitStateMachine)     // 0 = Idle.   Anything else is part of the init routine.
                    InitTR65Nudge();         // Sends all the commands needed to get the TR-65 initalized after a power up reset.  All LEDs will be on while in progress.

                if (appData.hidDataReceived)    // Look at the data the host sent, to see what kind of application specific command it sent.
                {
                    switch (appData.receiveDataBuffer[0]) 
                    {
                        case 0xee:

                            Parse_Received_Command();                                    // Parse and execute the received command
                            TxUSBPacketUpdate();                                         // Transmit the packet that was just assembled to USB port
                            PlaceUSBReadRequest();                                       // Place new read request
                            break;

                        case 0x80:

                            if (appData.ledflag) 
                            {
                                TestingLEDs = 30;            // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
                                All_LEDS_OFF();
                                appData.ledflag = 0;
                            }
                            else if (!appData.ledflag) 
                            {
                                TestingLEDs = 30;            // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
                                All_LEDS_ON();
                                appData.ledflag = 1;
                            }

                            PlaceUSBReadRequest(); // Place new read request

                            break;

                        case 0x81:

                            if (appData.hidDataTransmitted) // Echo back to the host PC the command we are fulfilling in the first byte.  
                            { // In this case, the Get Push-button State command.

                                appData.transmitDataBuffer[0] = 0x81;

                                if (BSP_SwitchStateGet(APP_USB_SWITCH_1) == BSP_SWITCH_STATE_PRESSED)
                                    appData.transmitDataBuffer[1] = 0x00;
                                else
                                    appData.transmitDataBuffer[1] = 0x01;

                                if (BSP_SwitchStateGet(APP_USB_SWITCH_2) == BSP_SWITCH_STATE_PRESSED)
                                    appData.transmitDataBuffer[1] = 0x00;
                                else
                                    appData.transmitDataBuffer[1] = 0x01;

                                TxUSBPacketUpdate(); // Transmit packet to USB port
                                PlaceUSBReadRequest(); // Place new read request
                            }
                            break;

                        default:
                            PlaceUSBReadRequest(); // Place new read request
                            break;
                    }
                }
            }
            else 
            {
                /* Just run without a usb connection */
            }
            break;

        case APP_STATE_ERROR:
            break;

        default:
            break;
    }
}

/******************************************************************************
  Function:
    void Parse_Received_Command( void )

  Remarks:
    Clears transmit buffer on entry; sets up transmit buffer with requested
    parameters. Clears receive buffer prior to exit.
    See GSTTestModuleCommands.xls for command description.
 */

void Parse_Received_Command(void) {
    static uint8_t receivedChecksum, ComputedChecksum;
    static uint8_t rcvdLEN, rcvChecksumIndex;
    static uint8_t lpcntr;
    static uint8_t JustATemp8;              // Temporary storage.  Typically used for a few lines of code then abandoned.
    static uint32_t JustATemp32;            // Temporary storage.  Typically used for a few lines of code then abandoned.
    //static uint32_t JustATemp32A;         // Temporary storage.  Typically used for a few lines of code then abandoned.
    //static uint32_t JustATemp32B;         // Temporary storage.  Typically used for a few lines of code then abandoned.
    //static uint32_t JustATemp32C;         // Temporary storage.  Typically used for a few lines of code then abandoned.
    //static uint32_t JustATemp32D;         // Temporary storage.  Typically used for a few lines of code then abandoned.
    static uint16_t JustATemp16;            // Temporary storage.  Typically used for a few lines of code then abandoned.
    
    APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
    appData.transmitDataBuffer[0] = 0xee; // Setup universally required response parameters
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);

    // ***************************************************************************************



    rcvdLEN = appData.receiveDataBuffer[1]; // Get the index of the received checksum
    rcvChecksumIndex = rcvdLEN + 3; // Check to see if the received checksum equals the computed checksum in the receive buffer
    receivedChecksum = appData.receiveDataBuffer[rcvChecksumIndex]; // Now retrieve the checksum we received in the packet
    ComputedChecksum = CheckSumRX(&appData.receiveDataBuffer[1]); // Compute the checksum from the received packet
    //DebugOut( sprintf(Uart5TxBuf, "Checksum: %X %X\r\n",receivedChecksum,ComputedChecksum));

    /*If the checksums don't match then setup the response with status = 0x02  */
    if (receivedChecksum != ComputedChecksum) {
        appData.transmitDataBuffer[1] = 0x00; // Make the return command length 0
        appData.transmitDataBuffer[2] = appData.receiveDataBuffer[2]; // echo back the received command
        status = 0x02; // set status to FCS error
        appData.transmitDataBuffer[3] = status;
        appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
    } else {
        status = 0x00; // Assume status = 0 here, may change later on if error is detected.
        appData.transmitDataBuffer[3] = status;

        switch (appData.receiveDataBuffer[2]) // Now parse and execute the received commands
        {
                //Ping
            case 0x00:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x00;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                break;


                //Version
            case 0x01:
                appData.transmitDataBuffer[1] = 0x05; //LEN
                appData.transmitDataBuffer[2] = 0x01;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = VersionMajor;
                appData.transmitDataBuffer[7] = VersionMinor;
                appData.transmitDataBuffer[8] = VersionYear;
                appData.transmitDataBuffer[9] = VersionMonth; // Revision notes located at the bottom of Init.c
                appData.transmitDataBuffer[10] = VersionDay;
                appData.transmitDataBuffer[11] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Reset
            case 0x02:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x02; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; // reset type: 0=cpu, 1=bootloader, 3=timer

                if (appData.receiveDataBuffer[3] == 3) // If we are getting a reser timer command. 
                {
                    HostTimer = 0; // Sent to Host PC with every USB message.
                    appData.transmitDataBuffer[4] = 0; // Re-stuff the timer return message bytes
                    appData.transmitDataBuffer[5] = 0;
                }
                // TODO Get the last type of reset event or do this type of reset - ask George
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get last fault
            case 0x03:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x03; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = lastfault; // last fault
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get status
            case 0x04:
                appData.transmitDataBuffer[1] = 0x05; //LEN
                appData.transmitDataBuffer[2] = 0x04; //CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0xAA; //timer hi 2
                appData.transmitDataBuffer[7] = 0x55; //timer lo 2
                appData.transmitDataBuffer[8] = GetTemp(); //temp
                appData.transmitDataBuffer[9] = 0xBB; //cal state
                appData.transmitDataBuffer[10] = TestModeState; //operating state. Requestable States for TestModeState are defined in Globals.h
                appData.transmitDataBuffer[11] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Check calibration
            case 0x05:
                appData.transmitDataBuffer[1] = 0x01; //LEN
                appData.transmitDataBuffer[2] = 0x05;
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[4] = 0x04; // Debug only.  Overwrites timer H
                appData.transmitDataBuffer[5] = 0x05; // Debug only.  Overwrites timer L
                appData.transmitDataBuffer[6] = 0; //cal state
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Clear last fault
            case 0x06:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x06;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                lastfault = 0; //clear the last fault

                break;

                //Set Date/Time
            case 0x08:
                appDateTime.lane = appData.receiveDataBuffer[3];
                appDateTime.year = appData.receiveDataBuffer[4];
                appDateTime.month = appData.receiveDataBuffer[5];
                appDateTime.day = appData.receiveDataBuffer[6];
                appDateTime.hour = appData.receiveDataBuffer[7];
                appDateTime.minute = appData.receiveDataBuffer[8];
                appDateTime.second = appData.receiveDataBuffer[9];

                /*Set update flag so RTCC gets updated*/
                appDateTime.dtupdateflag = 1;

                /*Set current lane, date, and time*/
                SetDateTime(&appData.receiveDataBuffer[4]);

                //Setup response
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x08;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                break;


                //Get Date/Time
            case 0x09:
                appData.transmitDataBuffer[1] = 0x07; //LEN
                appData.transmitDataBuffer[2] = 0x09;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                GetDateTime(); // Get current lane, date, and time
                appData.transmitDataBuffer[6] = appDateTime.lane;
                appData.transmitDataBuffer[7] = appDateTime.year;
                appData.transmitDataBuffer[8] = appDateTime.month;
                appData.transmitDataBuffer[9] = appDateTime.day;
                appData.transmitDataBuffer[10] = appDateTime.hour;
                appData.transmitDataBuffer[11] = appDateTime.minute;
                appData.transmitDataBuffer[12] = appDateTime.second;
                appData.transmitDataBuffer[13] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set RF Settings
            case 0x0a:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x0a; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                //RFChannel = appData.receiveDataBuffer[3];
                //RFAttenuation  = appData.receiveDataBuffer[4];
                //StrapTestMode = appData.receiveDataBuffer[5];
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get RF Settings    *************** New Combo Command
            case 0x0B:

                Freq0x0B = ((uint32_t) appData.receiveDataBuffer[3] << 24) & 0xff000000; // Get the requested Frequency.
                Freq0x0B |= ((uint32_t) appData.receiveDataBuffer[4] << 16) & 0x00ff0000;
                Freq0x0B |= ((uint32_t) appData.receiveDataBuffer[5] << 8) & 0x0000ff00;
                Freq0x0B |= ((uint32_t) appData.receiveDataBuffer[6]) & 0x000000ff;

                CurrentPowerSought = ((int16_t) appData.receiveDataBuffer[7] << 8) & 0xff00; // Holds the Power level passed in with command 0x0B
                CurrentPowerSought |= (int16_t) appData.receiveDataBuffer[8];
             
                TestModeState = PERFORMTEST0X0B;                               // RF Test Mode:   Perform test 0x0B in MAIN.C
                Init0x0BState = 0; // Set TR-65 Freq

                appData.transmitDataBuffer[1] = 0x04; // LEN
                appData.transmitDataBuffer[2] = 0x0B; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get RF Status
            case 0x0c:
                appData.transmitDataBuffer[1] = 0x04; // LEN
                appData.transmitDataBuffer[2] = 0x0c; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0; // forward power msb
                appData.transmitDataBuffer[7] = 0; // forward power lsb
                appData.transmitDataBuffer[8] = 0; // reverse power msb
                appData.transmitDataBuffer[9] = 0; // reverse power lsb
                appData.transmitDataBuffer[10] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Cal Settings
            case 0x0d:
                appData.transmitDataBuffer[1] = 0x05; // LEN
                appData.transmitDataBuffer[2] = 0x0d; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0; // RF attenuation
                appData.transmitDataBuffer[7] = 0; // Reader power value in table in centi-dbm(2000 to 3000). msb
                appData.transmitDataBuffer[8] = 0; // Reader power value in table in centi-dbm(2000 to 3000). lsb
                appData.transmitDataBuffer[9] = 0; // Stored reading of forward power msb
                appData.transmitDataBuffer[10] = 0; // Stored reading of forward power lsb
                appData.transmitDataBuffer[11] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Restart Reader To Bootloader
            case 0x0e:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x0e; //CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                // TODO   Restart Reader to Bootloader
                break;

                //Get Last Message
            case 0x0f:
                appData.transmitDataBuffer[1] = 0x01; //LEN
                appData.transmitDataBuffer[2] = 0x0f; //CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = lastcommand; //Msg ID
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set Test Settings
            case 0x10:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x10; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                appCmd10Data.testtype = appData.receiveDataBuffer[3]; // Test Type bitField  (MSB) ForceKill - Unused - Unused - IDFilter - TID - Unused - Write - Read (LSB))
                appCmd10Data.tagclass = appData.receiveDataBuffer[4]; // Tag class   00 = None, 01 = EPC1Gen2, 02 = Ucode, 03 = Impinj M5, 04 = Impinj R6, 05 = Impinj R6P
                appCmd10Data.antport = appData.receiveDataBuffer[5]; // Antenna port

                appCmd10Data.readpower = ((int16_t) appData.receiveDataBuffer[6] << 8) & 0xff00; // Read power
                appCmd10Data.readpower = (int16_t) (appCmd10Data.readpower | appData.receiveDataBuffer[7]); // CentidB -25 to +30dB.  Add 100dB and multiply by 10.    -12.3dB is sent as 877, +22.4dB sent as 1224.

                appCmd10Data.readtimeout = ((int16_t) appData.receiveDataBuffer[8] << 8) & 0xff00; // Read timeout
                appCmd10Data.readtimeout = appCmd10Data.readtimeout | appData.receiveDataBuffer[9];

                appCmd10Data.freq1 = ((uint32_t) appData.receiveDataBuffer[10] << 24) & 0xff000000; // Read frequency 1
                appCmd10Data.freq1 = (appCmd10Data.freq1 | (((uint32_t) appData.receiveDataBuffer[11] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd10Data.freq1 = (appCmd10Data.freq1 | (((uint32_t) appData.receiveDataBuffer[12] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd10Data.freq1 = appCmd10Data.freq1 | (((uint32_t) appData.receiveDataBuffer[13]) & 0x000000ff);

                appCmd10Data.freq2 = ((uint32_t) appData.receiveDataBuffer[14] << 24) & 0xff000000; // Read frequency 2
                appCmd10Data.freq2 = (appCmd10Data.freq2 | (((uint32_t) appData.receiveDataBuffer[15] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd10Data.freq2 = (appCmd10Data.freq2 | (((uint32_t) appData.receiveDataBuffer[16] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd10Data.freq2 = appCmd10Data.freq2 | (((uint32_t) appData.receiveDataBuffer[17]) & 0x000000ff);

                appCmd10Data.freq3 = ((uint32_t) appData.receiveDataBuffer[18] << 24) & 0xff000000; // Read frequency 3
                appCmd10Data.freq3 = (appCmd10Data.freq3 | (((uint32_t) appData.receiveDataBuffer[19] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd10Data.freq3 = (appCmd10Data.freq3 | (((uint32_t) appData.receiveDataBuffer[20] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd10Data.freq3 = appCmd10Data.freq3 | (((uint32_t) appData.receiveDataBuffer[21]) & 0x000000ff);

                appCmd10Data.writepower = ((int16_t) appData.receiveDataBuffer[22] << 8) & 0xff00; // Write power
                appCmd10Data.writepower = appCmd10Data.writepower | appData.receiveDataBuffer[23]; // CentidB -25 to +30dB.  Add 100dB and multiply by 10.    -12.3dB is sent as 877, +22.4dB sent as 1224.

                appCmd10Data.writetimeout = ((uint16_t) appData.receiveDataBuffer[24] << 8) & 0xff00; // Write timeout
                appCmd10Data.writetimeout = appCmd10Data.writetimeout | appData.receiveDataBuffer[25];

                appCmd10Data.writetype = appData.receiveDataBuffer[26]; // Write Type    0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values.

                for (lpcntr = 27; lpcntr < 39; lpcntr++)                // Start tag ID.
                    appCmd10Data_startTagID[lpcntr - 27] = appData.receiveDataBuffer[lpcntr]; // Move it from the USB Buffer into the working Array.

                JustDidSensitivityTest = 0;           // set in the Sensitivity test.  Lets us skip the wait for new label test when reentering test 0x10 after setting the attenuators.
                TestModeState = INITTEST0X10;         // Init a new test 0x10.   This uses all the above variables to set the tester into a known condition.
                InitTest0x10State = 0;                // All the parts of getting test 0x10 setup.

                if (appCmd10Data.antport != 1)                          // We support antenna port #1 only.
                    appData.transmitDataBuffer[3] = 0x31;               // Set status: 0x31 = invalid antenna 

                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set Marker Settings
            case 0x11:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x11; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                appCmd11Data.enable = appData.receiveDataBuffer[3];   // Enable / disable marker output.    0 disable, 1 = Mark Bad labels, 2 = Mark Good labels
                appCmd11Data.position = appData.receiveDataBuffer[4]; // Relative position of marker on web from the Antenna.
                appCmd11Data.duration = appData.receiveDataBuffer[5]; // Duration in ms that marker fires for.
                appCmd11Data.offset = appData.receiveDataBuffer[6];   // Offset in ms that marker waits before firing after trigger is received.

                if (appCmd11Data.offset)               // If this mS offset is non-zero then we zero out the Encoder TIC offset.
                    appCmd1dData.markeroffset = 0;     // This makes command 0x11 and 0x1D order Sensitive.   Last offset is used, previous offset is discarded.

                if (appCmd11Data.enable == 2)          // If we are marking good labels.
                {
                    if (appCmd20Data.enable)           // If user wants to punch bad labels.
                    {
                        status = 0x56;                 // Notify the PC Host that an illegal mark and punch request was made.
                        appCmd20Data.enable = 0;       // Disable punch output. 00 = Disable, 01 = Punch Bad Labels.   Just to be safe.
                    }
                }
                break;

                //Set Trigger Input Settings
            case 0x12:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x12; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                appCmd12Data.Enable = appData.receiveDataBuffer[3];          // 0 = Disabled, 1 = enabled
                appCmd12Data.edgetype = appData.receiveDataBuffer[4];        // Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).
                appCmd12Data.debounce = appData.receiveDataBuffer[5];        // Debounce time in ms. (unused))
                appCmd12Data.deaftics = appData.receiveDataBuffer[6];        // We wait at least this many Encoder TICS before accepting another New Label detector Trigger.
                appCmd12Data.testoffset = appData.receiveDataBuffer[7];      // Number of ms to wait from trigger being received until test starts (ms).
                appCmd12Data.triggeroffset = appData.receiveDataBuffer[8];   // What causes a delay between Banner and test.  0 None, 1 mS delay, 2 Encoder Delay.  Uses the Encoder TICS from 0x1D and mS offset from this command.

                if (!appCmd12Data.edgetype)          // if set to Falling.  Inverted here because of the inverter line receiver on the input.
                {
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_2, INT_EDGE_TRIGGER_RISING); // Banner 1
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_3, INT_EDGE_TRIGGER_RISING); // Banner 2
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_4, INT_EDGE_TRIGGER_RISING); // Camera
                } else {
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_2, INT_EDGE_TRIGGER_FALLING); // Banner 1
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_3, INT_EDGE_TRIGGER_FALLING); // Banner 2
                    SYS_INT_ExternalInterruptTriggerSet(INT_SOURCE_EXTERNAL_4, INT_EDGE_TRIGGER_FALLING); // Camera
                }

                break;

                //Set Trigger Output Settings
            case 0x13:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x13; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                appCmd13Data.enable = appData.receiveDataBuffer[3]; // Enable / disable trigger input. (00 = Disable, 01 = Enable).
                appCmd13Data.edgetype = appData.receiveDataBuffer[4]; // Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).
                appCmd13Data.duration = appData.receiveDataBuffer[5]; // Duration in ms that output triggers. 0 means until next input trigger is received.
                break;

                //Set Tester Settings
            case 0x14:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x14; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                appCmd14Data.enable = appData.receiveDataBuffer[3]; // Enable / Disable the tester. (00 = Disable, 01 = Enable).
                appCmd14Data.position = appData.receiveDataBuffer[4]; // Specifies the arbitrary position on the web relative to the position of new label detector.
                break;

                //Set Test Statistics
            case 0x15:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x15; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                /*Number of test passes.*/
                appCmd15Data.testpasscount = ((uint32_t) appData.receiveDataBuffer[3] << 24) & 0xff000000;
                appCmd15Data.testpasscount = (appCmd15Data.testpasscount | (((uint32_t) appData.receiveDataBuffer[4] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd15Data.testpasscount = (appCmd15Data.testpasscount | (((uint32_t) appData.receiveDataBuffer[5] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd15Data.testpasscount = appCmd15Data.testpasscount | (((uint32_t) appData.receiveDataBuffer[6]) & 0x000000ff);
                /*Number of test failures.*/
                appCmd15Data.testfailcount = ((uint32_t) appData.receiveDataBuffer[7] << 24) & 0xff000000;
                appCmd15Data.testfailcount = (appCmd15Data.testfailcount | (((uint32_t) appData.receiveDataBuffer[8] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd15Data.testfailcount = (appCmd15Data.testfailcount | (((uint32_t) appData.receiveDataBuffer[9] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd15Data.testfailcount = appCmd15Data.testfailcount | (((uint32_t) appData.receiveDataBuffer[10]) & 0x000000ff);
                /*Number of test triggers.*/
                appCmd15Data.triggercount = ((uint32_t) appData.receiveDataBuffer[11] << 24) & 0xff000000;
                appCmd15Data.triggercount = (appCmd15Data.triggercount | (((uint32_t) appData.receiveDataBuffer[12] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd15Data.triggercount = (appCmd15Data.triggercount | (((uint32_t) appData.receiveDataBuffer[13] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd15Data.triggercount = appCmd15Data.triggercount | (((uint32_t) appData.receiveDataBuffer[14]) & 0x000000ff);
                //PendingHostEventNotice = 0x01; // This holds an event notice that needs to be sent after the USB message that is currently being assembled is sent.
                break;


                //Set Bulk Write Settings
            case 0x16:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x16; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                /*Antenna port*/
                appCmd16Data.antport = appData.receiveDataBuffer[3];
                /*Write power in centi-dBm. -1500 to 3000.*/
                appCmd16Data.writepower = ((int16_t) appData.receiveDataBuffer[4] << 8) & 0xff00;
                appCmd16Data.writepower = appCmd16Data.writepower | appData.receiveDataBuffer[5];
                /*Write command timeout in ms.*/
                appCmd16Data.writetimeout = ((int16_t) appData.receiveDataBuffer[6] << 8) & 0xff00;
                appCmd16Data.writetimeout = appCmd16Data.writetimeout | appData.receiveDataBuffer[7];
                /*Frequency to bulk write at. F in kHz.*/
                appCmd16Data.frequency = ((uint32_t) appData.receiveDataBuffer[8] << 24) & 0xff000000;
                appCmd16Data.frequency = (appCmd16Data.frequency | (((uint32_t) appData.receiveDataBuffer[9] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd16Data.frequency = (appCmd16Data.frequency | (((uint32_t) appData.receiveDataBuffer[10] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd16Data.frequency = appCmd16Data.frequency | (((uint32_t) appData.receiveDataBuffer[11]) & 0x000000ff);
                /*Number of triggers before performing a bulk write. (Set to 0 for no bulk write).*/
                appCmd16Data.count = appData.receiveDataBuffer[12];
                /*0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values.*/
                appCmd16Data.writetype = appData.receiveDataBuffer[13];

                //Tag ID
                for (lpcntr = 14; lpcntr < 26; lpcntr++) {
                    appCmd16Data.bulkTagID[lpcntr - 14] = appData.receiveDataBuffer[lpcntr];
                }
                break;

                //Set Antenna Settings
            case 0x17:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x17; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                if (appData.receiveDataBuffer[3] != 1) // We support antenna port #1 only.
                    appData.transmitDataBuffer[3] = 0x31; // Invalid Antenna

                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Sensitivity Test Settings
            case 0x18:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x18; //CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                appCmd18Data.ReadWrite = appData.receiveDataBuffer[3]; // 0 = Read, 1 = Write
                appCmd18Data.AntPort = appData.receiveDataBuffer[4]; // Antenna port.  we use Port #1 only

                appCmd18Data.Freq = ((uint32_t) appData.receiveDataBuffer[5] << 24) & 0xff000000; // Test frequency
                appCmd18Data.Freq = (appCmd18Data.Freq | (((uint32_t) appData.receiveDataBuffer[6] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd18Data.Freq = (appCmd18Data.Freq | (((uint32_t) appData.receiveDataBuffer[7] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd18Data.Freq = appCmd18Data.Freq | (((uint32_t) appData.receiveDataBuffer[8]) & 0x000000ff);

                appCmd18Data.MinPower = ((int16_t) appData.receiveDataBuffer[9] << 8) & 0xff00;    // Min power to start the search at.
                appCmd18Data.MinPower = appCmd18Data.MinPower | appData.receiveDataBuffer[10];     // CentidB -25 to +30dB.  Add 100dB and multiply by 10.    -12.3dB is sent as 877, +22.4dB sent as 1224.
                appCmd18Data.MinPower = appCmd18Data.MinPower - 750;                               // Arrives in CentidB.  Convert it to the power level number for use everywhere else in the program.

                appCmd18Data.MaxPower = ((int16_t) appData.receiveDataBuffer[11] << 8) & 0xff00;   // Max power that we are interested in.
                appCmd18Data.MaxPower = appCmd18Data.MaxPower | appData.receiveDataBuffer[12];     // CentidB -25 to +30dB.  Add 100dB and multiply by 10.    -12.3dB is sent as 877, +22.4dB sent as 1224.
                appCmd18Data.MaxPower = appCmd18Data.MaxPower - 750;                               // Arrives in CentidB.  Convert it to the power level number for use everywhere else in the program.

                appCmd18Data.SearchDepth = appData.receiveDataBuffer[13];                          // Number of binary iterations.

                appCmd18Data.Timeout = ((uint16_t) appData.receiveDataBuffer[14] << 8) & 0xff00;   // Read or Write timeout
                appCmd18Data.Timeout = appCmd18Data.Timeout | appData.receiveDataBuffer[15];

                appCmd18Data.PassThreshold = ((uint16_t) appData.receiveDataBuffer[16] << 8) & 0xff00;    //  Min power required that permits three successful reads in a row.
                appCmd18Data.PassThreshold = appCmd18Data.PassThreshold | appData.receiveDataBuffer[17];

                appCmd18Data.Options = appData.receiveDataBuffer[18];     // (support 0 only)  0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values.

                if (appCmd18Data.AntPort != 1)                            // We support antenna port #1 only.
                    appData.transmitDataBuffer[3] = 0x31;                 // Invalid Antenna

                if( ( appCmd18Data.MaxPower < appCmd18Data.MinPower) || ( appCmd18Data.MaxPower == appCmd18Data.MinPower) )
                    Send0XE5EventNoticeToHost(0x07);                      // Send USB Event Notice to HOST.  Error codes are in GSTTestModuleCommands spread sheet.
                
                TestModeState = INIT0X18TEST;                             // Push all these settings into the test controller.
                Test0x18State = 0;                                        // All the parts of getting test 0x18 setup.

                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                DebugOut( sprintf(Uart5TxBuf, "*1* \n\r") );// AG
                break;

                //Set TID Settings
            case 0x19:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x19; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Tag ID Filter Settings
            case 0x1a:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1a; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                Cmd1A_Options = appData.receiveDataBuffer[3]; // uint8_t     So far unused.
                // uint32_t    1 bit for each nibble of the TID filter.  1 = enabled.
                Cmd1A_NibbleEnables = (Cmd1A_NibbleEnables | (((uint32_t) appData.receiveDataBuffer[4] << 16) & 0x00ff0000)) & 0xffff0000;
                Cmd1A_NibbleEnables = (Cmd1A_NibbleEnables | (((uint32_t) appData.receiveDataBuffer[5] << 8) & 0x0000ff00)) & 0xffffff00;
                Cmd1A_NibbleEnables = Cmd1A_NibbleEnables | (((uint32_t) appData.receiveDataBuffer[6]) & 0x000000ff);
                Cmd1A_TagIdFilter[0] = appData.receiveDataBuffer[7]; // uint8_t[13] Tag ID that the filter must match.  MSB
                Cmd1A_TagIdFilter[1] = appData.receiveDataBuffer[8]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[2] = appData.receiveDataBuffer[9]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[3] = appData.receiveDataBuffer[10]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[4] = appData.receiveDataBuffer[11]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[5] = appData.receiveDataBuffer[12]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[6] = appData.receiveDataBuffer[13]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[7] = appData.receiveDataBuffer[14]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[8] = appData.receiveDataBuffer[15]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[9] = appData.receiveDataBuffer[16]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[10] = appData.receiveDataBuffer[17]; // uint8_t[13] Tag ID that the filter must match.
                Cmd1A_TagIdFilter[11] = appData.receiveDataBuffer[18]; // uint8_t[13] Tag ID that the filter must match.  LSB
                
                break;

                //Set Tag Kill Settings
            case 0x1b:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1b; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Aux In Settings
            case 0x1c:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1c; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                EncoderStyle = appData.receiveDataBuffer[3]; // 0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
                EncoderEdgePolarity = appData.receiveDataBuffer[6]; // 0 = Detect Falling Edge.   1 = Detect Rising edge.
                EncoderDeafTimeReload = appData.receiveDataBuffer[8]; // Used to ignore pulses from the encoder if they come quicker than planned

                switch (EncoderStyle) {
                    case 0: // Aux connector disabled.
                        SYS_INT_SourceDisable(INT_SOURCE_EXTERNAL_0); // Disable the Encoder A IRQ
                        SYS_INT_SourceDisable(INT_SOURCE_EXTERNAL_1); // Disable the Encoder B IRQ
                        break;

                    case 1: // Aux connector used for Quadrature encoder.
                        SYS_INT_SourceEnable(INT_SOURCE_EXTERNAL_0); // Enable the Encoder A IRQ
                        SYS_INT_SourceEnable(INT_SOURCE_EXTERNAL_1); // Enable the Encoder B IRQ
                        break;

                    case 2: // Aux connector used for Pulse type linear distance (28 Pulses per inch).
                        SYS_INT_SourceEnable(INT_SOURCE_EXTERNAL_0); // Enable the Encoder A IRQ
                        SYS_INT_SourceDisable(INT_SOURCE_EXTERNAL_1); // Disable the Encoder B IRQ

                        if (EncoderEdgePolarity) // 0 = Detect Falling Edge.   1 = Detect Rising edge.
                            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE0, INT_EDGE_TRIGGER_RISING);
                        else
                            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE0, INT_EDGE_TRIGGER_FALLING);
                        break;
                }
                break;

                //Set Encoder In Settings
            case 0x1d:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1D; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                /*Now get the received command data*/
                //Trigger Filter Min
                appCmd1dData.triggerfiltermin = ((uint16_t) appData.receiveDataBuffer[3] << 8) & 0xff00;
                appCmd1dData.triggerfiltermin = appCmd1dData.triggerfiltermin | appData.receiveDataBuffer[4];

                //Tester Offset
                appCmd1dData.EncoderTicoffset = ((uint16_t) appData.receiveDataBuffer[5] << 8) & 0xff00;
                appCmd1dData.EncoderTicoffset = appCmd1dData.EncoderTicoffset | appData.receiveDataBuffer[6];

                //Marker Offset
                appCmd1dData.markeroffset = ((uint16_t) appData.receiveDataBuffer[7] << 8) & 0xff00;
                appCmd1dData.markeroffset = appCmd1dData.markeroffset | appData.receiveDataBuffer[8];

                //Punch Offset
                appCmd1dData.punchoffset = ((uint16_t) appData.receiveDataBuffer[9] << 8) & 0xff00;
                appCmd1dData.punchoffset = appCmd1dData.punchoffset | appData.receiveDataBuffer[10];

                //Punch Flight
                appCmd1dData.punchflight = ((uint16_t) appData.receiveDataBuffer[11] << 8) & 0xff00;
                appCmd1dData.punchflight = appCmd1dData.punchflight | appData.receiveDataBuffer[12];

                //Trigger Filter Max
                appCmd1dData.triggerfiltermax = ((uint16_t) appData.receiveDataBuffer[13] << 8) & 0xff00;
                appCmd1dData.triggerfiltermax = appCmd1dData.triggerfiltermax | appData.receiveDataBuffer[14];

                if(appCmd1dData.markeroffset)      // If a TIC offset for Mark is desired it will set any mS offset to zero.
                    appCmd11Data.offset = 0;       // This makes command 0x11 and 0x1D order Sensitive.   Last offset is used, previous offset is discarded.
                
                break;

                //Set Auto Marker Settings
            case 0x1e:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1e; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                Cmd1E_desiredNumPulses = ((uint32_t) appData.receiveDataBuffer[3] << 24) & 0xff000000; // Number of Marker Pulses to create for command 0x1E
                Cmd1E_desiredNumPulses = (Cmd1E_desiredNumPulses | (((uint32_t) appData.receiveDataBuffer[4] << 16) & 0x00ff0000)) & 0xffff0000;
                Cmd1E_desiredNumPulses = (Cmd1E_desiredNumPulses | (((uint32_t) appData.receiveDataBuffer[5] << 8) & 0x0000ff00)) & 0xffffff00;
                Cmd1E_desiredNumPulses = Cmd1E_desiredNumPulses | (((uint32_t) appData.receiveDataBuffer[6]) & 0x000000ff);
                Cmd1E_desiredNumPulses *= 2; // Multiply by two because we decrement each time we change state.

                Cmd1E_desiredPulseDuration = ((uint16_t) appData.receiveDataBuffer[7] << 8) & 0xff00; // Width and Spacing for the Marker Pulses created for command 0x1E
                Cmd1E_desiredPulseDuration = Cmd1E_desiredPulseDuration | appData.receiveDataBuffer[8];
                Cmd1E_Timer = Cmd1E_desiredPulseDuration; // put the initial time into the counter.
                TestModeState = RUNDEBUGMODE0x1E; // Stop everything and goto Debug mode in mode 0x1E.
                break;



                //Set Auto Test Settings
            case 0x1f:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x1f; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                //TODO Lot of stuff to do here*************************************
                break;

                //Set Punch Settings
            case 0x20:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x20; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                appCmd20Data.enable = appData.receiveDataBuffer[3]; // Enable / disable punch output. 00 = Disable, 01 = Punch Bad Labels.
                appCmd20Data.position = appData.receiveDataBuffer[4]; // Number of labels between the Antenna and the Punch Peripheral
                appCmd20Data.duration = appData.receiveDataBuffer[5]; // Duration in ms that Punch fires for.
                appCmd20Data.offset = appData.receiveDataBuffer[6]; // Offset in ms that Punch waits before firing after trigger is received.
                appCmd20Data.OffsetSel = appData.receiveDataBuffer[7]; // What causes the Punchoffset:  0 = 0x1D Punch offset Tics, 1 = 0x20 Punch offset mS

                if (appCmd20Data.enable) {
                    if (appCmd11Data.enable == 2) // When set to 2 then it means mark good labels.   We can not mark good labels and punch bad ones.
                        appData.transmitDataBuffer[3] = 0x56; // Return Status:  Indicate illegal mark and punch request
                }
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Label Width Settings
            case 0x21:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x21; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                Cmd21_LabelPitchTics = appData.receiveDataBuffer[3];  // The Nominal pitch of the labels in tics. Num tics from the leading edge of one label to the leading edge of the next label.
                Cmd21_NomLabelTics = appData.receiveDataBuffer[4];    // The Nominal tics that are expected per Label.  Leading edge of a label to the trailing edge of the same label.
                Cmd21_TicsPerInch = appData.receiveDataBuffer[5];     // The exact number of tics that will be sent for each 1.000 inch of Web length  (Typicaly set to 28))

                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Strap Test Settings
            case 0x2c:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x2c; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                //TODO Lot of stuff to do here*************************************
                break;

                //Get Test Settings
            case 0x30:
                appData.transmitDataBuffer[1] = 0x24; // LEN
                appData.transmitDataBuffer[2] = 0x30; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd10Data.testtype; //Test type
                appData.transmitDataBuffer[7] = appCmd10Data.tagclass; //Tag class
                appData.transmitDataBuffer[8] = appCmd10Data.antport; //Ant. Port
                appData.transmitDataBuffer[9] = (uint8_t) ((appCmd10Data.readpower >> 8) & 0x00ff); //Read power msb
                appData.transmitDataBuffer[10] = (uint8_t) (appCmd10Data.readpower & 0x00ff); //Read power lsb
                appData.transmitDataBuffer[11] = (uint8_t) ((appCmd10Data.readtimeout >> 8) & 0x00ff); //Read timeout msb
                appData.transmitDataBuffer[12] = (uint8_t) (appCmd10Data.readtimeout & 0x00ff); //Read timeout lsb
                appData.transmitDataBuffer[13] = (uint8_t) ((appCmd10Data.freq1 >> 24) & 0x000000ff); //Frequency 1[3]
                appData.transmitDataBuffer[14] = (uint8_t) ((appCmd10Data.freq1 >> 16) & 0x000000ff); //Frequency 1[2]
                appData.transmitDataBuffer[15] = (uint8_t) ((appCmd10Data.freq1 >> 8) & 0x000000ff); //Frequency 1[1]
                appData.transmitDataBuffer[16] = (uint8_t) (appCmd10Data.freq1 & 0x000000ff); //Frequency 1[0]
                appData.transmitDataBuffer[17] = (uint8_t) ((appCmd10Data.freq2 >> 24) & 0x000000ff); //Frequency 2[3]
                appData.transmitDataBuffer[18] = (uint8_t) ((appCmd10Data.freq2 >> 16) & 0x000000ff); //Frequency 2[2]
                appData.transmitDataBuffer[19] = (uint8_t) ((appCmd10Data.freq2 >> 8) & 0x000000ff); //Frequency 2[1]
                appData.transmitDataBuffer[20] = (uint8_t) (appCmd10Data.freq2 & 0x000000ff); //Frequency 2[0]
                appData.transmitDataBuffer[21] = (uint8_t) ((appCmd10Data.freq3 >> 24) & 0x000000ff); //Frequency 3[3]
                appData.transmitDataBuffer[22] = (uint8_t) ((appCmd10Data.freq3 >> 16) & 0x000000ff); //Frequency 3[2]
                appData.transmitDataBuffer[23] = (uint8_t) ((appCmd10Data.freq3 >> 8) & 0x000000ff); //Frequency 3[1]
                appData.transmitDataBuffer[24] = (uint8_t) (appCmd10Data.freq3 & 0x000000ff); //Frequency 3[0]
                appData.transmitDataBuffer[25] = (uint8_t) ((appCmd10Data.writepower >> 8) & 0x00ff); //Write power msb
                appData.transmitDataBuffer[26] = (uint8_t) (appCmd10Data.writepower & 0x00ff); //Write power lsb
                appData.transmitDataBuffer[27] = (uint8_t) ((appCmd10Data.writetimeout >> 8) & 0x00ff); //Write timeout msb
                appData.transmitDataBuffer[28] = (uint8_t) (appCmd10Data.writetimeout & 0x00ff); //Write timeout lsb
                appData.transmitDataBuffer[29] = appCmd10Data.writetype; //Write type
                appData.transmitDataBuffer[30] = appCmd10Data_startTagID[0]; //Start Tag ID
                appData.transmitDataBuffer[31] = appCmd10Data_startTagID[1]; //Start Tag ID
                appData.transmitDataBuffer[32] = appCmd10Data_startTagID[2]; //Start Tag ID
                appData.transmitDataBuffer[33] = appCmd10Data_startTagID[3]; //Start Tag ID
                appData.transmitDataBuffer[34] = appCmd10Data_startTagID[4]; //Start Tag ID
                appData.transmitDataBuffer[35] = appCmd10Data_startTagID[5]; //Start Tag ID
                appData.transmitDataBuffer[36] = appCmd10Data_startTagID[6]; //Start Tag ID
                appData.transmitDataBuffer[37] = appCmd10Data_startTagID[7]; //Start Tag ID
                appData.transmitDataBuffer[38] = appCmd10Data_startTagID[8]; //Start Tag ID
                appData.transmitDataBuffer[39] = appCmd10Data_startTagID[9]; //Start Tag ID
                appData.transmitDataBuffer[40] = appCmd10Data_startTagID[10]; //Start Tag ID
                appData.transmitDataBuffer[41] = appCmd10Data_startTagID[11]; //Start Tag ID
                appData.transmitDataBuffer[42] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Marker Settings
            case 0x31:
                appData.transmitDataBuffer[1] = 0x04; // LEN
                appData.transmitDataBuffer[2] = 0x31; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd11Data.enable; // enable
                appData.transmitDataBuffer[7] = appCmd11Data.position; // position
                appData.transmitDataBuffer[8] = appCmd11Data.duration; // duration
                appData.transmitDataBuffer[9] = appCmd11Data.offset; // offset
                appData.transmitDataBuffer[10] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Trigger Input Settings
            case 0x32:
                appData.transmitDataBuffer[1] = 0x06; // LEN
                appData.transmitDataBuffer[2] = 0x32; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd12Data.Enable; // Enable   0 = Disabled, 1 = Enabled
                appData.transmitDataBuffer[7] = appCmd12Data.edgetype; // edge type
                appData.transmitDataBuffer[8] = appCmd12Data.debounce; // debounce
                appData.transmitDataBuffer[9] = appCmd12Data.deaftics; // We wait at least this many Encoder TICS before accepting another New Label detector Trigger.
                appData.transmitDataBuffer[10] = appCmd12Data.testoffset; // test offset
                appData.transmitDataBuffer[11] = appCmd12Data.triggeroffset; // trigger offset
                appData.transmitDataBuffer[12] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Trigger Output Settings
            case 0x33:
                appData.transmitDataBuffer[1] = 0x03; // LEN
                appData.transmitDataBuffer[2] = 0x33; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd13Data.enable; // enable
                appData.transmitDataBuffer[7] = appCmd13Data.edgetype; // edge type
                appData.transmitDataBuffer[8] = appCmd13Data.duration; // duration
                appData.transmitDataBuffer[9] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Tester Settings
            case 0x34:
                appData.transmitDataBuffer[1] = 0x02; // LEN
                appData.transmitDataBuffer[2] = 0x34; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd14Data.enable; // enable
                appData.transmitDataBuffer[7] = appCmd14Data.position; // position
                appData.transmitDataBuffer[8] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Test Statistics
            case 0x35:
                appData.transmitDataBuffer[1] = 0x0c; // LEN
                appData.transmitDataBuffer[2] = 0x35; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = (uint8_t) ((appCmd15Data.testpasscount >> 24) & 0x000000ff); //Test Pass Count D3
                appData.transmitDataBuffer[7] = (uint8_t) ((appCmd15Data.testpasscount >> 16) & 0x000000ff); //Test Pass Count D2
                appData.transmitDataBuffer[8] = (uint8_t) ((appCmd15Data.testpasscount >> 8) & 0x000000ff); //Test Pass Count D1
                appData.transmitDataBuffer[9] = (uint8_t) (appCmd15Data.testpasscount & 0x000000ff); //Test Pass Count D0
                appData.transmitDataBuffer[10] = (uint8_t) ((appCmd15Data.testfailcount >> 24) & 0x000000ff); //Test Fail Count D3
                appData.transmitDataBuffer[11] = (uint8_t) ((appCmd15Data.testfailcount >> 16) & 0x000000ff); //Test Fail Count D2
                appData.transmitDataBuffer[12] = (uint8_t) ((appCmd15Data.testfailcount >> 8) & 0x000000ff); //Test Fail Count D1
                appData.transmitDataBuffer[13] = (uint8_t) (appCmd15Data.testfailcount & 0x000000ff); //Test Fail Count D0
                appData.transmitDataBuffer[14] = (uint8_t) ((appCmd15Data.triggercount >> 24) & 0x000000ff); //Trigger Count D3
                appData.transmitDataBuffer[15] = (uint8_t) ((appCmd15Data.triggercount >> 16) & 0x000000ff); //Trigger Count D2
                appData.transmitDataBuffer[16] = (uint8_t) ((appCmd15Data.triggercount >> 8) & 0x000000ff); //Trigger Count D1
                appData.transmitDataBuffer[17] = (uint8_t) (appCmd15Data.triggercount & 0x000000ff); //Trigger Count D0
                appData.transmitDataBuffer[18] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Bulk Write Settings
            case 0x36:
                appData.transmitDataBuffer[1] = 0x17; // LEN
                appData.transmitDataBuffer[2] = 0x36; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd16Data.antport; //Ant port
                appData.transmitDataBuffer[7] = (uint8_t) ((appCmd16Data.writepower >> 8) & 0x00ff); //Write power msb
                appData.transmitDataBuffer[8] = (uint8_t) (appCmd16Data.writepower & 0x00ff); //Write power lsb
                appData.transmitDataBuffer[9] = (uint8_t) ((appCmd16Data.writetimeout >> 8) & 0x00ff); //Write timeout msb
                appData.transmitDataBuffer[10] = (uint8_t) (appCmd16Data.writetimeout & 0x00ff); //Write timeout msb
                appData.transmitDataBuffer[11] = (uint8_t) ((appCmd16Data.frequency >> 24) & 0x000000ff); //Frequency D3
                appData.transmitDataBuffer[12] = (uint8_t) ((appCmd16Data.frequency >> 16) & 0x000000ff); //Frequency D2
                appData.transmitDataBuffer[13] = (uint8_t) ((appCmd16Data.frequency >> 8) & 0x000000ff); //Frequency D1
                appData.transmitDataBuffer[14] = (uint8_t) (appCmd16Data.frequency & 0x000000ff); //Frequency D0
                appData.transmitDataBuffer[15] = appCmd16Data.count; //count
                appData.transmitDataBuffer[16] = appCmd16Data.writetype; //write type
                appData.transmitDataBuffer[17] = appCmd16Data.bulkTagID[0]; //tag id
                appData.transmitDataBuffer[18] = appCmd16Data.bulkTagID[1]; //tag id
                appData.transmitDataBuffer[19] = appCmd16Data.bulkTagID[2]; //tag id
                appData.transmitDataBuffer[20] = appCmd16Data.bulkTagID[3]; //tag id
                appData.transmitDataBuffer[21] = appCmd16Data.bulkTagID[4]; //tag id
                appData.transmitDataBuffer[22] = appCmd16Data.bulkTagID[5]; //tag id
                appData.transmitDataBuffer[23] = appCmd16Data.bulkTagID[6]; //tag id
                appData.transmitDataBuffer[24] = appCmd16Data.bulkTagID[7]; //tag id
                appData.transmitDataBuffer[25] = appCmd16Data.bulkTagID[8]; //tag id
                appData.transmitDataBuffer[26] = appCmd16Data.bulkTagID[9]; //tag id
                appData.transmitDataBuffer[27] = appCmd16Data.bulkTagID[10]; //tag id
                appData.transmitDataBuffer[28] = appCmd16Data.bulkTagID[11]; //tag id
                appData.transmitDataBuffer[29] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get Antenna Settings
            case 0x37:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x37; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Ant. port
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get Sensitivity Test Settings
            case 0x38:
                appData.transmitDataBuffer[1] = 0x10; // LEN
                appData.transmitDataBuffer[2] = 0x38; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Read or write
                appData.transmitDataBuffer[7] = 2; // Ant port
                appData.transmitDataBuffer[8] = 3; // Freq[3]
                appData.transmitDataBuffer[9] = 4; // Freq[2]
                appData.transmitDataBuffer[10] = 5; // Freq[1]
                appData.transmitDataBuffer[11] = 6; // Freq[0]
                appData.transmitDataBuffer[12] = 7; // Min pwr D1
                appData.transmitDataBuffer[13] = 8; // Min pwr D0
                appData.transmitDataBuffer[14] = 9; // Max pwr D1
                appData.transmitDataBuffer[15] = 10; // Max pwr D0
                appData.transmitDataBuffer[16] = 11; // Search depth
                appData.transmitDataBuffer[17] = 12; // Timeout[1]
                appData.transmitDataBuffer[18] = 1; // Timeout[0]
                appData.transmitDataBuffer[19] = 2; // Pass Threshold[1]
                appData.transmitDataBuffer[20] = 3; // Pass Threshold[0]
                appData.transmitDataBuffer[21] = 4; // Options
                appData.transmitDataBuffer[22] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get TID Test Settings
            case 0x39:
                appData.transmitDataBuffer[1] = 0x09; // LEN
                appData.transmitDataBuffer[2] = 0x39; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Options
                appData.transmitDataBuffer[7] = 2; // Read timeout[1]
                appData.transmitDataBuffer[8] = 3; // Read timeout[0]
                appData.transmitDataBuffer[9] = 4; // Interval[1]
                appData.transmitDataBuffer[10] = 5; // Interval[0]
                appData.transmitDataBuffer[11] = 7; // TID[3]
                appData.transmitDataBuffer[12] = 8; // TID[2]
                appData.transmitDataBuffer[13] = 9; // TID[1]
                appData.transmitDataBuffer[14] = 10; // TID[0]
                appData.transmitDataBuffer[15] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Tag ID Filter Settings
            case 0x3a:
                appData.transmitDataBuffer[1] = 0x10; // LEN
                appData.transmitDataBuffer[2] = 0x3a; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = Cmd1A_Options; //Options
                appData.transmitDataBuffer[7] = Cmd1A_NibbleEnables >> 16; //Nibble Enable[2]
                appData.transmitDataBuffer[8] = Cmd1A_NibbleEnables >> 8; //Nibble Enable[1]
                appData.transmitDataBuffer[9] = Cmd1A_NibbleEnables; //Nibble Enable[0]
                appData.transmitDataBuffer[10] = Cmd1A_TagIdFilter[1]; //Tag ID Filter[11]
                appData.transmitDataBuffer[11] = Cmd1A_TagIdFilter[2]; //Tag ID Filter[10]
                appData.transmitDataBuffer[12] = Cmd1A_TagIdFilter[3]; //Tag ID Filter[9]
                appData.transmitDataBuffer[13] = Cmd1A_TagIdFilter[4]; //Tag ID Filter[8]
                appData.transmitDataBuffer[14] = Cmd1A_TagIdFilter[5]; //Tag ID Filter[7]
                appData.transmitDataBuffer[15] = Cmd1A_TagIdFilter[6]; //Tag ID Filter[6]
                appData.transmitDataBuffer[16] = Cmd1A_TagIdFilter[7]; //Tag ID Filter[5]
                appData.transmitDataBuffer[17] = Cmd1A_TagIdFilter[8]; //Tag ID Filter[4]
                appData.transmitDataBuffer[18] = Cmd1A_TagIdFilter[9]; //Tag ID Filter[3]
                appData.transmitDataBuffer[19] = Cmd1A_TagIdFilter[10]; //Tag ID Filter[2]
                appData.transmitDataBuffer[20] = Cmd1A_TagIdFilter[11]; //Tag ID Filter[1]
                appData.transmitDataBuffer[21] = Cmd1A_TagIdFilter[12]; //Tag ID Filter[0]
                appData.transmitDataBuffer[22] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Sensitivity TestTag Kill Settings
            case 0x3b:
                appData.transmitDataBuffer[1] = 0x0e; // LEN
                appData.transmitDataBuffer[2] = 0x3b; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Options
                appData.transmitDataBuffer[7] = 2; // Ant port
                appData.transmitDataBuffer[8] = 3; // KillWritePwr[1]
                appData.transmitDataBuffer[9] = 4; // KillWritePwr[0]
                appData.transmitDataBuffer[10] = 5; // KillTimeout[1]
                appData.transmitDataBuffer[11] = 6; // KillTimeout[0]
                appData.transmitDataBuffer[12] = 7; // Freq[3]
                appData.transmitDataBuffer[13] = 8; // Freq[2]
                appData.transmitDataBuffer[14] = 9; // Freq[1]
                appData.transmitDataBuffer[15] = 10; // Freq[0]
                appData.transmitDataBuffer[16] = 11; // Password[3]
                appData.transmitDataBuffer[17] = 12; // Password[2]
                appData.transmitDataBuffer[18] = 1; // Password[1]
                appData.transmitDataBuffer[19] = 2; // Password[0]
                appData.transmitDataBuffer[20] = CheckSum(&appData.transmitDataBuffer[1]);
                break;


                //Get Aux In Settings
            case 0x3c: // Echos data from the 0x1C command
                appData.transmitDataBuffer[1] = 0x06; // LEN
                appData.transmitDataBuffer[2] = 0x3c; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = EncoderStyle; // Function    0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
                appData.transmitDataBuffer[7] = 0; // Option 1
                appData.transmitDataBuffer[8] = 0; // Option 2
                appData.transmitDataBuffer[9] = EncoderEdgePolarity; // Edge type
                appData.transmitDataBuffer[10] = 0; // Debounce    // TODO Unsupported at this time.
                appData.transmitDataBuffer[11] = EncoderDeafTimeReload; // Deaf time master value.
                appData.transmitDataBuffer[12] = CheckSum(&appData.transmitDataBuffer[1]);
                break;


                //Get Encoder Settings
            case 0x3d:
                appData.transmitDataBuffer[1] = 0x0c; // LEN
                appData.transmitDataBuffer[2] = 0x3d; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = (uint8_t) ((appCmd1dData.triggerfiltermin >> 8) & 0x00ff); // Trigger Filter Min[1]
                appData.transmitDataBuffer[7] = (uint8_t) (appCmd1dData.triggerfiltermin & 0x00ff); // Trigger Filter Min[0]
                appData.transmitDataBuffer[8] = (uint8_t) ((appCmd1dData.EncoderTicoffset >> 8) & 0x00ff); // Tester Encoder TIC Offset[1]
                appData.transmitDataBuffer[9] = (uint8_t) (appCmd1dData.EncoderTicoffset & 0x00ff); // Tester Encoder TIC Offset[0]
                appData.transmitDataBuffer[10] = (uint8_t) ((appCmd1dData.markeroffset >> 8) & 0x00ff); // Marker Offset[1]
                appData.transmitDataBuffer[11] = (uint8_t) (appCmd1dData.markeroffset & 0x00ff); // Marker Offset[0]
                appData.transmitDataBuffer[12] = (uint8_t) ((appCmd1dData.punchoffset >> 8) & 0x00ff); // Punch Offset[1]
                appData.transmitDataBuffer[13] = (uint8_t) (appCmd1dData.punchoffset & 0x00ff); // Punch Offset[0]
                appData.transmitDataBuffer[14] = (uint8_t) ((appCmd1dData.punchflight >> 8) & 0x00ff); // Punch Flight[1]
                appData.transmitDataBuffer[15] = (uint8_t) (appCmd1dData.punchflight & 0x00ff); // Punch Flight[1]
                appData.transmitDataBuffer[16] = (uint8_t) ((appCmd1dData.triggerfiltermax >> 8) & 0x00ff); // Trigger Filter Max[1]
                appData.transmitDataBuffer[17] = (uint8_t) (appCmd1dData.triggerfiltermax & 0x00ff); // Trigger Filter Max[0]
                appData.transmitDataBuffer[18] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Punch Settings
            case 0x40:
                appData.transmitDataBuffer[1] = 0x05;                       // LEN
                appData.transmitDataBuffer[2] = 0x40;                       // CMD
                appData.transmitDataBuffer[3] = 0x00;                       // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd20Data.enable;        // enable
                appData.transmitDataBuffer[7] = appCmd20Data.position;      // position
                appData.transmitDataBuffer[8] = appCmd20Data.duration;      // duration
                appData.transmitDataBuffer[9] = appCmd20Data.offset;        // offset
                appData.transmitDataBuffer[10] = appCmd20Data.OffsetSel;    // offset Selection
                appData.transmitDataBuffer[11] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Label Width Settings
            case 0x41:
                appData.transmitDataBuffer[1] = 0x03; // LEN
                appData.transmitDataBuffer[2] = 0x41; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = Cmd21_LabelPitchTics;
                appData.transmitDataBuffer[7] = Cmd21_NomLabelTics;
                appData.transmitDataBuffer[8] = Cmd21_TicsPerInch;                
                appData.transmitDataBuffer[9] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Strap Test Settings
            case 0x4c:
                appData.transmitDataBuffer[1] = 0x0e; // LEN
                appData.transmitDataBuffer[2] = 0x4c; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // StartFreq[1]
                appData.transmitDataBuffer[7] = 2; // StartFreq[0]
                appData.transmitDataBuffer[8] = 3; // StopFreq[1]
                appData.transmitDataBuffer[9] = 4; // StopFreq[0]
                appData.transmitDataBuffer[10] = 5; // StepFreq[1]
                appData.transmitDataBuffer[11] = 6; // StepFreq[0]
                appData.transmitDataBuffer[12] = 7; // Offset F.
                appData.transmitDataBuffer[13] = 8; // Atten.
                appData.transmitDataBuffer[14] = 9; // MinPass[1]
                appData.transmitDataBuffer[15] = 10; // MinPass[0]
                appData.transmitDataBuffer[16] = 11; // MaxPass[1]
                appData.transmitDataBuffer[17] = 12; // MaxPass[0]
                appData.transmitDataBuffer[18] = 11; // PassAmplitude[1]
                appData.transmitDataBuffer[19] = 12; // PassAmplitude[0]
                appData.transmitDataBuffer[20] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Start Testing
            case 0x50:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x50; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                sprintf(Uart3TxBuf, "RO3\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf); // Put TR-65 into CW output mode
                GTestInProcessState = 0;             // Reset flag that warns the HOST if we get a trigger when a label is still in process.
                MarkPunchActive = 1;                 // The pass/fail indication will be stuffed into the MarkPunch array when set.  Typically reset (0) for Firmware triggered tests.
                PlayPause = 1;                       // 0 = pause.  1 = Play.
                TestModeState = WAITFOR0X10TRIG;     // Wait for a new label to test
                break;

                //Stop Testing
            case 0x51:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x51; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                sprintf(Uart3TxBuf, "RO0\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf); // Inhibit RF power on TR-65
                MarkPunchActive = 0;                  // The pass/fail indication will be stuffed into the MarkPunch array when set.  Typically reset (0) for Firmware triggered tests.
                PlayPause = 0;                        // 0 = pause.  1 = Play.
                break;

                //Test (0x10 Firmware Trigger))
            case 0x52:
                appData.transmitDataBuffer[1] = 0x00; // LEN    // Data is returned with E3
                appData.transmitDataBuffer[2] = 0x52; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                    status = 0x00;                              // Set status: 00 OK, 03 Unsupported OR Not yet fully supported Command, 2C Hardware Unavailable
                    MarkPunchActive = 0;                        // The pass/fail indication will be stuffed into the MarkPunch array when set.  Typically reset (0) for Firmware triggered tests.
                    PlayPause = 1;                              // 0 = pause.  1 = Play.
                    //FlushLabelData();                         // Delete the EPC and TID data from the last read.
                    OldTestModeState = RUNTEST0X10;
                    //Active0x10Tests = appCmd10Data.testtype;    // intitalized each time a new label is detected.  the bits are reset as tests complete.  When 00 then all the tests are done.
                    // TODO Handle possible trigger request while test is already in progress.
                    TriggertheTest();  // We did the 0x10 test setup, we just got the 0x52, now we trigger and wait for the read.
                          
                break;

                //Mark
            case 0x53:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x53; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                MarkActiveTimer = appCmd11Data.duration; // The number of mS that the Mark peripheral is to be energized from Command 0x11
                Mark(1); // Pass in a 0 to untrigger and a 1 to trigger the mark peripheral.
                break;

                //Sensitivity test Firmware Trigger.   Triggers test 0x18
            case 0x54:
                appData.transmitDataBuffer[1] = 0x06; // LEN
                appData.transmitDataBuffer[2] = 0x54; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appCmd15Data.triggercount >> 24; // Trigger Count[3]
                appData.transmitDataBuffer[7] = appCmd15Data.triggercount >> 16; // Trigger Count[2]
                appData.transmitDataBuffer[8] = appCmd15Data.triggercount >> 8;  // Trigger Count[1]
                appData.transmitDataBuffer[9] = appCmd15Data.triggercount;       // Trigger Count[0]
                appData.transmitDataBuffer[10] = LabelEncoderTics >> 8;          // Encoder Count[1]    // Bottom 16 bits of the 32 bit value are returned here.
                appData.transmitDataBuffer[11] = LabelEncoderTics;               // Encoder Count[0]
                MainTestStatus = 0;                    // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                LabelEncoderTics = 0;                  // Zero counter
                if(TestModeState == TESTMODEIDLE)      // if not running any other test then trigger the 
                {   
                    TestModeState = RUNSENSITIVITYTEST;    // start a new test.
                    CalPacer = 0;                          // Decremented in the 1mS ISR
                    Test0x18State = 0;                     // Start at the beginning of the new test.
                    appData.transmitDataBuffer[3] = 0x59;  // illegal sensitivity test request.
                }
                appData.transmitDataBuffer[12] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Trigger Output
            case 0x55:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x55; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Punch
            case 0x56:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x56; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                PunchActiveTimer = appCmd20Data.duration; // The number of mS that the Punch peripheral is to be energized from Command 0x20
                Punch(1); // Pass in a 0 to retract the punch and a 1 to extend the punch.
                break;

                //Strap Test
            case 0x5c:
                appData.transmitDataBuffer[1] = 0x05; // LEN
                appData.transmitDataBuffer[2] = 0x5c; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Test Status
                appData.transmitDataBuffer[7] = 2; // Measured Frequency[1]
                appData.transmitDataBuffer[8] = 3; // Measured Frequency[0]
                appData.transmitDataBuffer[9] = 4; // Measured Amplitude[1]
                appData.transmitDataBuffer[10] = 5; // Measured Amplitude[0]
                appData.transmitDataBuffer[11] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Program PLL
            case 0x60:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x60; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Strap Response
            case 0x61:
                appData.transmitDataBuffer[1] = 0x02; // LEN
                appData.transmitDataBuffer[2] = 0x61; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Measured Amplitude[1]
                appData.transmitDataBuffer[7] = 2; // Measured Amplitude[0]
                appData.transmitDataBuffer[8] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Hardware Version
            case 0x62:
                appData.transmitDataBuffer[1] = 0x08; // LEN
                appData.transmitDataBuffer[2] = 0x62; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0; // Check Byte[1]
                appData.transmitDataBuffer[7] = 0; // Check Byte[0]
                appData.transmitDataBuffer[8] = 1; // Board Type
                appData.transmitDataBuffer[9] = 'A'; // Board Revision
                appData.transmitDataBuffer[10] = '1'; // ID4
                appData.transmitDataBuffer[11] = '0'; // ID3
                appData.transmitDataBuffer[12] = '0'; // ID2
                appData.transmitDataBuffer[13] = '0'; // ID1
                appData.transmitDataBuffer[14] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Fault
            case 0x63:
                lastfault = appData.receiveDataBuffer[3]; // Bring in the Pseudo fault from the Host
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x63; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Calibration Status
            case 0x64:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x64; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Cal state
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Calibration Status
            case 0x65:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x65; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Cal state
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //TestB
            case 0x66:
                appData.transmitDataBuffer[1] = 0x18; // LEN
                appData.transmitDataBuffer[2] = 0x66; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Test Type
                appData.transmitDataBuffer[7] = 2; // Test Status
                appData.transmitDataBuffer[8] = 3; // Test Count[3]
                appData.transmitDataBuffer[9] = 4; // Test Count[2]
                appData.transmitDataBuffer[10] = 5; // Test Count[1]
                appData.transmitDataBuffer[11] = 6; // Test Count[0]
                appData.transmitDataBuffer[12] = 7; // Tag ID
                appData.transmitDataBuffer[13] = 8; // Tag ID
                appData.transmitDataBuffer[14] = 9; // Tag ID
                appData.transmitDataBuffer[15] = 10; // Tag ID
                appData.transmitDataBuffer[16] = 11; // Tag ID
                appData.transmitDataBuffer[17] = 12; // Tag ID
                appData.transmitDataBuffer[18] = 1; // Tag ID
                appData.transmitDataBuffer[19] = 2; // Tag ID
                appData.transmitDataBuffer[20] = 3; // Tag ID
                appData.transmitDataBuffer[21] = 4; // Tag ID
                appData.transmitDataBuffer[22] = 3; // Tag ID
                appData.transmitDataBuffer[23] = 4; // Tag ID
                appData.transmitDataBuffer[24] = 5; // Sensitivity[1]
                appData.transmitDataBuffer[25] = 6; // Sensitivity[0]
                appData.transmitDataBuffer[26] = 5; // TID[3]
                appData.transmitDataBuffer[27] = 6; // TID[2]
                appData.transmitDataBuffer[28] = 5; // TID[1]
                appData.transmitDataBuffer[29] = 6; // TID[0]
                appData.transmitDataBuffer[30] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Digital I/O
            case 0x68:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x68; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);

                if (appData.receiveDataBuffer[3] & 0x40) // (MSB) Reserved, Aux, Punch, Marker, Reserved, Reserved, Reserved, Reserved
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH);
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW);

                if (appData.receiveDataBuffer[3] & 0x20)
                {
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, HIGH);
                        SetFrontPanelLEDs(1, 2);         // Blink the Punch LED.
                }
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, LOW);

                if (appData.receiveDataBuffer[3] & 0x10)
                {
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, HIGH);
                    SetFrontPanelLEDs(2, 2);             // Blink the Mark LED.
                }
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, LOW);

                break;

                //Get Digital I/O
            case 0x69:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x69; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                JustATemp8 = 0;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, ENCODER_B))
                    JustATemp8 |= 0x01;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, ENCODER_A))
                    JustATemp8 |= 0x02;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, BANNER_1))
                    JustATemp8 |= 0x04;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, BANNER_0))
                    JustATemp8 |= 0x08;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, MARK))
                    JustATemp8 |= 0x10;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_F, PUNCH))
                    JustATemp8 |= 0x20;
                if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_F, AUX))
                    JustATemp8 |= 0x40;
                appData.transmitDataBuffer[6] = JustATemp8; // IO Value
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Antenna Frequency Power
            case 0x6a:

                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x6a; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable

                appCmd6AData.freq1 = ((uint32_t) appData.receiveDataBuffer[5] << 24) & 0xff000000; // Read frequency
                appCmd6AData.freq1 = (appCmd6AData.freq1 | (((uint32_t) appData.receiveDataBuffer[6] << 16) & 0x00ff0000)) & 0xffff0000;
                appCmd6AData.freq1 = (appCmd6AData.freq1 | (((uint32_t) appData.receiveDataBuffer[7] << 8) & 0x0000ff00)) & 0xffffff00;
                appCmd6AData.freq1 = appCmd6AData.freq1 | (((uint32_t) appData.receiveDataBuffer[8]) & 0x000000ff);

                appCmd6AData.readpower = ((int16_t) appData.receiveDataBuffer[9] << 8) & 0xff00; // Read power
                appCmd6AData.readpower = (int16_t) (appCmd6AData.readpower | appData.receiveDataBuffer[10]); // CentidB -25 to +30dB.  Add 100dB and multiply by 10.    -12.3dB is sent as 877, +22.4dB sent as 1224.

                if (appData.receiveDataBuffer[3]) // 0 for Read power only.   1 for both Read and Write power.
                    appCmd6AData.writepower = appCmd6AData.readpower;

                if (appData.receiveDataBuffer[4] != 1) // We support antenna port #1 only.
                    status = 0x31;

                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                //TestModeState = INITDEBUGMODE0x6A;                                                               // set the tester into a known condition for this mode.
                Test0x6AState = 0; // All the parts of getting test 0x6A setup.
                break;

                //Get Transmit Power Status
            case 0x6c:
                appData.transmitDataBuffer[1] = 0x1b; // LEN
                appData.transmitDataBuffer[2] = 0x6c; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Antenna
                appData.transmitDataBuffer[7] = 2; // Difference Threshold[1]
                appData.transmitDataBuffer[8] = 3; // Difference Threshold[0]
                appData.transmitDataBuffer[9] = 4; // Stored1[1]
                appData.transmitDataBuffer[10] = 5; // Stored1[0]
                appData.transmitDataBuffer[11] = 6; // Stored2[1]
                appData.transmitDataBuffer[12] = 7; // Stored2[0]
                appData.transmitDataBuffer[13] = 8; // Stored3[1]
                appData.transmitDataBuffer[14] = 9; // Stored3[0]
                appData.transmitDataBuffer[15] = 10; // Stored4[1]
                appData.transmitDataBuffer[16] = 11; // Stored4[0]
                appData.transmitDataBuffer[17] = 12; // Stored5[1]
                appData.transmitDataBuffer[18] = 1; // Stored5[0]
                appData.transmitDataBuffer[19] = 2; // Stored6[1]
                appData.transmitDataBuffer[20] = 3; // Stored6[0]
                appData.transmitDataBuffer[21] = 4; // Measured1[1]
                appData.transmitDataBuffer[22] = 3; // Measured1[0]
                appData.transmitDataBuffer[23] = 4; // Measured2[1]
                appData.transmitDataBuffer[24] = 5; // Measured2[0]
                appData.transmitDataBuffer[25] = 6; // Measured3[1]
                appData.transmitDataBuffer[26] = 5; // Measured3[0]
                appData.transmitDataBuffer[27] = 6; // Measured4[1]
                appData.transmitDataBuffer[28] = 5; // Measured4[0]
                appData.transmitDataBuffer[29] = 6; // Measured5[1]
                appData.transmitDataBuffer[30] = 5; // Measured5[0]
                appData.transmitDataBuffer[31] = 6; // Measured6[1]
                appData.transmitDataBuffer[32] = 5; // Measured6[0]
                appData.transmitDataBuffer[33] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Antenna Port Status
            case 0x6d:
                appData.transmitDataBuffer[1] = 0x26; // LEN
                appData.transmitDataBuffer[2] = 0x6d; // CMD
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Antenna
                appData.transmitDataBuffer[7] = 2; // Test Mode
                appData.transmitDataBuffer[8] = 3; // Stored1[1]
                appData.transmitDataBuffer[9] = 4; // Stored1[0]
                appData.transmitDataBuffer[10] = 5; // Stored2[1]
                appData.transmitDataBuffer[11] = 6; // Stored2[0]
                appData.transmitDataBuffer[12] = 7; // Stored3[1]
                appData.transmitDataBuffer[13] = 8; // Stored3[0]
                appData.transmitDataBuffer[14] = 9; // Stored4[1]
                appData.transmitDataBuffer[15] = 10; // Stored4[0]
                appData.transmitDataBuffer[16] = 11; // Stored5[1]
                appData.transmitDataBuffer[17] = 12; // Stored5[0]
                appData.transmitDataBuffer[18] = 1; // Stored6[1]
                appData.transmitDataBuffer[19] = 2; // Stored6[0]
                appData.transmitDataBuffer[20] = 3; // Stored7[1]
                appData.transmitDataBuffer[21] = 4; // Stored7[0]
                appData.transmitDataBuffer[22] = 3; // Stored8[1]
                appData.transmitDataBuffer[23] = 4; // Stored8[0]
                appData.transmitDataBuffer[24] = 5; // Stored9[1]
                appData.transmitDataBuffer[25] = 6; // Stored9[0]
                appData.transmitDataBuffer[26] = 5; // Stored10[1]
                appData.transmitDataBuffer[27] = 6; // Stored10[0]
                appData.transmitDataBuffer[28] = 5; // Stored11[1]
                appData.transmitDataBuffer[29] = 6; // Stored11[0]
                appData.transmitDataBuffer[30] = 5; // Stored12[1]
                appData.transmitDataBuffer[31] = 6; // Stored12[0]
                appData.transmitDataBuffer[32] = 5; // Measured1[1]
                appData.transmitDataBuffer[33] = 6; // Measured1[0]
                appData.transmitDataBuffer[34] = 5; // Measured2[1]
                appData.transmitDataBuffer[35] = 6; // Measured2[0]
                appData.transmitDataBuffer[36] = 5; // Measured3[1]
                appData.transmitDataBuffer[37] = 6; // Measured3[0]
                appData.transmitDataBuffer[38] = 5; // Measured4[1]
                appData.transmitDataBuffer[39] = 6; // Measured4[0]
                appData.transmitDataBuffer[40] = 5; // Measured5[1]
                appData.transmitDataBuffer[41] = 6; // Measured5[0]
                appData.transmitDataBuffer[42] = 5; // Measured6[1]
                appData.transmitDataBuffer[43] = 5; // Measured6[0]
                appData.transmitDataBuffer[44] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Sensitivity
            case 0x6f:
                appData.transmitDataBuffer[1] = 0x02; // LEN                // This is an unsolicited TX message
                appData.transmitDataBuffer[2] = 0x6f; // CMD                // It should probably not be here.
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 1; // Sensitivity[1]
                appData.transmitDataBuffer[7] = 2; // Sensitivity[0]
                appData.transmitDataBuffer[8] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get dip switch setting
            case 0x70:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x70;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = ReadDipSwitch();
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Get MAC address
            case 0x71:

                appData.transmitDataBuffer[1] = 0x07; // Len
                appData.transmitDataBuffer[2] = 0x71; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 6; // Len 2.  Should always be 6 for now.
                appData.transmitDataBuffer[7] = MacArray[5]; // Addr5
                appData.transmitDataBuffer[8] = MacArray[4]; // Addr4
                appData.transmitDataBuffer[9] = MacArray[3]; // Addr3
                appData.transmitDataBuffer[10] = MacArray[2]; // Addr2
                appData.transmitDataBuffer[11] = MacArray[1]; // Addr1
                appData.transmitDataBuffer[12] = MacArray[0]; // Addr0
                appData.transmitDataBuffer[13] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set barcode reader power on/off
            case 0x72:

                appData.transmitDataBuffer[1] = 0x01; // Len
                appData.transmitDataBuffer[2] = 0x72; // CMD
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                //if(appData.receiveDataBuffer[3] == 1)           // Set barcode power accordingly
                //{
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_F, JADAK_ENABLE, REGULATOR_ON );  // Turn on regulator to the Jadak
                //}
                //else
                //{
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_F, JADAK_ENABLE, REGULATOR_OFF ); // Turn off regulator to the Jadak
                //}
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set RFID reader power on/off
            case 0x73:

                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x73;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off

                //Set RFID power accordingly
                if (appData.receiveDataBuffer[3] == 1) {
                    //Turn on regulator to the RFID
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, RFID_ENABLE, REGULATOR_ON);
                } else {
                    //Turn off regulator to the RFID
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, RFID_ENABLE, REGULATOR_OFF);
                }

                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set camera reader power on/off
            case 0x74:

                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x74;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off

                if (appData.receiveDataBuffer[3] == 1) // Set camera power accordingly
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, CAMERA_ENABLE, REGULATOR_ON); // Turn on regulator to the camera
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, CAMERA_ENABLE, REGULATOR_OFF); // Turn off regulator to the camera

                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set motor enable on/off
            case 0x75:

                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x75;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);

                break;

                //Set motor speed
            case 0x76:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x76;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; // speed
                //glbmotorpower = appData.receiveDataBuffer[3];                             // Update the global motor speed
                //LED_Motor_Set(LED8, LEDOFF, MOTOR_DATA, appData.receiveDataBuffer[3]);    // Set motor speed to requested value
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Twinkle LED's     Send their current status then twinkle them.
            case 0x77:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x77;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                JustATemp8 = 0;
                if (LED1) JustATemp8 |= 0x01;
                if (LED2) JustATemp8 |= 0x02;
                if (LED3) JustATemp8 |= 0x04;
                if (LED4) JustATemp8 |= 0x08;
                if (LED5) JustATemp8 |= 0x10;
                if (LED6) JustATemp8 |= 0x20;
                if (LED7) JustATemp8 |= 0x40;
                if (LED8) JustATemp8 |= 0x80;
                appData.transmitDataBuffer[6] = JustATemp8; // return current led state
                TwinkleLEDs(); // Twinkle LED's; do a light show
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set USB to spare serial port monitoring on/off
            case 0x78:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x78;
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                // TODO Set spare serial port monitoring flag to receiveDataBuffer[3] here]
                break;

                //Set camera trigger on/off
            case 0x79:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x79;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                if (appData.receiveDataBuffer[3] == 1) // Set trigger accordingly
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, CAM_TRIG, HIGH); // Trigger high
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, CAM_TRIG, LOW); // Trigger low
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set camera teach on/off
            case 0x7a:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x7a;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                if (appData.receiveDataBuffer[3] == 1) // Set teach accordingly
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, CAM_TEACH, HIGH); // Teach high
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, CAM_TEACH, LOW); // Teach low
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get camera outputs
            case 0x7b:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x7b;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = GetCameraOutputs(); //camera gpio
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get WiFi MAC address
            case 0x7c:
                appData.transmitDataBuffer[1] = 0x07;
                appData.transmitDataBuffer[2] = 0x7c;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0x06; // Len2
                appData.transmitDataBuffer[7] = 0xff; // Addr5
                appData.transmitDataBuffer[8] = 0xee; // Addr4
                appData.transmitDataBuffer[9] = 0xdd; // Addr3
                appData.transmitDataBuffer[10] = 0xcc; // Addr2
                appData.transmitDataBuffer[11] = 0xbb; // Addr1
                appData.transmitDataBuffer[12] = 0xaa; // Addr0
                appData.transmitDataBuffer[13] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get WiFi Network ID
            case 0x7d:

                appData.transmitDataBuffer[1] = 0x21;
                appData.transmitDataBuffer[2] = 0x7d;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0x20; //Len2
                appData.transmitDataBuffer[7] = 0xff; //char31
                appData.transmitDataBuffer[8] = 0xee; //char30
                appData.transmitDataBuffer[9] = 0xdd; //char29
                appData.transmitDataBuffer[10] = 0xcc; //char28
                appData.transmitDataBuffer[11] = 0xbb; //char27
                appData.transmitDataBuffer[12] = 0xaa; //char26
                appData.transmitDataBuffer[13] = 0xff; //char25
                appData.transmitDataBuffer[14] = 0xee; //char24
                appData.transmitDataBuffer[15] = 0xdd; //char23
                appData.transmitDataBuffer[16] = 0xcc; //char22
                appData.transmitDataBuffer[17] = 0xbb; //char21
                appData.transmitDataBuffer[18] = 0xaa; //char20
                appData.transmitDataBuffer[19] = 0xff; //char19
                appData.transmitDataBuffer[20] = 0xee; //char18
                appData.transmitDataBuffer[21] = 0xdd; //char17
                appData.transmitDataBuffer[22] = 0xcc; //char16
                appData.transmitDataBuffer[23] = 0xbb; //char15
                appData.transmitDataBuffer[24] = 0xaa; //char14
                appData.transmitDataBuffer[25] = 0xff; //char13
                appData.transmitDataBuffer[26] = 0xee; //char12
                appData.transmitDataBuffer[27] = 0xdd; //char11
                appData.transmitDataBuffer[28] = 0xcc; //char10
                appData.transmitDataBuffer[29] = 0xbb; //char9
                appData.transmitDataBuffer[30] = 0xaa; //char8
                appData.transmitDataBuffer[31] = 0xaa; //char7
                appData.transmitDataBuffer[32] = 0xaa; //char6
                appData.transmitDataBuffer[33] = 0xaa; //char5
                appData.transmitDataBuffer[34] = 0xaa; //char4
                appData.transmitDataBuffer[35] = 0xaa; //char3
                appData.transmitDataBuffer[36] = 0xaa; //char2
                appData.transmitDataBuffer[37] = 0xaa; //char1
                appData.transmitDataBuffer[38] = 0xaa; //char0
                appData.transmitDataBuffer[39] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get WiFi network security key
            case 0x7e:
                appData.transmitDataBuffer[1] = 0x21;
                appData.transmitDataBuffer[2] = 0x7e;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0x20; //Len2
                appData.transmitDataBuffer[7] = 0xff; //char31
                appData.transmitDataBuffer[8] = 0xee; //char30
                appData.transmitDataBuffer[9] = 0xdd; //char29
                appData.transmitDataBuffer[10] = 0xcc; //char28
                appData.transmitDataBuffer[11] = 0xbb; //char27
                appData.transmitDataBuffer[12] = 0xaa; //char26
                appData.transmitDataBuffer[13] = 0xff; //char25
                appData.transmitDataBuffer[14] = 0xee; //char24
                appData.transmitDataBuffer[15] = 0xdd; //char23
                appData.transmitDataBuffer[16] = 0xcc; //char22
                appData.transmitDataBuffer[17] = 0xbb; //char21
                appData.transmitDataBuffer[18] = 0xaa; //char20
                appData.transmitDataBuffer[19] = 0xff; //char19
                appData.transmitDataBuffer[20] = 0xee; //char18
                appData.transmitDataBuffer[21] = 0xdd; //char17
                appData.transmitDataBuffer[22] = 0xcc; //char16
                appData.transmitDataBuffer[23] = 0xbb; //char15
                appData.transmitDataBuffer[24] = 0xaa; //char14
                appData.transmitDataBuffer[25] = 0xff; //char13
                appData.transmitDataBuffer[26] = 0xee; //char12
                appData.transmitDataBuffer[27] = 0xdd; //char11
                appData.transmitDataBuffer[28] = 0xcc; //char10
                appData.transmitDataBuffer[29] = 0xbb; //char9
                appData.transmitDataBuffer[30] = 0xaa; //char8
                appData.transmitDataBuffer[31] = 0xaa; //char7
                appData.transmitDataBuffer[32] = 0xaa; //char6
                appData.transmitDataBuffer[33] = 0xaa; //char5
                appData.transmitDataBuffer[34] = 0xaa; //char4
                appData.transmitDataBuffer[35] = 0xaa; //char3
                appData.transmitDataBuffer[36] = 0xaa; //char2
                appData.transmitDataBuffer[37] = 0xaa; //char1
                appData.transmitDataBuffer[38] = 0xaa; //char0
                appData.transmitDataBuffer[39] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get encoder A status
            case 0x7f:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x7f;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, ENCODER_A);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get encoder B status
            case 0x80:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x80;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, ENCODER_B);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get trigger sensor 0 status (Banner_0)
            case 0x81:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x81;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, BANNER_0);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get trigger sensor 1 status (Banner_1)
            case 0x82:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x82;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, BANNER_1);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get spare 1 trigger sensor status
            case 0x83:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x83;
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 000; // PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, SPARE_1);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get spare 2 trigger sensor status
            case 0x84:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x84;
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0x00; // PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, SPARE_2);
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set GPI0 RFID Input
            case 0x85:
                appData.transmitDataBuffer[1] = 0x01; // Len
                appData.transmitDataBuffer[2] = 0x85; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                if (appData.receiveDataBuffer[3] == 1) // Set trigger accordingly
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, HIGH); // GPI0 high
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, LOW); // GPI0 low
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set GPI1 RFID Input
            case 0x86:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x86;
                appData.transmitDataBuffer[3] = 0x00;     // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                if (appData.receiveDataBuffer[3] == 1)    // Set trigger accordingly
                {
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, HIGH); // GPI1 high
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH);        // Enable the AUX output on J3 pins 1&2
                    SetFrontPanelLEDs(3, 2);              // Pulse the TR-65 Trigger LED
                }
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, LOW); // GPI1 low            
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW);        // Disable the AUX output on J3 pins 1&2
                
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get GPIO RFID Reader Status
            case 0x87:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x87;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = GetRFIDOutputs();
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get board temperature
            case 0x88:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x88;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = GetTemp();
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Mark state
            case 0x89:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x89;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //high/low
                if (appData.receiveDataBuffer[3] == 1) // Set Mark accordingly   0 = inactive, 1 = active
                    Mark(1); // send a 0 to retract the punch, and a 1 to extend it.  This does not regard the NV RAM variable that can invert the command.
                else
                    Mark(0); // send a 0 to retract the punch, and a 1 to extend it.  This does not regard the NV RAM variable that can invert the command.
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Punch state
            case 0x8a:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8a;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //high/low
                if (appData.receiveDataBuffer[3] == 1) // Set Punch accordingly    0 = inactive, 1 = active
                    Punch(1); // send a 0 to retract the punch, and a 1 to extend it.  This does not regard the NV RAM variable that can invert the command.
                else
                    Punch(0); // send a 0 to retract the punch, and a 1 to extend it.  This does not regard the NV RAM variable that can invert the command.
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Aux state
            case 0x8b:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8b;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //high/low
                if (appData.receiveDataBuffer[3] == 1) // Set Aux accordingly
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH); // Aux high
                else
                    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW); // Aux low
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Snap relay state
            case 0x8c:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8c;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                //if(appData.receiveDataBuffer[3] == 1)                                           // Set Snap relay accordingly
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, SNAPRELAY, HIGH );       // Snap relay on
                //else
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, SNAPRELAY, LOW );        // Snap relay off
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set Monarch relay state
            case 0x8d:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8d;
                appData.transmitDataBuffer[3] = 0x2C; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = appData.receiveDataBuffer[3]; //on/off
                //if(appData.receiveDataBuffer[3] == 1)                                           // Set Monarch relay accordingly
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, MONARCHPAUSE, HIGH );    // Monarch relay on
                //else
                //    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, MONARCHPAUSE, LOW );     // Monarch relay off
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get Mark, Punch, Aux, Snap and Monarch Pause Status
            case 0x8e:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8e;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = GetOutputStatus(); //status
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Get pushbutton status
            case 0x8f:
                appData.transmitDataBuffer[1] = 0x01;
                appData.transmitDataBuffer[2] = 0x8f;
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = GetPushbuttonStatus(); //status
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Enter High Speed GPIO Test Mode 
            case 0x90:
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x90; // CMD
                appData.transmitDataBuffer[3] = 0x55; // Update status to high speed
                appData.transmitDataBuffer[6] = 1; // 1 = entering high speed gpio mode
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                Enable0xE6Mode = appData.receiveDataBuffer[3]; // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.
                HSGPIOCounter = 0;        // Zero gpio counter
                Banner1Count = 0;         // Zero sensor counter
                LabelEncoderTics = 0;     // Zero encoder counter
                break;

                //Exit High Speed GPIO/Reader Test Mode
            case 0x91:
                APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x91; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0; // 0 = leaving high speed gpio mode
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                Enable0xE6Mode = 0; // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.
                break;

                //Set High Speed GPIO Test Mode Timer
            case 0x92:
                appData.transmitDataBuffer[1] = 0x00; //LEN
                appData.transmitDataBuffer[2] = 0x92; //CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                HSGPIOTMTimer = 0xff00 & ((uint16_t) appData.receiveDataBuffer[3] << 8); //MSB
                HSGPIOTMTimer = HSGPIOTMTimer | ((uint16_t) appData.receiveDataBuffer[4] & 0x00ff); //+LSB
                if (HSGPIOTMTimer > 6000) {
                    HSGPIOTMTimer = 6000;
                } //Make sure it's within range
                if (HSGPIOTMTimer < 1) {
                    HSGPIOTMTimer = 1;
                }
                break;

                //Get High Speed GPIO Test Mode Timer
            case 0x93:
                appData.transmitDataBuffer[1] = 0x02; // LEN
                appData.transmitDataBuffer[2] = 0x93; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = (uint8_t) ((HSGPIOTMTimer >> 8) & 0x00ff);
                appData.transmitDataBuffer[7] = (uint8_t) (HSGPIOTMTimer & 0x00ff);
                appData.transmitDataBuffer[8] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Enter High Speed Reader Test Mode    *********** RX PORTION DOES NOT MATCH SPREAD SHEET
            case 0x94:
                HSPacketEnable = appData.receiveDataBuffer[3]; // 0 = Disable, 1 = Enable.  Send 0xE6 at rate specified in 0x95 when enabled.
                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0x94; // CMD
                if (HSPacketEnable) {
                    appData.transmitDataBuffer[3] = 0x55; // Update status to high speed
                    appData.transmitDataBuffer[6] = 1; // 1 = In high speed reader mode
                    HSReaderCounter = HSReaderTMTimer;
                } else {
                    appData.transmitDataBuffer[3] = 0; // Update status to NOT high speed
                    appData.transmitDataBuffer[6] = 0; // 0 = In high speed reader mode                
                }
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                //Set High Speed Reader Test Mode Timer
            case 0x95:
                appData.transmitDataBuffer[1] = 0x00; // LEN
                appData.transmitDataBuffer[2] = 0x95; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                HSReaderTMTimer = 0xff00 & ((uint16_t) appData.receiveDataBuffer[3] << 8); // MSB
                HSReaderTMTimer = HSReaderTMTimer | ((uint16_t) appData.receiveDataBuffer[4] & 0x00ff); // +LSB
                if (HSReaderTMTimer > 60000) HSReaderTMTimer = 60000; // Make sure it's within range
                if (HSReaderTMTimer < 1) HSReaderTMTimer = 1;
                HSReaderCounter = HSReaderTMTimer; // HSReaderCounter is decremented in 1mS ISR
                break;

                //Get High Speed Reader Test Mode Timer
            case 0x96:
                appData.transmitDataBuffer[1] = 0x02; // LEN
                appData.transmitDataBuffer[2] = 0x96; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = (uint8_t) ((HSReaderTMTimer >> 8) & 0x00ff);
                appData.transmitDataBuffer[7] = (uint8_t) (HSReaderTMTimer & 0x00ff);
                appData.transmitDataBuffer[8] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

                // Calibration commands
            case 0x97:
                 break;


            case 0x98: // Power meter data incoming.  This is how the main board receives power meter data during CAL
                //ControlTP(33, 1); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                //ControlTP(32, 1); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

                LatestPwrReading = (uint16_t) appData.receiveDataBuffer[3];           // Power sent as centi dB with + 100dB offset.   Sent in two bytes; units and 2 place decimal.
                LatestPwrReading = LatestPwrReading * 100;                            // We got the hundreds.
                LatestPwrReading = LatestPwrReading + appData.receiveDataBuffer[4];   // Now add in the units.
                PMRunStop = appData.receiveDataBuffer[5];                             // Run Stop Button.   0 = Stop or pre-running, 1 = Run
                
                
                // TODO Fix me.
                if(appData.receiveDataBuffer[3]==0x9E)            // If we detect an underflow from the power meter. (Power too low))
                    LatestPwrReading = 7400;                      // Bandaid and bailing wire.   Replace with the minumum reading; -26dB
                //DebugOut( sprintf(Uart5TxBuf, "%X %X %lu \r\n",appData.receiveDataBuffer[3],appData.receiveDataBuffer[4],LatestPwrReading) );
                
                AveragePwrReading = (AveragePwrReading + LatestPwrReading) / 2;
                
                if (NewPowerMeterValueAvailable < 250)
                    NewPowerMeterValueAvailable++;                           // Set when a new power meter value is available.   The counter permits averaging.
                
               
                //PMPacer = 0;                                         // Shortens the delay
                
                //appData.transmitDataBuffer[1] = 0x03;                // LEN
                //appData.transmitDataBuffer[2] = 0x98;                // Command
                //appData.transmitDataBuffer[3] = 0x00;                // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                //appData.transmitDataBuffer[6] = 1;                   // Unused
                //appData.transmitDataBuffer[7] = CurrentCALChannel;   //(Channel Number) The Actual Freq is = (uint32_t) 860 + (CurrentCALChannel * 2 ) * 1000000;
                //appData.transmitDataBuffer[8] = AverageTemperature;  // Temperature 0 - 100 in Degrees C.
                //appData.transmitDataBuffer[9] = CheckSum(&appData.transmitDataBuffer[1]);
                //TxUSBPacketUpdate();                                 // Transmit packet to USB port
                //ControlTP(32, 0); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                //ControlTP(33, 0); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                break;


            case 0xF6: // Read Configuration data

                JustATemp8 = appData.receiveDataBuffer[3]; // The number of Bytes requested.  Ignored.  We return one byte at a time for now.
                JustATemp16 = ((int16_t) appData.receiveDataBuffer[5] << 8) & 0xff00; // Get the MSB of the Address.
                JustATemp16 = (int16_t) (JustATemp16 | appData.receiveDataBuffer[4]); // Get the LSB of the Address.

                JustATemp8 = FRAMRead8(JustATemp16); // pass in uint16_t Address.  For use with Cypress FM25V01

                appData.transmitDataBuffer[1] = 0x04; // LEN
                appData.transmitDataBuffer[2] = 0xF6; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = 0x01; // The number of Bytes requested.  Ignored.  We return one byte at a time for now.
                appData.transmitDataBuffer[7] = appData.receiveDataBuffer[4]; // the LSB of the Address.
                appData.transmitDataBuffer[8] = appData.receiveDataBuffer[5]; // the MSB of the Address.
                appData.transmitDataBuffer[9] = JustATemp8; // Data that was read from the Config NVRAM
                appData.transmitDataBuffer[10] = CheckSum(&appData.transmitDataBuffer[1]); // Checksum

                break;

            case 0xF7: // Write Configuration data

                JustATemp8 = appData.receiveDataBuffer[3]; // The number of Bytes to Write. Ignored. We write one byte at a time for now.
                JustATemp16 = ((int16_t) appData.receiveDataBuffer[5] << 8) & 0xff00; // Get the MSB of the Address.
                JustATemp16 = (int16_t) (JustATemp16 | appData.receiveDataBuffer[4]); // Get the LSB of the Address.
                JustATemp8 = appData.receiveDataBuffer[6]; // Get the Byte to Write.

                FRAMWrite8(JustATemp16, JustATemp8); // pass in uint16_t Address and uint8_t Data.  For use with Cypress FM25V01
                JustATemp8 = FRAMRead8(JustATemp16); // pass in uint16_t Address.  For use with Cypress FM25V01

                appData.transmitDataBuffer[1] = 0x01; // LEN
                appData.transmitDataBuffer[2] = 0xF7; // CMD
                appData.transmitDataBuffer[3] = 0x00; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = JustATemp8; // Data that was read from the Config NVRAM
                appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]); // Checksum

                break;


            default:
                //Unknown command
                appData.transmitDataBuffer[1] = 0x00;
                appData.transmitDataBuffer[2] = appData.receiveDataBuffer[2];
                appData.transmitDataBuffer[3] = 0x03; // Set status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
                appData.transmitDataBuffer[6] = CheckSum(&appData.transmitDataBuffer[1]);
                break;

        }
    }

    if(appData.transmitDataBuffer[3])          // if STATUS is not zero 
        SetFrontPanelLEDs(7,2);                // then light the front panel indicator.      
    
    if (!appCmd14Data.enable) // Main Enable/disable for the tester.
        status = 0x58; // Command 0x14 must send an enable.  (Default is on during debug.   It should be off when released.)

    lastcommand = appData.receiveDataBuffer[2]; // update the last command variable.
    //lastfault = appData.transmitDataBuffer[3];  // We always send the status as byte 3
    APP_Clear_Receive_Buffer(); // Now let's clear the receive buffer pending next received command.

}

void UpdatePowerMeter(uint8_t NumAverages)         // Build a USB message to send Temperature and Frequency to power meter.
{
    //ControlTP(32, 1); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    appData.transmitDataBuffer[0] = 0xee;
    appData.transmitDataBuffer[1] = 0x03;                                    // LEN
    appData.transmitDataBuffer[2] = 0x98;                                    // Command
    appData.transmitDataBuffer[3] = 0;                                       // Status
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff);   // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);
    appData.transmitDataBuffer[6] = 1;                                       // Unused
    appData.transmitDataBuffer[7] = CurrentCALChannel;                       //(Channel Number) The Actual Freq is = (uint32_t) 860 + (CurrentCALChannel * 2 ) * 1000000;
    appData.transmitDataBuffer[8] = AverageTemperature;                      // Temperature 0 - 100 in Degrees C.
    appData.transmitDataBuffer[9] = CheckSum(&appData.transmitDataBuffer[1]);
    TxUSBPacketUpdate();                                                     // Transmit packet to USB port
    //ControlTP(32, 0); // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
}

void SendFaultNoticeToHost(uint8_t FaultID) // Build a USB message to notify the HOST that a fault Occurred.
{
    appData.transmitDataBuffer[0] = 0xee;
    appData.transmitDataBuffer[1] = 0x01;     // LEN
    appData.transmitDataBuffer[2] = 0xE0;     // Command
    appData.transmitDataBuffer[3] = 0;        // Status
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);
    appData.transmitDataBuffer[6] = FaultID; // Faults defined on Spreadsheet.
    appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
    TxUSBPacketUpdate(); // Transmit packet to USB port
}


void Send0xE2Data(void)              // Send the results of test 0x0B
{
uint8_t  JustATemp8;                 // Temporary storage.  Typically used for a few lines of code then abandoned.

    APP_Clear_Transmit_Buffer();     // First let's clear the transmit buffer

    appData.transmitDataBuffer[0] = 0xee; // Setup universally required response parameters
    appData.transmitDataBuffer[1] = 0x0F; // Len
    appData.transmitDataBuffer[2] = 0xE2; // Command
    appData.transmitDataBuffer[3] = 0x0;  // Set status:  Normal
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);

    appData.transmitDataBuffer[6] = (uint8_t) ((CaldFreqs[CurrentCALChannel] >> 24) & 0x000000ff); // Closest Frequency MSB
    appData.transmitDataBuffer[7] = (uint8_t) ((CaldFreqs[CurrentCALChannel] >> 16) & 0x000000ff); // 
    appData.transmitDataBuffer[8] = (uint8_t) ((CaldFreqs[CurrentCALChannel] >> 8) & 0x000000ff);  // 
    appData.transmitDataBuffer[9] = (uint8_t) (CaldFreqs[CurrentCALChannel] & 0x000000ff);         // Closest Frequency LSB
    appData.transmitDataBuffer[10] = (uint8_t) (ACalRecord_PwrError >> 8);                  // Power Error from cal table.
    appData.transmitDataBuffer[11] = (uint8_t) (ACalRecord_PwrError & 0x00FF);              // 
    appData.transmitDataBuffer[12] = CurrentTemperatureNum;                                 // Temperature Bracket
    appData.transmitDataBuffer[13] = (uint8_t) (ACalRecord_FAD >> 8);                       // Forward AD Value from CAL table.
    appData.transmitDataBuffer[14] = (uint8_t) (ACalRecord_FAD & 0x00FF);                   //
    appData.transmitDataBuffer[15] = (uint8_t) (ACalRecord_RAD >> 8);                       // Reverse AD Value from CAL table.
    appData.transmitDataBuffer[16] = (uint8_t) (ACalRecord_RAD & 0x00FF);                   //
    appData.transmitDataBuffer[17] = (uint8_t) (CurrentFAD >> 8);                           // Forward AD Value that was just measured.
    appData.transmitDataBuffer[18] = (uint8_t) (CurrentFAD & 0x00FF);                       //
    appData.transmitDataBuffer[19] = (uint8_t) (CurrentRAD >> 8);                           // Reverse AD Value that was just mesured.
    appData.transmitDataBuffer[20] = (uint8_t) (CurrentRAD & 0x00FF);                       //
    appData.transmitDataBuffer[21] = CheckSum(&appData.transmitDataBuffer[1]);              // Checksum
    TxUSBPacketUpdate();                                                                    // Send the packet to the USB serial interface engine.
}


void Send0xE3Data(void)         // unsolicited response sent at the completion of a 0x10 command.
{
    //static uint16_t timer;
    //static uint8_t tmrmsb, tmrlsb;

    APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
    //timer = TMR3; // Let's get the timer values required of all responses */
    //tmrmsb = (uint8_t) ((timer >> 8) & 0x00ff);
    //tmrlsb = (uint8_t) (timer & 0x00ff);

    appData.transmitDataBuffer[0] = 0xee;     // Setup universally required response parameters
    appData.transmitDataBuffer[1] = 0x20;     // LEN
    appData.transmitDataBuffer[2] = 0xE3;     // CMD
    appData.transmitDataBuffer[3] = 0;        // Status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);
    appData.transmitDataBuffer[6] = appCmd10Data.testtype; // Test Type
    appData.transmitDataBuffer[7] = MainTestStatus; // Test Status
    appData.transmitDataBuffer[8] = (uint8_t) ((appCmd15Data.triggercount >> 24) & 0x000000ff); // Number of labels tested D3
    appData.transmitDataBuffer[9] = (uint8_t) ((appCmd15Data.triggercount >> 16) & 0x000000ff); // Number of labels tested D2
    appData.transmitDataBuffer[10] = (uint8_t) ((appCmd15Data.triggercount >> 8) & 0x000000ff); // Number of labels tested D1
    appData.transmitDataBuffer[11] = (uint8_t) (appCmd15Data.triggercount & 0x000000ff); // Number of labels tested D0
    appData.transmitDataBuffer[12] = CurrentEPC[0]; // Tag ID MSB
    appData.transmitDataBuffer[13] = CurrentEPC[1]; // Tag ID
    appData.transmitDataBuffer[14] = CurrentEPC[2]; // Tag ID
    appData.transmitDataBuffer[15] = CurrentEPC[3]; // Tag ID
    appData.transmitDataBuffer[16] = CurrentEPC[4]; // Tag ID
    appData.transmitDataBuffer[17] = CurrentEPC[5]; // Tag ID
    appData.transmitDataBuffer[18] = CurrentEPC[6]; // Tag ID
    appData.transmitDataBuffer[19] = CurrentEPC[7]; // Tag ID
    appData.transmitDataBuffer[20] = CurrentEPC[8]; // Tag ID
    appData.transmitDataBuffer[21] = CurrentEPC[9]; // Tag ID
    appData.transmitDataBuffer[22] = CurrentEPC[10]; // Tag ID
    appData.transmitDataBuffer[23] = CurrentEPC[11]; // Tag ID LSB
    appData.transmitDataBuffer[24] = 0; // Sensitivity[1]
    appData.transmitDataBuffer[25] = 0; // Sensitivity[0]
    appData.transmitDataBuffer[26] = CurrentTID[0]; // TID[0] MSB
    appData.transmitDataBuffer[27] = CurrentTID[1]; // TID[1]
    appData.transmitDataBuffer[28] = CurrentTID[2]; // TID[2]
    appData.transmitDataBuffer[29] = CurrentTID[3]; // TID[3]
    appData.transmitDataBuffer[30] = CurrentTID[4]; // TID[4]
    appData.transmitDataBuffer[31] = CurrentTID[5]; // TID[5]
    appData.transmitDataBuffer[32] = CurrentTID[6]; // TID[6]
    appData.transmitDataBuffer[33] = CurrentTID[7]; // TID[7]
    appData.transmitDataBuffer[34] = CurrentTID[8]; // TID[8]
    appData.transmitDataBuffer[35] = CurrentTID[9]; // TID[9]
    appData.transmitDataBuffer[36] = CurrentTID[10]; // TID[10]
    appData.transmitDataBuffer[37] = CurrentTID[11]; // TID[11] LSB
    appData.transmitDataBuffer[38] = CheckSum(&appData.transmitDataBuffer[1]);
    TxUSBPacketUpdate();
}


void Send0xE4Data(uint8_t PassFail) // unsolicited response sent at the completion of a 0x18 Sensivity test command.
{
    //static uint16_t timer;
    //static uint8_t tmrmsb, tmrlsb;

    APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
    //timer = TMR3; // Let's get the timer values required of all responses */
    //tmrmsb = (uint8_t) ((timer >> 8) & 0x00ff);
    //tmrlsb = (uint8_t) (timer & 0x00ff);

    appData.transmitDataBuffer[0] = 0xee; // Setup universally required response parameters
    appData.transmitDataBuffer[1] = 0x03; // LEN
    appData.transmitDataBuffer[2] = 0xE4; // CMD
    appData.transmitDataBuffer[3] = 0; // Status: 00 OK, 03 Unsupported Command, 2C Hardware Unavailable
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);
    appData.transmitDataBuffer[6] = PassFail; // 1 = Pass, 0 = Fail
    appData.transmitDataBuffer[7] = (uint8_t) (appCmd18Data.CurrentPowerLevel >> 8); // Shift the MSB down to the LSB and chop off the top byte so that it fits into an int
    appData.transmitDataBuffer[8] = (uint8_t) appCmd18Data.CurrentPowerLevel; // chops off the top byte so that it fits into an 8 bit int.
    appData.transmitDataBuffer[9] = CheckSum(&appData.transmitDataBuffer[1]);
    TxUSBPacketUpdate();
}


void Send0XE5EventNoticeToHost(uint8_t EventID) // Send USB Event Notice to HOST.   0x03 = Flash Erase Complete. 04 Command 0x10 setup complete.
{
    APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
    appData.transmitDataBuffer[0] = 0xee; // SOM
    appData.transmitDataBuffer[1] = 0x01; // LEN
    appData.transmitDataBuffer[2] = 0xE5; // Command
    appData.transmitDataBuffer[3] = 0; // Status
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);
    appData.transmitDataBuffer[6] = EventID; // Events defined on Spreadsheet.
    appData.transmitDataBuffer[7] = CheckSum(&appData.transmitDataBuffer[1]);
    TxUSBPacketUpdate(); // Transmit packet to USB port
}


void Send0xE6PacketHS(void) // Send the High Speed Data packet
{
    //static uint16_t timer;
    //static uint8_t tmrmsb, tmrlsb;

    APP_Clear_Transmit_Buffer(); // First let's clear the transmit buffer
    //timer = TMR3;                                    // Let's get the timer values required of all responses
    //tmrmsb = (uint8_t)((timer>>8) & 0x00ff);
    //tmrlsb = (uint8_t)(timer & 0x00ff);

    appData.transmitDataBuffer[0] = 0xee; // Setup universally required response parameters
    appData.transmitDataBuffer[1] = 0x27; // Len
    appData.transmitDataBuffer[2] = 0xE6; // Command
    appData.transmitDataBuffer[3] = 0x55; // Set status:  HIGH SPEED STREAMING MODE
    appData.transmitDataBuffer[4] = (uint8_t) ((HostTimer >> 8) & 0x00ff); // Increments in the 1mS ISR. Can be reset with command 0x02
    appData.transmitDataBuffer[5] = (uint8_t) (HostTimer & 0x00ff);

    appData.transmitDataBuffer[6] = (uint8_t) ((Banner1Count >> 24) & 0x000000ff); // Send the sensor 1 counter
    appData.transmitDataBuffer[7] = (uint8_t) ((Banner1Count >> 16) & 0x000000ff);
    appData.transmitDataBuffer[8] = (uint8_t) ((Banner1Count >> 8) & 0x000000ff);
    appData.transmitDataBuffer[9] = (uint8_t) (Banner1Count & 0x000000ff);

    appData.transmitDataBuffer[10] = 0;                                                  // Send the encoder A counter
    appData.transmitDataBuffer[11] = 0;                                                  // 32 Bits in GPIO
    appData.transmitDataBuffer[12] = (uint8_t) ((LabelEncoderTics >> 8)  & 0x000000ff);  // 16 Bits in Programmer
    appData.transmitDataBuffer[13] = (uint8_t) ( LabelEncoderTics        & 0x000000ff);

    appData.transmitDataBuffer[14] = MacArray[0]; // Send the device ID
    appData.transmitDataBuffer[15] = MacArray[1];
    appData.transmitDataBuffer[16] = MacArray[2];
    appData.transmitDataBuffer[17] = MacArray[3];
    appData.transmitDataBuffer[18] = MacArray[4];
    appData.transmitDataBuffer[19] = MacArray[5];

    appData.transmitDataBuffer[20] = CurrentTID[0]; // TID[0] MSB
    appData.transmitDataBuffer[21] = CurrentTID[1]; // TID[1]
    appData.transmitDataBuffer[22] = CurrentTID[2]; // TID[2]
    appData.transmitDataBuffer[23] = CurrentTID[3]; // TID[3]
    appData.transmitDataBuffer[24] = CurrentTID[4]; // TID[4]
    appData.transmitDataBuffer[25] = CurrentTID[5]; // TID[5]
    appData.transmitDataBuffer[26] = CurrentTID[6]; // TID[6]
    appData.transmitDataBuffer[27] = CurrentTID[7]; // TID[7]
    appData.transmitDataBuffer[28] = CurrentTID[8]; // TID[8]
    appData.transmitDataBuffer[29] = CurrentTID[9]; // TID[9]
    appData.transmitDataBuffer[30] = CurrentTID[10]; // TID[10]
    appData.transmitDataBuffer[31] = CurrentTID[11]; // TID[11] LSB

    appData.transmitDataBuffer[32] = CurrentEPC[0]; // Tag ID MSB
    appData.transmitDataBuffer[33] = CurrentEPC[1]; // Tag ID
    appData.transmitDataBuffer[34] = CurrentEPC[2]; // Tag ID
    appData.transmitDataBuffer[35] = CurrentEPC[3]; // Tag ID
    appData.transmitDataBuffer[36] = CurrentEPC[4]; // Tag ID
    appData.transmitDataBuffer[37] = CurrentEPC[5]; // Tag ID
    appData.transmitDataBuffer[38] = CurrentEPC[6]; // Tag ID
    appData.transmitDataBuffer[39] = CurrentEPC[7]; // Tag ID
    appData.transmitDataBuffer[40] = CurrentEPC[8]; // Tag ID
    appData.transmitDataBuffer[41] = CurrentEPC[9]; // Tag ID
    appData.transmitDataBuffer[42] = CurrentEPC[10]; // Tag ID
    appData.transmitDataBuffer[43] = CurrentEPC[11]; // Tag ID LSB

    appData.transmitDataBuffer[44] = 0; // Result

    appData.transmitDataBuffer[45] = CheckSum(&appData.transmitDataBuffer[1]);

    TxUSBPacketUpdate();

}


void FlushLabelData(void) // Delete the EPC and TID data from the last read.
{
    for (LoopCounter = 0; LoopCounter < 12; LoopCounter++) {
        CurrentTID[LoopCounter] = 0;
        CurrentEPC[LoopCounter] = 0;
    }
}







/******************************************************************************
  Function:
    void APP_Clear_Transmit_Buffer ( void )

  Remarks:
    Clears transmitDataBuffer to 0. Should be called prior to setting up
    command response
 */

void APP_Clear_Transmit_Buffer(void) {
    static uint8_t cntr;

    for (cntr = 0; cntr < 64; cntr++) {
        appData.transmitDataBuffer[cntr] = 0;
    }
}

/******************************************************************************
  Function:
    void APP_Clear_Receive_Buffer ( void )

  Remarks:
    Clears transmitDataBuffer to 0. Should be called prior to setting up
    command response
 */

void APP_Clear_Receive_Buffer(void) {
    static uint8_t cntr;

    for (cntr = 0; cntr < 64; cntr++) {
        appData.receiveDataBuffer[cntr] = 0;
    }
}

uint8_t CheckSumRX(uint8_t *buffer) // Sums, Modulo-256, the buffer from LEN to FCS-1.  Casts result to unsigned int 8-bit for the return trip.
{ // Received messages have two more characters that the LEN byte states.
    static uint8_t x, LEN, FCS;
    static uint16_t sum;
    uint8_t TestChar;

    LEN = *buffer; // Address passed in is the LEN BYTE of the protocol or command length. The LEN that is passed in is the num bytes between CMD and FCS.  
    // we do the checksum for all bytes between SOF (EE) and FCS.   We add 2 to compensate for the difference.

    sum = 0; // Zero the sum

    for (x = 0; x < LEN + 2; x++) // Add them up... 
    {
        TestChar = *buffer;
        sum = sum + *buffer;
        buffer++;
    }

    FCS = (uint8_t) sum; // Now cast to uint8_t to clip off the upper bype and

    //DebugOut( sprintf(Uart5TxBuf, "FCS %x \n\r",FCS) );

    return FCS; // send it back.

}

uint8_t CheckSum(uint8_t *buffer) // Sums, Modulo-256, the buffer from LEN to FCS-1.  Casts result to unsigned int 8-bit for the return trip.
{ // Use for Transmitted messages.  They have 5 more characters than the LEN byte states.
    static uint8_t x, LEN, FCS; // Use CheckSumRX() for received messages,
    static uint16_t sum;

    LEN = *buffer; // Address passed in is the LEN BYTE of the protocol or command length.  The LEN that is passed in is the num bytes between TMRL and FCS.  
    // we do the checksum for all bytes between EE and FCS.   We add 5 to compensate for the difference.

    sum = 0; // Zero the sum

    for (x = 0; x < LEN + 5; x++) // Add them up... 
    {
        sum = sum + *buffer;
        buffer++;
    }

    FCS = (uint8_t) sum; // Now cast to uint8_t to clip off the upper bype and
    return FCS; // send it back.

}

/******************************************************************************
  Function:
    uint8_t ReadDipSwitch( void )

  Remarks:
    Returns config8,2,4,1 in lower nibble
 */

uint8_t ReadDipSwitch(void) {
    static uint8_t sw, temp;

    temp = 0;
    sw = 0;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, CONFIG8) == 1) {
        sw = sw | 0x08;
    } else {
        sw = sw & 0x03;
    }

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, CONFIG4) == 1) {
        sw = sw | 0x04;
    } else {
        sw = sw & 0x0b;
    }

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, CONFIG2) == 1) {
        sw = sw | 0x02;
    } else {
        sw = sw & 0x0d;
    }

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, CONFIG1) == 1) {
        sw = sw | 0x01;
    } else {
        sw = sw & 0x0e;
    }

    //Mask off the upper nibble
    sw = sw & 0x0f;

    return sw;

}

/******************************************************************************
  Function:
    uint8_t GetCameraOutputs( void )

  Remarks:
    Returns cam_out1, cam_out2, cam_out3, cam_strobe, cam_ready as follows
    D7     D6      D5      D4       D3          D2          D1          D0
    0       0       0      cam_rdy  cam_strobe  cam_out3    cam_out2    cam_out1
 */

uint8_t GetCameraOutputs(void) {
    static uint8_t gpio;

    gpio = 0;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, CAM_OUT1) == 1)
        gpio = gpio | 0x01;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, CAM_OUT2) == 1)
        gpio = gpio | 0x02;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, CAM_OUT3) == 1)
        gpio = gpio | 0x04;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_A, CAM_STROBE) == 1)
        gpio = gpio | 0x08;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, CAM_READY) == 1)
        gpio = gpio | 0x10;

    return gpio;

}

/******************************************************************************
  Function:
    uint8_t GetRFIDOutputs( void )

  Remarks:
    Returns gpio_0, gpio_1, as follows
    D7     D6      D5      D4       D3        D2        D1          D0
    0       0       0      0        0         0         gpio_1      gpio_0
 */

uint8_t GetRFIDOutputs(void) {
    static uint8_t gpio;

    gpio = 0;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, RFID_GPO_0) == 1)
        gpio = gpio | 0x01;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, RFID_GPO_1) == 1)
        gpio = gpio | 0x02;

    return gpio;

}

/******************************************************************************
  Function:
    uint8_t GetOutputStatus( void )

  Remarks:
    Returns gpio_0, gpio_1, as follows
    D7     D6      D5       D4          D3        D2        D1          D0
    0       0      0        MonRelay  SnapRelay   Aux       Punch       Mark
 Monarch and Snap deleted for rev B and later PCBs.
 */

uint8_t GetOutputStatus(void) {
    static uint8_t gpio;

    gpio = 0;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_G, MARK) == 1)
        gpio = gpio | 0x01;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_F, PUNCH) == 1)
        gpio = gpio | 0x02;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_F, AUX) == 1)
        gpio = gpio | 0x04;

    //if( PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, SNAPRELAY) == 1 )
    //    gpio = gpio | 0x08;

    //if( PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, MONARCHPAUSE) == 1 )
    //    gpio = gpio | 0x10;

    return gpio;

}

/******************************************************************************
  Function:
    uint8_t GetPushbuttonStatus( void )

  Remarks:
    Returns gpio_0, gpio_1, as follows
    D7     D6      D5       D4      D3      D2      D1          D0
    0       0      0        0       0       0       Push1       Push2

 */

uint8_t GetPushbuttonStatus(void) {
    static uint8_t gpio;

    gpio = 0;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, PUSH1) == 1)
        gpio = gpio | 0x01;

    if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, PUSH2) == 1)
        gpio = gpio | 0x02;

    return gpio;

}

/******************************************************************************
  Function:
    void SetDateTime( uint8_t *ptryear )

  Remarks:
  Called in the USB command protocol as a result of receiving command 0x08
  Updates the RTCC date and time

 */

void SetDateTime(uint8_t *ptryear) {
    static uint8_t tens, ones, temp = 0;
    static uint32_t dt = 0, tm = 0;

    if (appDateTime.dtupdateflag == 1) {
        /*Setup the write to HH:MM:SS now*/
        /*Get the year*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        dt = ((uint32_t) tens << 28) & 0xf0000000;
        dt = dt | (((uint32_t) ones << 24) & 0x0f000000);

        /*Increment pointer to month*/
        ptryear++;

        /*Get the month*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        dt = dt | (((uint32_t) tens << 20) & 0x00100000);
        dt = dt | (((uint32_t) ones << 16) & 0x000f0000);

        /*Increment pointer to day*/
        ptryear++;

        /*Get the day*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        dt = dt | (((uint32_t) tens << 12) & 0x00003000);
        dt = dt | (((uint32_t) ones << 8) & 0x00000f00);

        /*Setup the write to HH:MM:SS now*/
        /*Increment pointer to hour*/
        ptryear++;

        /*Get the hour*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        tm = ((uint32_t) tens << 28) & 0x30000000;
        tm = tm | (((uint32_t) ones << 24) & 0x0f000000);

        /*Increment pointer to minute*/
        ptryear++;

        /*Get the minute*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        tm = tm | (((uint32_t) tens << 20) & 0x00700000);
        tm = tm | (((uint32_t) ones << 16) & 0x000f0000);

        /*Increment pointer to second*/
        ptryear++;

        /*Get the second*/
        temp = *ptryear;

        /*Convert it to BCD and place in correct location*/
        tens = temp / 10;
        ones = temp - tens * 10;

        tm = tm | (((uint32_t) tens << 12) & 0x00007000);
        tm = tm | (((uint32_t) ones << 8) & 0x00000f00);

        /*dt and tm now contain the proper values so let's write them to the registers*/

        /* Enable writes to RTCC */
        PLIB_DEVCON_SystemUnlock(DEVCON_ID_0); /* Unlock System */
        PLIB_RTCC_WriteEnable(RTCC_ID_0);

        /* Disable clock to RTCC */
        PLIB_RTCC_Disable(RTCC_ID_0);
        while (PLIB_RTCC_ClockRunningStatus(RTCC_ID_0)); /*Check if clock is disabled */

        PLIB_RTCC_RTCDateSet(RTCC_ID_0, dt); /* Set RTCC date */
        PLIB_RTCC_RTCTimeSet(RTCC_ID_0, tm); /* Set RTCC time */

        /* Enable RTCC module */
        PLIB_RTCC_Enable(RTCC_ID_0);
        PLIB_RTCC_AlarmEnable(RTCC_ID_0);

        /* Disable writes to RTCC and lock */
        PLIB_RTCC_WriteDisable(RTCC_ID_0);
        PLIB_DEVCON_SystemLock(DEVCON_ID_0); /* Lock System */

        /*Clear the update flag*/
        appDateTime.dtupdateflag = 0;
    }

}

/******************************************************************************
  Function:
    void GetCurrentDateTime( void )

  Remarks:
    Updates appDateTime array with the current date and time.

 */

void GetDateTime(void) {
    static uint32_t date, time, tens, ones;
    static uint8_t year, month, day, hour, minute, second;


    date = DRV_RTCC_DateGet();
    time = DRV_RTCC_TimeGet();

    tens = ((date & 0xf0000000) >> 28);
    ones = ((date & 0x0f000000) >> 24);

    year = tens * 10 + ones;

    appDateTime.year = year;

    tens = ((date & 0x00100000) >> 20);
    ones = ((date & 0x000f0000) >> 16);

    month = tens * 10 + ones;

    appDateTime.month = month;

    tens = ((date & 0x00003000) >> 12);
    ones = ((date & 0x00000f00) >> 8);

    day = tens * 10 + ones;

    appDateTime.day = day;

    tens = ((time & 0x30000000) >> 28);
    ones = ((time & 0x0f000000) >> 24);

    hour = tens * 10 + ones;

    appDateTime.hour = hour;

    tens = ((time & 0x00700000) >> 20);
    ones = ((time & 0x000f0000) >> 16);

    minute = tens * 10 + ones;

    appDateTime.minute = minute;

    tens = ((time & 0x00007000) >> 12);
    ones = ((time & 0x00000f00) >> 8);

    second = tens * 10 + ones;

    appDateTime.second = second;


}

void TxUSBPacketUpdate(void) // appData.TransmitBuffer[] must be updated prior to calling this routine.
{
    appData.hidDataTransmitted = false; // Set transmit flag to false

    /* Prepare the USB module to send the data packet to the host */
    USB_DEVICE_HID_ReportSend(USB_DEVICE_HID_INDEX_0, &appData.txTransferHandle, appData.transmitDataBuffer, 64);
}

void PlaceUSBReadRequest(void) // Sets USB to read request mode
{
    appData.hidDataReceived = false; // Set receive flag to false

    /* Place a new read request. */
    USB_DEVICE_HID_ReportReceive(USB_DEVICE_HID_INDEX_0, &appData.rxTransferHandle, appData.receiveDataBuffer, 64);

}

// End of File*******************************************************************************
