/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

//DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
//DOM-IGNORE-END

#ifndef _APP_H
#define _APP_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "usb/usb_chapter_9.h"
#include "usb/usb_device.h"
#include "led.h"

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application states

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/

typedef enum
{
    /* Application is initializing */
    APP_STATE_INIT,

    /* Application is waiting for configuration */
    APP_STATE_WAIT_FOR_CONFIGURATION,

    /* Application is running the main tasks */
    APP_STATE_MAIN_TASK,

    /* Application is in an error state */
    APP_STATE_ERROR
           
} APP_STATES;


// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    /* The application's current state */
    APP_STATES state;

      /* Device layer handle returned by device layer open function */
    USB_DEVICE_HANDLE  usbDevHandle;

    /* Receive data buffer */
    uint8_t * receiveDataBuffer;

    /* Transmit data buffer */
    uint8_t * transmitDataBuffer;

    /* Device configured */
    bool deviceConfigured;

    /* Send report transfer handle*/
    USB_DEVICE_HID_TRANSFER_HANDLE txTransferHandle;

    /* Receive report transfer handle */
    USB_DEVICE_HID_TRANSFER_HANDLE rxTransferHandle;

    /* Configuration value selected by the host*/
    uint8_t configurationValue;

    /* HID data received flag*/
    bool hidDataReceived;

    /* HID data transmitted flag */
    bool hidDataTransmitted;

     /* USB HID current Idle */
    uint8_t idleRate;

    uint8_t ledflag;

} APP_DATA;

// *****************************************************************************
/* APP_DATETIME

  Summary:
    Holds application date/time data

  Description:
    This structure holds the application's date/time data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    /* Programmer lane */
    uint8_t lane;

    uint8_t year;

    uint8_t month;

    uint8_t day;

    uint8_t hour;

    uint8_t minute;

    uint8_t second;
    
    bool dtupdateflag;

} APP_DATETIME;

// *****************************************************************************
/* APP_CMD10

  Summary:
    Holds command 0x10 data

  Description:
    This structure holds the application's command 0x10 data.

  Remarks:
    
 */

typedef struct
{
    uint8_t testtype;

    uint8_t tagclass;

    uint8_t antport;

    int16_t readpower;

    uint16_t readtimeout;
    
    uint32_t freq1;

    uint32_t freq2;

    uint32_t freq3;

    int16_t writepower;
    
    uint16_t writetimeout;
    
    uint8_t writetype;
      
    bool changesettings;

} APP_CMD10;

APP_CMD10 appCmd6AData;
APP_CMD10 appCmd10Data;


           

// *****************************************************************************
/* APP_MARKER

  Summary:
    Holds command 0x11 data

  Description:
    This structure holds the application's command 0x11 data.

  Remarks:
    
 */





// *****************************************************************************
/* APP_TRIGGERINPUTSETTINGS

  Summary:
    Holds command 0x12 data

  Description:
    This structure holds the application's command 0x12 data.

  Remarks:
    
 */


// *****************************************************************************
/* APP_TRIGGEROUTPUTSETTINGS

  Summary:
    Holds command 0x13 data

  Description:
    This structure holds the application's command 0x13 data.

  Remarks:
    
 */

typedef struct
{
    /*Enable / disable trigger input. (00 = Disable, 01 = Enable).*/
    uint8_t enable;

    /*Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).*/
    uint8_t edgetype;
    
    /*Duration in ms that output triggers. 0 means until next input trigger is received.*/
    uint8_t duration;

} APP_TRIGGEROUTPUTSETTINGS;


// *****************************************************************************
/* APP_TESTERSETTINGS

  Summary:
    Holds command 0x14 data

  Description:
    This structure holds the application's command 0x14 data.

  Remarks:
    
 */

typedef struct
{
    /*Enable / disable trigger input. (00 = Disable, 01 = Enable).*/
    uint8_t enable;

    /*Relative position of tester on web from arbitrary start position (00).*/
    uint8_t position;
    
} APP_TESTERSETTINGS;
APP_TESTERSETTINGS appCmd14Data;


// *****************************************************************************
/* APP_SETBULKWRITESETTINGS

  Summary:
    Holds command 0x16 data

  Description:
    This structure holds the application's command 0x16 data.

  Remarks:
    
 */

typedef struct
{
    /*Antenna port configuration to use. 0 = No port, 1 = Tx1 RX1, 2 = Tx2 Rx2, 3 = Tx1 Rx2.*/
    uint8_t antport;

    /*Write power in centi-dBm. -1500 to 3000.*/
    int16_t writepower;
    
    /*Write command timeout in ms.*/
    uint16_t writetimeout;
    
    /*Frequency to bulk write at. F in kHz.*/
    uint32_t frequency;
    
    /*Number of triggers before performing a bulk write. (Set to 0 for no bulk write).*/
    uint8_t count;
    
    /*0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values.*/
    uint8_t writetype;
    
    /*Tag ID that will be used on the next bulk write.*/
    uint8_t * bulkTagID;
    
} APP_SETBULKWRITESETTINGS;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Routines
// *****************************************************************************
// *****************************************************************************
/* These routines are called by drivers when certain events occur.
*/

	
// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Summary:
     MPLAB Harmony application initialization routine.

  Description:
    This function initializes the Harmony application.  It places the 
    application in its initial state and prepares it to run so that its 
    APP_Tasks function can be called.

  Precondition:
    All other system initialization routines should be called before calling
    this routine (in "SYS_Initialize").

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Initialize();
    </code>

  Remarks:
    This routine must be called from the SYS_Initialize function.
*/

void APP_Initialize ( void );


/*******************************************************************************
  Function:
    void APP_Tasks ( void )

  Summary:
    MPLAB Harmony Demo application tasks function

  Description:
    This routine is the Harmony Demo application's tasks function.  It
    defines the application's state machine and core logic.

  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Tasks();
    </code>

  Remarks:
    This routine must be called from SYS_Tasks() routine.
 */

void APP_Tasks( void );


/*******************************************************************************
  Function:
    Wait_For_USB ( void )

  Summary:
    Tasks to run until the USB connection has been made.

  Description:
    This routine runs in APP_Tasks() until the USB port has been connected.
  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    Wait_For_USB();
    </code>

  Remarks:
    This routine must be called from APP_Tasks() routine.
 */

void INIT_BEFORE_USB( void );
uint8_t reversebyte(uint8_t byte);
void APP_Clear_Transmit_Buffer ( void );
void APP_Clear_Receive_Buffer ( void );
uint8_t CheckSumRX( uint8_t *buffer );      // Add RX to the name for Received Messages.   LEN+2  Two Bytes extra
uint8_t CheckSum( uint8_t *buffer );        // Use this function for transmitted messages. LEN+5  Five Bytes Extra.
void Parse_Received_Command( void );
uint8_t ReadDipSwitch( void );
uint8_t GetCameraOutputs( void );
uint8_t GetRFIDOutputs( void );
uint8_t GetTemp( void );
uint8_t GetOutputStatus( void );
uint8_t GetPushbuttonStatus( void );
void SetDateTime(  uint8_t *ptryear  );
void GetDateTime( void );
void HSPacketUpdate( uint8_t cmd );
void PlaceUSBReadRequest( void );
void TxUSBPacketUpdate( void );



#endif /* _APP_H */
/*******************************************************************************
 End of File
 */

