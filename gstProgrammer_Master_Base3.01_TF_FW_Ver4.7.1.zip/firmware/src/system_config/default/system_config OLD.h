/*******************************************************************************
  MPLAB Harmony System Configuration Header

  File Name:
    system_config.h

  Summary:
    Build-time configuration header for the system defined by this MPLAB Harmony
    project.

  Description:
    An MPLAB Project may have multiple configurations.  This file defines the
    build-time options for a single configuration.

  Remarks:
    This configuration header must not define any prototypes or data
    definitions (or include any files that do).  It only provides macro
    definitions for build-time configuration options that are not instantiated
    until used by another MPLAB Harmony module or application.
    
    Created with MPLAB Harmony Version 1.06
*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

#ifndef _SYSTEM_CONFIG_H
#define _SYSTEM_CONFIG_H

/* This is a temporary workaround for an issue with the peripheral library "Exists"
   functions that causes superfluous warnings.  It "nulls" out the definition of
   The PLIB function attribute that causes the warning.  Once that issue has been
   resolved, this definition should be removed. */
#define _PLIB_UNSUPPORTED


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
/*  This section Includes other configuration headers necessary to completely
    define this configuration.
*/

#include "bsp_config.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Service Configuration
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Common System Service Configuration Options
*/
#define SYS_VERSION_STR           "1.06"
#define SYS_VERSION               10600

// *****************************************************************************
/* Clock System Service Configuration Options
*/
#define SYS_CLK_FREQ                        48000000ul
#define SYS_CLK_BUS_PERIPHERAL_1            48000000ul
#define SYS_CLK_UPLL_BEFORE_DIV2_FREQ       96000000ul
#define SYS_CLK_CONFIG_PRIMARY_XTAL         8000000ul
#define SYS_CLK_CONFIG_SECONDARY_XTAL       32768ul
   
/*** Interrupt System Service Configuration ***/
#define SYS_INT                     true

/*** Ports System Service Configuration ***/

#define SYS_PORT_A_ANSEL        0x0
#define SYS_PORT_A_TRIS         0x4200
#define SYS_PORT_A_LAT          0x0
#define SYS_PORT_A_ODC          0x0
#define SYS_PORT_A_CNPU         0x0
#define SYS_PORT_A_CNPD         0x0
#define SYS_PORT_A_CNEN         0x0

#define SYS_PORT_B_ANSEL        0x0
#define SYS_PORT_B_TRIS         0xd9bf
#define SYS_PORT_B_LAT          0x40
#define SYS_PORT_B_ODC          0x0
#define SYS_PORT_B_CNPU         0x0
#define SYS_PORT_B_CNPD         0x0
#define SYS_PORT_B_CNEN         0x0
#define SYS_PORT_C_ANSEL        0xf000
#define SYS_PORT_C_TRIS         0xf000
#define SYS_PORT_C_LAT          0x0
#define SYS_PORT_C_ODC          0x0
#define SYS_PORT_C_CNPU         0x0
#define SYS_PORT_C_CNPD         0x0
#define SYS_PORT_C_CNEN         0x0

#define SYS_PORT_D_ANSEL        0x0
#define SYS_PORT_D_TRIS         0x4c0f
#define SYS_PORT_D_LAT          0x0
#define SYS_PORT_D_ODC          0x0
#define SYS_PORT_D_CNPU         0x0
#define SYS_PORT_D_CNPD         0x0
#define SYS_PORT_D_CNEN         0x0

#define SYS_PORT_E_ANSEL        0x0
#define SYS_PORT_E_TRIS         0x7f
#define SYS_PORT_E_LAT          0x0
#define SYS_PORT_E_ODC          0x0
#define SYS_PORT_E_CNPU         0x0
#define SYS_PORT_E_CNPD         0x0
#define SYS_PORT_E_CNEN         0x0

#define SYS_PORT_F_ANSEL        0x0
#define SYS_PORT_F_TRIS         0x1030
#define SYS_PORT_F_LAT          0x0
#define SYS_PORT_F_ODC          0x0
#define SYS_PORT_F_CNPU         0x0
#define SYS_PORT_F_CNPD         0x0
#define SYS_PORT_F_CNEN         0x0

#define SYS_PORT_G_ANSEL        0x0
#define SYS_PORT_G_TRIS         0x7382
#define SYS_PORT_G_LAT          0x0
#define SYS_PORT_G_ODC          0x0
#define SYS_PORT_G_CNPU         0x0
#define SYS_PORT_G_CNPD         0x0
#define SYS_PORT_G_CNEN         0x0


// *****************************************************************************
// *****************************************************************************
// Section: Driver Configuration
// *****************************************************************************
// *****************************************************************************

/*** Timer Driver Configuration ***/
#define DRV_TMR_INTERRUPT_SOURCE_IDX0       INT_SOURCE_TIMER_3
#define DRV_TMR_INTERRUPT_SOURCE_IDX1       INT_SOURCE_TIMER_2

 

/*** SPI Driver Configuration ***/
#define DRV_SPI_NUMBER_OF_MODULES		4
/*** Driver Compilation and static configuration options. ***/
/*** Select SPI compilation units.***/
#define DRV_SPI_POLLED 				0
#define DRV_SPI_ISR 				0
#define DRV_SPI_MASTER 				0
#define DRV_SPI_SLAVE 				0
#define DRV_SPI_RM 				0
#define DRV_SPI_EBM 				0
#define DRV_SPI_8BIT 				0
#define DRV_SPI_16BIT 				0
#define DRV_SPI_32BIT 				0
#define DRV_SPI_DMA 				0

/*** SPI Driver Static Allocation Options ***/
#define DRV_SPI_INSTANCES_NUMBER 		
#define DRV_SPI_CLIENTS_NUMBER 			
#define DRV_SPI_ELEMENTS_PER_QUEUE 		

// *****************************************************************************
// *****************************************************************************
// Section: Middleware & Other Library Configuration
// *****************************************************************************
// *****************************************************************************

/*** USB Driver Configuration ***/


/* Enables Device Support */
#define DRV_USBFS_DEVICE_SUPPORT      true

/* Disable Device Support */
#define DRV_USBFS_HOST_SUPPORT      false

/* Maximum USB driver instances */
#define DRV_USBFS_INSTANCES_NUMBER    1


/* Interrupt mode enabled */
#define DRV_USBFS_INTERRUPT_MODE      true


/* Number of Endpoints used */
#define DRV_USBFS_ENDPOINTS_NUMBER    2

/*** USB Device Stack Configuration ***/

/* The USB Device Layer will not initialize the USB Driver */
#define USB_DEVICE_DRIVER_INITIALIZE_EXPLICIT

/* Maximum device layer instances */
#define USB_DEVICE_INSTANCES_NUMBER     1

/* EP0 size in bytes */
#define USB_DEVICE_EP0_BUFFER_SIZE      64

/* Maximum instances of HID function driver */
#define USB_DEVICE_HID_INSTANCES_NUMBER     1

/* HID Transfer Queue Size for both read and
   write. Applicable to all instances of the
   function driver */
#define USB_DEVICE_HID_QUEUE_DEPTH_COMBINED 2


// *****************************************************************************
/* BSP Configuration Options
*/
#define BSP_OSC_FREQUENCY 8000000

#define APP_MAKE_BUFFER_DMA_READY

#define APP_USB_LED_1 BSP_LED_1
#define APP_USB_LED_2 BSP_LED_2
#define APP_USB_LED_3 BSP_LED_3

#define APP_USB_SWITCH_1 BSP_SWITCH_1
#define APP_USB_SWITCH_2 BSP_SWITCH_2

//Barry
#define REGULATOR_ON    1
#define REGULATOR_OFF   0
#define MOTOR_ON        0
#define MOTOR_OFF       1
#define LOW             0
#define HIGH            1
#define LEDON           0
#define LEDOFF          1
#define MOTOR_DATA      2
#define LED_DATA        1
#define READEPC         0x01
#define READTID         0x08
#define EPC1GEN2        0x01
#define DOSENSTEST      0x04


//Defines for all I/O pins that are outputs
#define RFID_ENABLE     PORTS_BIT_POS_7
#define JADAK_ENABLE    PORTS_BIT_POS_3
#define CAMERA_ENABLE   PORTS_BIT_POS_9
#define MOTOR_ENABLE    PORTS_BIT_POS_6
#define SR_LAT_SCLK     PORTS_BIT_POS_3
#define SR_LAT_RCLK     PORTS_BIT_POS_4
#define SR_LAT_DATA     PORTS_BIT_POS_2
#define MONARCHPAUSE    PORTS_BIT_POS_7
#define SNAPRELAY       PORTS_BIT_POS_6
#define ATT_LE          PORTS_BIT_POS_5
#define RAD_CS          PORTS_BIT_POS_4
#define FAD_CS          PORTS_BIT_POS_13
#define BANNER_ENABLE   PORTS_BIT_POS_12
#define RFID_GPI_0      PORTS_BIT_POS_0
#define RFID_GPI_1      PORTS_BIT_POS_7
#define SPARE2          PORTS_BIT_POS_0
#define SPARE1          PORTS_BIT_POS_1
#define EE_CS           PORTS_BIT_POS_8
#define FRAM_CS         PORTS_BIT_POS_15
#define PUNCH           PORTS_BIT_POS_8
#define AUX             PORTS_BIT_POS_2
#define CAM_TRIG        PORTS_BIT_POS_9
#define CAM_TEACH       PORTS_BIT_POS_10
#define MARK            PORTS_BIT_POS_15
#define TEMP_CS         PORTS_BIT_POS_13

#define CONFIG8         PORTS_BIT_POS_2
#define CONFIG4         PORTS_BIT_POS_13
#define CONFIG2         PORTS_BIT_POS_12
#define CONFIG1         PORTS_BIT_POS_14
#define CAM_OUT1        PORTS_BIT_POS_5
#define CAM_OUT2        PORTS_BIT_POS_7
#define CAM_OUT3        PORTS_BIT_POS_11
#define CAM_STROBE      PORTS_BIT_POS_9
#define CAM_READY       PORTS_BIT_POS_2
#define ENCODER_A       PORTS_BIT_POS_0
#define ENCODER_B       PORTS_BIT_POS_14
#define BANNER_0        PORTS_BIT_POS_1
#define BANNER_1        PORTS_BIT_POS_8
#define SPARE_1         PORTS_BIT_POS_1
#define SPARE_2         PORTS_BIT_POS_0
#define RFID_GPO_0      PORTS_BIT_POS_6
#define RFID_GPO_1      PORTS_BIT_POS_12
#define PUSH1           PORTS_BIT_POS_3
#define PUSH2           PORTS_BIT_POS_4

//Joe's defines
#define TP12            PORTS_BIT_POS_2      // Port A, Pin 58,   
#define TP13            PORTS_BIT_POS_3      // Port A, Pin 59,
#define TP17            PORTS_BIT_POS_4      // Port A, Pin 60, 
#define TP18            PORTS_BIT_POS_5      // Port A, Pin 61, 
#define TP31            PORTS_BIT_POS_1      // Port F, Pin 88,    
#define TP32            PORTS_BIT_POS_0      // Port F, Pin 87,    
#define TP39            PORTS_BIT_POS_6      // Port A, Pin 91, 
#define TP45            PORTS_BIT_POS_1      // Port A, Pin 38, 
#define TP49            PORTS_BIT_POS_10     // Port B, Pin 34,
#define TP68            PORTS_BIT_POS_0      // Port A, Pin 17,    
#define TP77            PORTS_BIT_POS_8      // Port E, Pin 18,     
#define TP96            PORTS_BIT_POS_14     // Port A, Pin 66,
#define ADMISO          PORTS_BIT_POS_3      // Port B, pin 22, i
#define ADSCLK          PORTS_BIT_POS_6      // Port G, pin 10, o, l
#define TEMPMISO        PORTS_BIT_POS_14     // Port D, pin 47, i
#define TEMPSCLK        PORTS_BIT_POS_15     // Port D, pin 48, o, l
#define ATT_MOSI        PORTS_BIT_POS_1      // Port C, pin 6, o, l
#define ATT_SCLK        PORTS_BIT_POS_13     // Port F, pin 39, o, l

#endif // _SYSTEM_CONFIG_H
/*******************************************************************************
 End of File
*/

