//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    system_int.c
//    This file contains a definitions of the raw ISRs required to support the interrupt sub-system.  
//
//  Last Edit Date:  Sept  3 2017   JRL Updates for Rev B Board
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************



// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <xc.h>
#include <sys/attribs.h>
#include "app.h"
#include "globals.h"
#include "system_definitions.h"



// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************

/* ENCODER_A external interrupt */
void __ISR(_EXTERNAL_0_VECTOR, IPL1AUTO) _IntHandlerExternalInterruptInstance0(void)
{
unsigned int BState;
static bool AWasRising;
    
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_0);                  // Clear the INT
    
    ControlTP(16, 1);      // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    ControlTP(16, 0);      // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    if(EncoderADeafTime)                       // Decremented in 1mS ISR.  Used to ignore pulses from the encoder if they come quicker than planned.
    {
        return;                               // If we received an encoder TIC sooner than we expected then ignore it.  
    }

    EncoderADeafTime = EncoderDeafTimeReload; // We just got a legal encoder pulse.  Reset the deaf time to be able to ignore glitches that happen before the next real one.
    
    if( EncoderStyle == 1 )                   // 0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
    {

        BState = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_B, ENCODER_B);      // Read the other Encoder channel
              
        SetFrontPanelLEDs(5, 2);              // Illuminate Encoder A LED on front panel.
               
        if(AWasRising)
        {    
            AWasRising = 0;

            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE0,INT_EDGE_TRIGGER_FALLING);
            if(BState)                        // Turned Counter Clockwise
            {
                LabelEncoderTics--;           // Number of Encoder tics since a new label was detected.
            }
            else                              // Turned Clockwise
            {    
                LabelEncoderTics++;           // Number of Encoder tics since a new label was detected.
                EncoderJustMovedForward();    // Do everything that has to happen when the encoder reports a foreard movement.
            }
        }
        else
        {
            AWasRising = 1;
            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE0,INT_EDGE_TRIGGER_RISING);
            if(BState)                        // Turned Counter Clockwise
            {
                LabelEncoderTics++;           // Number of Encoder tics since a new label was detected.
                EncoderJustMovedForward();    // Do everything that has to happen when the encoder reports a foreard movement.
            }
            else                         // Turned Clockwise
            {
                LabelEncoderTics--;      // Number of Encoder tics since a new label was detected.
            }
        }
    }
    
    if( EncoderStyle == 2 )              // Encoder style is pulse A type.    We can't determine direction with a single input channel so it's always positive movement.
    {
        LabelEncoderTics++;              // Number of Encoder tics since a new label was detected.
        EncoderJustMovedForward();       // Do everything that has to happen when the encoder reports a foreward movement. 
        SetFrontPanelLEDs(5, 2);         // Illuminate Encoder A LED on front panel.
    }
    
    // The encoder moved. Update velocity every time we get a rising edge on the A channel Encoder.////////////////////////////////////////
    // Get fast timer ticks and add rollovers.
    // GlobalTimerTicksPerEncoderTick = #Rollovers<<16 | CurrentTimerValue;       // Global uint32_t Calculated from the Timer ticks and roll overs.    
    // Zero timer;                                                                // Reset and start counting again for next encoder tick.
    // The next 4 lines consume ~1uS
    GlobalTimerTicksPerEncoderTick = PLIB_TMR_Counter16BitGet(TMR_ID_2);          // Get the current timer value.
    PLIB_TMR_Counter16BitSet(TMR_ID_2, 0);                                        // Auto Re-Load Value for count up timer.. reset it to the beginning.
    GlobalTimerTicksPerEncoderTick += (EncoderTimerRollovers * 65535);            // add the number timer ticks for the number of 65535 count rollovers
    EncoderTimerRollovers = 0;                                                    // Global uint16_t Counts roll overs of the timer used to measure velocity.

    // If we received more encoder tics than the length of a label and TrigFiltMax is > 0
    if( ( LabelEncoderTics > appCmd1dData.triggerfiltermax) && appCmd1dData.triggerfiltermax && (TestModeState == WAITFOR0X10TRIG))   
    {  // then the Banner missed a label. So we Fake one.                 
        JustGotNewLabelTrigger();    // fiber optic detector or Camera just detected a new label.
        LabelEncoderTics = 0;        // Global uint16_t Counts number of encoder tics since last new label detection.
        //ControlTP(12,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    }
    
}



/* ENCODER_B external interrupt */
void __ISR(_EXTERNAL_1_VECTOR, IPL1AUTO) _IntHandlerExternalInterruptInstance1(void)
{
unsigned int AState;
static bool BWasRising;

    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_1);                  // Clear the INT

    if(EncoderBDeafTime)                       // Decremented in 1mS ISR.  Used to ignore pulses from the encoder if they come quicker than planned.
        return;                                // If we received an encoder TIC sooner than we expected then ignore it.
    
    SetFrontPanelLEDs(4, 2);                   // Illuminate Encoder B LED on front panel.
    
    EncoderBDeafTime = EncoderDeafTimeReload;  // We just got a legal encoder pulse.  Reset the deaf time to be able to ignore glitches that happen before the next real one.
    
    if( EncoderStyle == 1 )                                                     // 0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
    {

        AState = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, ENCODER_A);      // Read the other Encoder channel

        if(BWasRising)
        {    
            BWasRising = 0;
            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE1,INT_EDGE_TRIGGER_FALLING);
            if(AState)                        // Turned Counter Clockwise
            {
                LabelEncoderTics++;           // Number of Encoder tics since a new label was detected.
                EncoderJustMovedForward();     // Do everything that has to happen when the encoder reports a foreard movement.
            }
            else                              // Turned Clockwise
            {
                LabelEncoderTics--;           // Number of Encoder tics since a new label was detected.
            }
        }
        else
        {
            BWasRising = 1;
            SYS_INT_ExternalInterruptTriggerSet(INT_EXTERNAL_INT_SOURCE1,INT_EDGE_TRIGGER_RISING);
            if(AState)                         // Turned Counter Clockwise
            {
                LabelEncoderTics--;            // Number of Encoder tics since a new label was detected
            }
            else                               // Turned Clockwise
            {    
                LabelEncoderTics++;            // Number of Encoder tics since a new label was detected.
                EncoderJustMovedForward();     // Do everything that has to happen when the encoder reports a foreard movement.
            }
        }
        
        // If we received more encoder tics than the length of a label and TrigFiltMax is > 0 then the Banner missed a label.   Fake one.
        if( ( LabelEncoderTics > appCmd1dData.triggerfiltermax) && appCmd1dData.triggerfiltermax && (TestModeState == WAITFOR0X10TRIG))   
        {
            JustGotNewLabelTrigger();   // fiber optic detector or Camera just detected a new label.
            LabelEncoderTics = 0;       // Global uint16_t Counts number of encoder tics since last new label detection.
        }
    }
}

/*** ENCODER SPEED ********************************
*  We need to handle 300 MAX Feet (91.44 Meter) per minute.  Thats 3600 inches per minute or 60 inches per second. 
*  If a label is 6 inches wide, then that's 10 labels per second.
*  50 Encoder Pulses per inch results in 3000 encoder pulses per second.
*  50   encoder pulses per second (EPPS) = 1 inch per second.
*  500  EPPS = 10 inches per second.
*  3000 EPPS = 60 inches per second.
****************************************************/

/* BANNER_1 external interrupt This is the one that uses Banner connector pin 4 and TP53 */
void __ISR(_EXTERNAL_2_VECTOR, IPL1AUTO) _IntHandlerExternalInterruptInstance2(void)
{          
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_2);
    
    ControlTP(79,1);            // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    ControlTP(79,0);            // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    if( (LabelEncoderTics < appCmd1dData.triggerfiltermin) && appCmd1dData.triggerfiltermin)     // If triggerfiltermin is set and that many encoder tics
    {                                                                                            // have not been counted since the last detected label. 
        return;     
    }

    LabelEncoderTics = 0;           // Global uint16_t Counts number of encoder tics since last new label detection.
    
    if(PlayPause)                   // 0 = pause.  1 = Play. Host must send setup info using command 0x10 then set the mode to enable using commands 0x50 and 0x51
        JustGotNewLabelTrigger();   // Banner fiber optic detector or Camera just detected a new label.
}

/* BANNER_0 external interrupt This is the one that uses Banner connector pin 2 and TP35 */
void __ISR(_EXTERNAL_3_VECTOR, IPL1AUTO) _IntHandlerExternalInterruptInstance3(void)
{           
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_3);
    
    ControlTP(79,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    ControlTP(79,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    if( (LabelEncoderTics < appCmd1dData.triggerfiltermin) && appCmd1dData.triggerfiltermin)     // If triggerfiltermin is set and that many encoder tics
    {                                                                                            // have not been counted since the last detected label. 
        return;     
    }
 
    LabelEncoderTics = 0;               // Global uint16_t Counts number of encoder tics since last new label detection.

    if(PlayPause)                       // 0 = pause.  1 = Play. Host must send setup info using command 0x10 then set the mode to enable using commands 0x50 and 0x51
        JustGotNewLabelTrigger();       // fiber optic detector or Camera just detected a new label.
}

/* CAM_OUT1 external interrupt */
void __ISR(_EXTERNAL_4_VECTOR, IPL1AUTO) _IntHandlerExternalInterruptInstance4(void)
{           
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_EXTERNAL_4);    
}


 
void __ISR(_UART_3_VECTOR, ipl1AUTO) _IntHandlerDrvUsartInstance2(void)         // TR-65 Serial Port.
{
char GetOnce;
uint8_t BuildDigit;

    GetOnce = PLIB_USART_ReceiverByteReceive(USART_ID_3);    // Hold the newly received character from RFID  
    
    if( (GetOnce != 0x0A) && (GetOnce != 0x0D) && (GetOnce != 0x00))  // if the char is not a 0x0D CR, 0x0D LF, or a 0x00 NULL
    {    
        Uart3RxBuf[Uart3RXpointer] = GetOnce;                // Stick it in the Global Buffer.
    
        if( Uart3RXpointer < MAXSERBUF )                     // Max length of a serial buffer  (250 Chars)
            Uart3RXpointer++;                                // if we are not at the end then increment it.
        else
            Uart3RXpointer = 0;                              // Just toss the buffer and reset the pointer.   no more would fit in anyway.    
    }

    // Possible replies when doing EPC and TID reads
    // ACQUIREFAIL 0D 0A <CRLF>
    // EPC=E2806810000000394F06DFCA,READFAIL 0D 0A <CRLF>
    // EPC=E2806810000000394F06DFCA,TID=E2806810200000014F06DFCA   0D 0A <CRLF> 
    
    // Possible replies when doing EPC only reads
    // ACQUIREFAIL 0D 0A <CRLF>
    // EPC=30380000000000000000007B 0D 0A <CRLF>
      
    if( GetOnce == 0x0D )                                    // If we just received a Carriage Return
    {
        Uart3CRGot = 1;                                      // Bool True if we just received a CR on the Specified UART
        
        if ((Uart3RxBuf[0] == 'A') && (Uart3RxBuf[1] == 'C') && (Uart3RxBuf[2] == 'Q') && (Uart3RxBuf[3] == 'U') )   // Received ACQUIREFAIL  (EPC and TID read fail)
        {
            GotTheStopInventoryMsg = 1;
            Uart3RxBuf[0] = 'Z';            // prevents retriggering.
            TR65EPCReadFail = 1;            // Set if a read error is detected in the EPC section 
            TR65TidReadFail = 1;            // This is ignored if TID Tests are not in process.
            NewTR65EPCAvailable = 0;                                   // Set a flag that says that we just got a TR-65 TAG EPC read.
        }
        
        //if ((Uart3RxBuf[0] == 'E') && (Uart3RxBuf[1] == 'P') && (Uart3RxBuf[2] == 'C') && (Uart3RxBuf[3] == '=') )    // Got an EPC Read.
        if ((Uart3RxBuf[0] == 'T') && (Uart3RxBuf[1] == 'A') && (Uart3RxBuf[2] == 'G') && (Uart3RxBuf[3] == '=') )    // Got an EPC Read.
        {
            NewTR65EPCAvailable = 0;                                   // Set a flag that says that we just got a TR-65 TAG EPC read.
            //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, LOW);
            //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, HIGH);
            Uart3RxBuf[0] = 'Z';                                       // prevents retriggering.

            TR65EPCReadFail = 0;                                       // reset if a read error is not detected in the EPC section             
            for( LoopCounter=0 ; LoopCounter < 12 ; LoopCounter++ )    // Convert from a text string to a numerical array.
            {
                BuildDigit = Uart3RxBuf[(LoopCounter*2)+8] - '0';      // Start 4 characters in so we can ignore the "EPC="  prefix of each TR-65 Read.
                if(BuildDigit > 16)                                    // If the digit is A - F 
                    BuildDigit -= 7;                                   // subtract 7 to get it in range.
                CurrentEPC[LoopCounter] = BuildDigit << 4;             // Shift it up 4 to multiply by 16 and push it into the array

                BuildDigit = (Uart3RxBuf[(LoopCounter*2)+9] - '0');    // Check the next character                                
                if(BuildDigit > 16)                                    // If the digit is A - F 
                    BuildDigit -= 7;                                   // subtract 7 to get it in range.
                CurrentEPC[LoopCounter] += BuildDigit;                 // Add it to the array.
            }
            NewTR65EPCAvailable = 1;                                   // Set a flag that says that we just got a TR-65 TAG EPC read.
        }

        if ((Uart3RxBuf[29] == 'R') && (Uart3RxBuf[30] == 'E') && (Uart3RxBuf[31] == 'A') && (Uart3RxBuf[32] == 'D') )   // READFAIL is sent if TID was not received.
        {
            TR65TidReadFail = 1;                                       // Set if a read error is detected in the TID Section. 
            Uart3RxBuf[29] = 'Z';                                      // prevents retriggering if we don't get a full read when we enter this loop on the next cycle..
        }

        if( (Uart3RxBuf[29] == 'T') && (Uart3RxBuf[30] == 'I') && (Uart3RxBuf[31] == 'D') && (Uart3RxBuf[32] == '=') )    // TID=XXXXXXXXXXXXXXXXXXXXXXXX is a good TID read.  
        {
            Uart3RxBuf[29] = 'Z';                                      // prevents retriggering if we don't get a full read when we enter this loop on the next cycle..
            TR65TidReadFail = 0;                                       // Reset if a good read is detected in the TID section   
            NewTR65TIDAvailable = 1;
            for( LoopCounter=0 ; LoopCounter < 12 ; LoopCounter++ )    // Convert from a text string to a numerical array.
            {
                BuildDigit = Uart3RxBuf[(LoopCounter*2)+33] - '0';     // Start 33 characters in so we can ignore the "TAG=" prefix of each TID TR-65 Read.
                if(BuildDigit > 17)                                    // If the digit is A - F 
                    BuildDigit -= 7;                                   // subtract 7 to get it in range.
                CurrentTID[LoopCounter] = BuildDigit << 4;             // Shift it up 4 to multiply by 16 and push it into the array

                BuildDigit = (Uart3RxBuf[(LoopCounter*2)+34] - '0');   // Check the next character                                
                if(BuildDigit > 17)                                    // If the digit is A - F 
                    BuildDigit -= 7;                                   // subtract 7 to get it in range.
                CurrentTID[LoopCounter] += BuildDigit;                 // Add it to the array.
            }
        }
        Uart3RXpointer = 0;       // Zero out the Receive pointer since we processed the string 
    }

    if( GetOnce == '>' )          // If we just received the ready message from the TR-65
    {
        //RfidTimeOut = 0;        // Reset the timeout that prevents sending the next message to 20mS because TR-65 really isn't all the way ready.
        RfidReady = 1;            // Set to 1 when the > is received from the TR-65
    }   
  
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_3_TRANSMIT);   // Clear pending interrupts
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_3_RECEIVE);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_3_ERROR);

} 
 
 
void __ISR(_UART_4_VECTOR, ipl1AUTO) _IntHandlerDrvUsartInstance3(void)
{
char GetOnce;

    GetOnce = PLIB_USART_ReceiverByteReceive(USART_ID_4);                       // Hold the newly received character from Camera 

    if( Uart4RXpointer < MAXSERBUF )                                            // Max length of a serial buffer
        Uart4RxBuf[Uart4RXpointer++] = GetOnce;                                 // Stick it in the Global Buffer.
    else
        Uart4RXpointer = 0;                                                     // Just toss the buffer and reset the pointer.   no more would fit in anyway.

    if( GetOnce == 0x0D )                                                       // If we just received a Carriage Return
        Uart4CRGot = 1;                                                         // Bool True if we just received a CR on the Specified UART

    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_TRANSMIT);            // Clear pending interrupts
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_RECEIVE);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_ERROR);

} 


void __ISR(_UART_5_VECTOR, ipl1AUTO) _IntHandlerDrvUsartInstance4(void)
{
char GetOnce;
    
    GetOnce = PLIB_USART_ReceiverByteReceive(USART_ID_5);                       // Hold the newly received character from  Debug Port SP5 (J14)  

    if( Uart5RXpointer < MAXSERBUF )                                            // Max length of a serial buffer
        Uart5RxBuf[Uart5RXpointer++] = GetOnce;                                 // Stick it in the Global Buffer if it fits.
    else
        Uart5RXpointer = 0;                                                     // Just toss the buffer and reset the pointer.   no more would fit in anyway.
  
    if( GetOnce == 0x0D )                                                       // If we just received a Carriage Return
        Uart5CRGot = 1;                                                         // Bool True if we just received a CR on the Specified UART

    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_5_TRANSMIT);            // Clear pending interrupts
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_5_RECEIVE);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_5_ERROR);

}	
	
void __ISR(_USB_1_VECTOR, ipl4AUTO) _IntHandlerUSBInstance0(void)
{

    DRV_USBFS_Tasks_ISR(sysObj.drvUSBObject);
            
}


/*******************************************************************************
  Function:
    __ISR(_TIMER_3_VECTOR, ipl1AUTO) _IntHandlerDrvTmrInstance0(void)

  Remarks:
    Timer 0 Instance. Executes every 1ms with a period of 188 
    Main system timer
    Uses Timer 3 hardware timer
 ******************************************************************************/
void __ISR(_TIMER_3_VECTOR, ipl1AUTO) _IntHandlerDrvTmrInstance0(void)
{

    HSGPIOCounter++;             // Counts up to find when to launch test 0x90
    
    ControlTP(12,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    ControlTP(12,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    
    if(HSReaderCounter)           // Times the High Speed messages
    {
        HSReaderCounter--;        // Decrement each mS   
        if( (!HSReaderCounter) && HSPacketEnable )     // If we just decremented from 1 to 0 and the HS mode is enabled.
        {
            HSReaderCounter = HSReaderTMTimer;    // The number of mS between sending 0xE6 High Speed update messages.
            Send0xE6PacketHS();                   // Send the USB message containing all the high speed data.
        }
    }        
    
    //IPC0SET = 0x1;

    // Toggle the test point to make it easy to see if the ISR is accurate.
    
    HostTimer++;                         // Increments each 1mS in the 1mS ISR.  Sent to Host PC with every USB message.  Can be reset with command 0x02    
    
    if(Cmd1E_desiredNumPulses)           // If we are making pulses for Debug command 0x1E.
    {
        if(Cmd1E_Timer)                  // If there is time on the counter.
        {   
            Cmd1E_Timer--;
            if(!Cmd1E_Timer)                                  // If we just decremented from 1 to 0
            {
                ToggleMark();                                 // Toggle the MARK Peripheral
                Cmd1E_Timer = Cmd1E_desiredPulseDuration;     // Reset the counter/timer
                Cmd1E_desiredNumPulses--;                     // Decrement the counter to consume a half of a Pulse (either a rising edge or a falling edge of the pulse)
                if(!Cmd1E_desiredNumPulses)                   // If we just decremented from 1 to 0 then we exit.
                {
                    TestModeState = TESTMODEIDLE;             // Stop everything and goto the test IDLE mode.   
                }                 
            }    
        }
    }
    
    if(Counter1mS)                // Triggers the tenth second tasks in PCB_Peripherals.c
        Counter1mS--;

    if(PMCounter)                 // Decremented in the Timer3 ISR.  Used to ensure delays between Power Meter Reads.
        PMCounter--;
    
    if(Enable0xE6Mode == 1)       // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.
        Send0xE6PacketHS();       // Send the message to the host.
    
    if(RfidTimeOut)               // Pace messages to the RFID Interface
        RfidTimeOut--;

    if(EncoderADeafTime)          // Used to ignore pulses from the encoder if they come quicker than planned.
        EncoderADeafTime--;

    if(EncoderBDeafTime)          // Used to ignore pulses from the encoder if they come quicker than planned.
        EncoderBDeafTime--;
    
    if(CalPacer)                  // Paces the RFID Calibration processes.
        CalPacer--;

    if(PMPacer)                   // Paces the power meter requests.
        PMPacer--;
       
    
    if(MarkOffsetTimer)           // If we are delaying the peripherals trigger using MilliSeconds
    {
        MarkOffsetTimer--;        // Decrement each mS   
        if(!MarkOffsetTimer)      // If we just decremented from 1 to 0
        {
            MarkActiveTimer = appCmd11Data.duration;            // The number of mS that the Mark peripheral is to be energized from command 0x11
            Mark(1);                                            // Trigger the Mark Peripheral.
        }
    }
    
    if(PunchOffsetTimer)          // If we are delaying the peripherals trigger using MilliSeconds
    {
        PunchOffsetTimer--;       // Decrement each mS   
        if(!PunchOffsetTimer)     // If we just decremented from 1 to 0
        {
            PunchActiveTimer = appCmd20Data.duration;          // The number of mS that the Mark peripheral is to be energized from command 0x20
            Punch(1);                                          // enable the peripheral
        }
    }
    
    if(TR65TriggerLen)          // If we are timing the trigger
    {
        TR65TriggerLen--;       // decrement it
        if(!TR65TriggerLen)     // if it just transitioned from 1 to 0
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, LOW);     // Reset TR-65 Hardware trigger pin.
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, LOW);     // To finish the TR-65 GPI hardware trigger for a read.
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW);            // Disable the AUX output on J3 pins 1&2
        }
    }

    if(TriggerDelayTimer)        // If the trigger delay timer is active
    {
        TriggerDelayTimer--;     // decrement it
        if(!TriggerDelayTimer)   // if it just transitioned from 1 to 0
            TriggertheTest();    // We detected the label in mS delay mode and just waited for that specified delay, so Trigger the TR-65
    }
    
    if(PunchActiveTimer)         // If the punch timer is active then the punch peripheral is active.
    {                            // this will disable the peripheral when has been enabled for the requested time
        PunchActiveTimer--;      // Decrement it every one millisecond.
        if(!PunchActiveTimer)    // If the punch timer just decremented from 1 to 0
            Punch(0);            // Disable the peripheral.
    }

    if(MarkActiveTimer)          // If the Mark timer is active then the Mark peripheral is active.
    {                            // this will disable the peripheral when has been enabled for the requested time
        MarkActiveTimer--;       // Decrement it.  
        if(!MarkActiveTimer)     // If the mark timer just decremented from 1 to 0
            Mark(0);             // Disable the peripheral
    }

    if(TR65Timeout)              // If we are counting and are currently running a test.  If this counts down to zero then it means that the TR-65 was late reading the tag.
    {
        TR65Timeout--;                    // If the timer has any time on it then decrement it.
        if(!TR65Timeout)                  // If the timer just decremented from 1 to 0
        {
            if(GTestInProcessState == 1)
                GTestInProcessState = 2;    // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timed out.
        }
    }
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);    //Reset the interrupt flag
    
}




void __ISR(_TIMER_2_VECTOR, ipl1AUTO) _IntHandlerDrvTmrInstance1(void)   // Runs at 187242Hz
{

    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_2);
    EncoderTimerRollovers++;     // Global uint16_t Counts roll overs of the timer used to measure velocity.

}

void __ISR(_RTCC_VECTOR, ipl2AUTO) _IntHandlerRTCC(void)
{
    static bool tgl;

    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_RTCC);
    
    if(tgl)
    {
        tgl=0;
    }
    else
    {
        tgl=1;
    }
    
}


 
/*******************************************************************************
 End of File
*/

