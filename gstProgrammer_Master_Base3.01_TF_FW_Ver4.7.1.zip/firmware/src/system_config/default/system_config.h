/*******************************************************************************
  MPLAB Harmony System Configuration Header

  File Name:
    system_config.h

  Summary:
    Build-time configuration header for the system defined by this MPLAB Harmony
    project.

  Description:
    An MPLAB Project may have multiple configurations.  This file defines the
    build-time options for a single configuration.

  Remarks:
    This configuration header must not define any prototypes or data
    definitions (or include any files that do).  It only provides macro
    definitions for build-time configuration options that are not instantiated
    until used by another MPLAB Harmony module or application.
    
    Created with MPLAB Harmony Version 1.06
*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

#ifndef _SYSTEM_CONFIG_H
#define _SYSTEM_CONFIG_H

/* This is a temporary workaround for an issue with the peripheral library "Exists"
   functions that causes superfluous warnings.  It "nulls" out the definition of
   The PLIB function attribute that causes the warning.  Once that issue has been
   resolved, this definition should be removed. */
#define _PLIB_UNSUPPORTED


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
/*  This section Includes other configuration headers necessary to completely
    define this configuration.
*/

#include "bsp_config.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Service Configuration
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Common System Service Configuration Options
*/
#define SYS_VERSION_STR           "1.06"
#define SYS_VERSION               10600

// *****************************************************************************
/* Clock System Service Configuration Options
*/
#define SYS_CLK_FREQ                        48000000ul
#define SYS_CLK_BUS_PERIPHERAL_1            48000000ul
#define SYS_CLK_UPLL_BEFORE_DIV2_FREQ       96000000ul
#define SYS_CLK_CONFIG_PRIMARY_XTAL         8000000ul
#define SYS_CLK_CONFIG_SECONDARY_XTAL       32768ul
   
/*** Interrupt System Service Configuration ***/
#define SYS_INT                     true

/*** Ports System Service Configuration ***/

#define SYS_PORT_A_ANSEL        0x0
#define SYS_PORT_A_TRIS         0x0200
#define SYS_PORT_A_LAT          0x0
#define SYS_PORT_A_ODC          0x0
#define SYS_PORT_A_CNPU         0x0
#define SYS_PORT_A_CNPD         0x0
#define SYS_PORT_A_CNEN         0x0

#define SYS_PORT_B_ANSEL        0x0
#define SYS_PORT_B_TRIS         0xD984
#define SYS_PORT_B_LAT          0x40
#define SYS_PORT_B_ODC          0x0
#define SYS_PORT_B_CNPU         0x0
#define SYS_PORT_B_CNPD         0x0
#define SYS_PORT_B_CNEN         0x0

#define SYS_PORT_C_ANSEL        0xf000
#define SYS_PORT_C_TRIS         0xF000
#define SYS_PORT_C_LAT          0x0
#define SYS_PORT_C_ODC          0x0
#define SYS_PORT_C_CNPU         0x0
#define SYS_PORT_C_CNPD         0x0
#define SYS_PORT_C_CNEN         0x0

#define SYS_PORT_D_ANSEL        0x0
#define SYS_PORT_D_TRIS         0x0081
#define SYS_PORT_D_LAT          0x0
#define SYS_PORT_D_ODC          0x0
#define SYS_PORT_D_CNPU         0x0
#define SYS_PORT_D_CNPD         0x0
#define SYS_PORT_D_CNEN         0x0

#define SYS_PORT_E_ANSEL        0x0
#define SYS_PORT_E_TRIS         0x007C
#define SYS_PORT_E_LAT          0x0
#define SYS_PORT_E_ODC          0x0
#define SYS_PORT_E_CNPU         0x0
#define SYS_PORT_E_CNPD         0x0
#define SYS_PORT_E_CNEN         0x0

#define SYS_PORT_F_ANSEL        0x0
#define SYS_PORT_F_TRIS         0x1000   
#define SYS_PORT_F_LAT          0x0
#define SYS_PORT_F_ODC          0x0
#define SYS_PORT_F_CNPU         0x0
#define SYS_PORT_F_CNPD         0x0
#define SYS_PORT_F_CNEN         0x0

#define SYS_PORT_G_ANSEL        0x0
#define SYS_PORT_G_TRIS         0x7202    // WAS 0X7002
#define SYS_PORT_G_LAT          0x0
#define SYS_PORT_G_ODC          0x0
#define SYS_PORT_G_CNPU         0x0
#define SYS_PORT_G_CNPD         0x0
#define SYS_PORT_G_CNEN         0x0


// *****************************************************************************
// *****************************************************************************
// Section: Driver Configuration
// *****************************************************************************
// *****************************************************************************

/*** Timer Driver Configuration ***/
#define DRV_TMR_INTERRUPT_SOURCE_IDX0       INT_SOURCE_TIMER_3
#define DRV_TMR_INTERRUPT_SOURCE_IDX1       INT_SOURCE_TIMER_2

 

/*** SPI Driver Configuration ***/
#define DRV_SPI_NUMBER_OF_MODULES		4
/*** Driver Compilation and static configuration options. ***/
/*** Select SPI compilation units.***/
#define DRV_SPI_POLLED 				0
#define DRV_SPI_ISR 				0
#define DRV_SPI_MASTER 				0
#define DRV_SPI_SLAVE 				0
#define DRV_SPI_RM 				0
#define DRV_SPI_EBM 				0
#define DRV_SPI_8BIT 				0
#define DRV_SPI_16BIT 				0
#define DRV_SPI_32BIT 				0
#define DRV_SPI_DMA 				0

/*** SPI Driver Static Allocation Options ***/
#define DRV_SPI_INSTANCES_NUMBER 		
#define DRV_SPI_CLIENTS_NUMBER 			
#define DRV_SPI_ELEMENTS_PER_QUEUE 		

// *****************************************************************************
// *****************************************************************************
// Section: Middleware & Other Library Configuration
// *****************************************************************************
// *****************************************************************************

/*** USB Driver Configuration ***/


/* Enables Device Support */
#define DRV_USBFS_DEVICE_SUPPORT      true

/* Disable Device Support */
#define DRV_USBFS_HOST_SUPPORT      false

/* Maximum USB driver instances */
#define DRV_USBFS_INSTANCES_NUMBER    1


/* Interrupt mode enabled */
#define DRV_USBFS_INTERRUPT_MODE      true


/* Number of Endpoints used */
#define DRV_USBFS_ENDPOINTS_NUMBER    2

/*** USB Device Stack Configuration ***/

/* The USB Device Layer will not initialize the USB Driver */
#define USB_DEVICE_DRIVER_INITIALIZE_EXPLICIT

/* Maximum device layer instances */
#define USB_DEVICE_INSTANCES_NUMBER     1

/* EP0 size in bytes */
#define USB_DEVICE_EP0_BUFFER_SIZE      64

/* Maximum instances of HID function driver */
#define USB_DEVICE_HID_INSTANCES_NUMBER     1

/* HID Transfer Queue Size for both read and
   write. Applicable to all instances of the
   function driver */
#define USB_DEVICE_HID_QUEUE_DEPTH_COMBINED 2


// *****************************************************************************
/* BSP Configuration Options
*/
#define BSP_OSC_FREQUENCY 8000000

#define APP_MAKE_BUFFER_DMA_READY

#define APP_USB_LED_1 BSP_LED_1
#define APP_USB_LED_2 BSP_LED_2
#define APP_USB_LED_3 BSP_LED_3

#define APP_USB_SWITCH_1 BSP_SWITCH_1
#define APP_USB_SWITCH_2 BSP_SWITCH_2

//Barry
#define REGULATOR_ON    1
#define REGULATOR_OFF   0
#define MOTOR_ON        0
#define MOTOR_OFF       1
#define LOW             0
#define HIGH            1
#define LEDON           0
#define LEDOFF          1
#define MOTOR_DATA      2
#define LED_DATA        1
#define READEPC         0x01
#define READTID         0x08
#define EPC1GEN2        0x01
#define DOSENSTEST      0x04

// Joe
#define LED1 1
#define LED2 2
#define LED3 3
#define LED4 4
#define LED5 5
#define LED6 6
#define LED7 7
#define LED8 8
#define OFF  0
#define ON   1

//Defines for all I/O pins that are outputs
#define MARK            PORTS_BIT_POS_15     // Port G, Pin 1  O
#define CAM_OUT1        PORTS_BIT_POS_5      // Port E, Pin 3  I
#define RFID_GPO_0      PORTS_BIT_POS_6      // Port E, Pin 4  I
#define RFID_ENABLE     PORTS_BIT_POS_7      // Port E, Pin 5  O
#define TP79            PORTS_BIT_POS_1      // Port C, Pin 6  O
#define LED_DAT         PORTS_BIT_POS_2      // Port C, Pin 7  O
#define LED_SCLK        PORTS_BIT_POS_3      // Port C, Pin 8  O
#define LED_RCLK        PORTS_BIT_POS_4      // Port C, Pin 9  O
#define TP81            PORTS_BIT_POS_6      // Port G, Pin 10 O
#define TP72            PORTS_BIT_POS_7      // Port G, Pin 11 O
#define TP82            PORTS_BIT_POS_8      // Port G, Pin 12 O
#define TP64            PORTS_BIT_POS_9      // Port G, Pin 14 O
#define TP73            PORTS_BIT_POS_0      // Port A, Pin 17 O
#define TP84            PORTS_BIT_POS_8      // Port E, Pin 18 O    
#define CAMERA_ENABLE   PORTS_BIT_POS_9      // Port E, Pin 19 O 
#define TP86            PORTS_BIT_POS_3      // Port B, pin 22 O
#define CAM_READY       PORTS_BIT_POS_2      // Port B, Pin 23 I
#define TP65            PORTS_BIT_POS_6      // Port B, Pin 26 O
#define CAM_OUT2        PORTS_BIT_POS_7      // Port B, Pin 27 I  
#define CAM_STROBE      PORTS_BIT_POS_9      // Port A, Pin 28 I
#define CAM_TEACH       PORTS_BIT_POS_10     // Port A, Pin 29 O
#define BANNER_1        PORTS_BIT_POS_8      // Port B, Pin 32 I 
#define CAM_TRIG        PORTS_BIT_POS_9      // Port B, Pin 33 O
#define TP52            PORTS_BIT_POS_10     // Port B, Pin 34 O
#define CAM_OUT3        PORTS_BIT_POS_11     // Port B, Pin 35 I
#define TP47            PORTS_BIT_POS_1      // Port A, Pin 38 O
#define TP48            PORTS_BIT_POS_13     // Port F, pin 39 O
#define MISO            PORTS_BIT_POS_12     // Port F, pin 40 I
#define RFID_GPO_1      PORTS_BIT_POS_12     // Port B, Pin 41 I  
#define TEMP_CS         PORTS_BIT_POS_13     // Port B, Pin 42 O 
#define ENCODER_B       PORTS_BIT_POS_14     // Port B, Pin 43 I
#define TP32            PORTS_BIT_POS_14     // Port D, Pin 47 O
#define TP33            PORTS_BIT_POS_15     // Port D, pin 48 O
#define TP24            PORTS_BIT_POS_3      // Port F, Pin 51 O
#define AUX             PORTS_BIT_POS_2      // Port F, Pin 52 O 
#define PUNCH           PORTS_BIT_POS_8      // Port F, Pin 53 O
#define TP12            PORTS_BIT_POS_2      // Port A, Pin 58 O  
#define TP13            PORTS_BIT_POS_3      // Port A, Pin 59 O
#define TP16            PORTS_BIT_POS_4      // Port A, Pin 60 O
#define TP17            PORTS_BIT_POS_5      // Port A, Pin 61 O 
#define TP10            PORTS_BIT_POS_14     // Port A, Pin 66 O
#define FRAM_CS         PORTS_BIT_POS_15     // Port A, Pin 67 O
#define EE_CS           PORTS_BIT_POS_8      // Port D, Pin 68 O
#define ENCODER_A       PORTS_BIT_POS_0      // Port D, Pin 72 I 
#define RF_MOSI         PORTS_BIT_POS_2      // Port D, Pin 77 O
#define DA_CS           PORTS_BIT_POS_3      // Port D, Pin 78 O
#define BANNER_ENABLE   PORTS_BIT_POS_12     // Port D, Pin 79 O
#define FAD_CS          PORTS_BIT_POS_13     // Port D, Pin 80 O 
#define RAD_CS          PORTS_BIT_POS_4      // Port D, Pin 81 O
#define ATT_LE          PORTS_BIT_POS_5      // Port D, Pin 82 O
#define RF_SCLK         PORTS_BIT_POS_6      // Port D, Pin 83 O
#define RF_MISO         PORTS_BIT_POS_7      // Port D, Pin 84 I
#define TP31            PORTS_BIT_POS_0      // Port F, Pin 87 O  
#define TP30            PORTS_BIT_POS_1      // Port F, Pin 88 O   
#define BANNER_0        PORTS_BIT_POS_1      // Port G, Pin 89 I
#define RFID_GPI_0      PORTS_BIT_POS_0      // Port G, Pin 90 O
#define TP40            PORTS_BIT_POS_6      // Port A, Pin 91 O
#define RFID_GPI_1      PORTS_BIT_POS_7      // Port A, Pin 92 O 
#define TP45            PORTS_BIT_POS_0      // Port E, Pin 93 O
#define TP46            PORTS_BIT_POS_1      // Port E, Pin 94 O
#define CONFIG1         PORTS_BIT_POS_14     // Port G, Pin 95 I 
#define CONFIG2         PORTS_BIT_POS_12     // Port G, Pin 96 I
#define CONFIG4         PORTS_BIT_POS_13     // Port G, Pin 97 I
#define CONFIG8         PORTS_BIT_POS_2      // Port E, Pin 98 I
#define PUSH1           PORTS_BIT_POS_3      // Port E, Pin 99 I
#define PUSH2           PORTS_BIT_POS_4      // Port E, Pin 100 I

#endif // _SYSTEM_CONFIG_H
/*******************************************************************************
 End of File
*/

