//*******************************************************************************
//  C Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    PCB Peripherals.c
//    Drivers for all the Peripherals on the PCB.  
//
//  Last Edit Date:  Aug  27 2017   JRL    Change pinouts for rev B board set.
//  Last Edit Date:  Oct   3 2016   JRL    Clean up after calibration debug.
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************

#include "system_config.h"
//#include <stdint.h>
//#include <stdbool.h>
//#include <stddef.h>
//#include <stdlib.h>
//#include <string.h>
#include "globals.h"
#include "peripheral/usart/plib_usart.h"
//#include "peripheral/devcon/plib_devcon.h"
//#include "system/debug/sys_debug.h"


// Function Prototypes //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void NudgeSerialTransmitters(void);                   // Sends characters out each serial port if there are some to send.
void GetMAC(void);                                    // Gets MAC address from the W25q128FV 128Mb 16MBx8 Serial Flash
void MainLoopStuff(void);                             // Called from the main loop.  Pass in a 1 to initialize stuff.
void ReverseString(char *InString);                   // Reverse the string in place.
uint16_t GetAD(uint8_t);                              // refreshes and returns a 12 bit, right justified, (2.048 / 2e12 ) * N in volts, MSB First. from the selected channel
void Get_Temp(void);                                  // refreshes and returns the temperature in degrees C from the TC77.  Limited to temps from 1 Degree C to +125 Degrees C.  
                                                      // A return of 0 means the temp is less than 1 degree.  A return of 126 means the temp is greater than 125 degrees C.
void SetDAC(uint16_t RequestedAttenuation);           // Drives LTC2630 (12 bit DAC)
void SetRFAttenuation(uint16_t);                      // Pass in Desired attenuation level 0..127.    Upper bits contain the Address of the Attenuator and should be 0.
void NudgeInit_RFID(uint8_t);                         // send normal startup instructions to the RFID peripheral,  Pass in which string to send.  Returns 1 when the string is sent.
void TuneRFID(uint32_t);                              // Pass in uint32_t frequency, and this will format it and send it to the RFID interface.
uint8_t SPI_Transaction8(bool, uint16_t, uint8_t);    // RW is the Read/Write, Where is the 16 bit address, WhattoWrite is the 8 bit value to put there
uint8_t FRAMRead8(uint16_t);                          // pass in uint16_t Address 
void FRAMWrite8(uint16_t, uint8_t);                   // pass in uint16_t Address and uint8_t WhatToWrite
uint8_t BSPI_Transaction8(bool, uint32_t, uint8_t);   // RW is the Read/Write, Where is the 18 bit address, WhattoWrite is the 8 bit value to put there
uint8_t BFRAMRead8(uint32_t);                         // pass in uint32_t containing the FRAMs 18 bit Address to be read
void BFRAMWrite8(uint32_t, uint8_t);                  // pass in uint32_t containing the FRAMs 18 bit Address to be written to and uint8_t WhatToWrite
void CalculateMediaVelocity(void);                    // Uses Global variables to refresh Global uint16_t VelocityCentiInchPerSecond
void EraseW25Q128FV(void);                            // Performs CHIPERASE on the W25q128FV 128Mb 16MBx8 Serial Flash
void MaintainMarkPunchArray(void);                    // Checks to see if it's time to mark or punch.
void MarkOrPunchLabel(void);                          // Stuff the MarkPunch array so that the label will be processed per the Mark and punch settings.
void InitMarkPunchArray(void);                        // Zeros out the entire Array
void ToggleMark(void);                                // Simply toggle the Mark Peripheral.  used for command 0x1E
void Punch(int8_t);                                   // Pass in a 0 to retract the punch and a 1 to extend the punch.   This performs the inversion if required.
void Mark(int8_t);                                    // Pass in a 0 to untrigger and a 1 to trigger the mark peripheral.
void WriteFLASH8(uint32_t,uint8_t);                   // Write one Byte to Flash.  Pass in 32 bit Address and a 8 byte data to write
uint8_t ReadFLASH8(uint32_t);                         // Read one Byte from Flash. Pass in 32 bit Address and get a 8 byte data back
void ControlTP(uint8_t, uint8_t);                     // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
void ChangedTestModeState(void);                      // DEBUG ONLY.   Remove all traces of this function before use.

//***************************************************************************************************
//  Main Loop Stuff.   this function is called once for each pass through the Harmony main loop.
//  it takes care of all the maintenance of the PCB mounted peripherals such as serial ports, attenuator control, 
//  AD Converters and NV Memory devices.
//***************************************************************************************************

void MainLoopStuff(void) // Called from the Harmony main loop    ~10uS 
{
static uint16_t  AttenuatorReq;
static uint32_t  Loop32Counter = 0;
static uint16_t  LoopCounter = 0;
static uint8_t   SecondCounter = 0;
static uint8_t   Button1Counter = 0;        // Debounce
static uint8_t   Button1State = 0;          // 0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.
static bool      OldButton1State = 0;
static bool      CurrentButton1State = 0;
static uint8_t   Button2Counter = 0;        // Debounce
static uint8_t   Button2State = 0;          // 0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.
static bool      OldButton2State = 0;
static bool      CurrentButton2State = 0;
static bool      DumpFlash = 0;
static uint8_t   DipSwitchVal;
//static bool      SweepEnable = 0;
//static uint32_t  SweepFreq = 90000;
//static int8_t counter = 0;
//uint8_t JustAnInt = 0;
//uint8_t SeekRFChannel;
//static uint16_t Loop16Counter = 0;
//static uint8_t WhichRfidInitString = 3;
//static uint8_t LoopCounterIn = 0;
//static uint8_t LoopCounterOut = 0;
//static uint8_t FCounter = 0;
//static uint8_t ACounter = 5;
//uint8_t Success = 0;                    // Returns 1 if the function call was successful, or 0 if not successful
//static bool WaitingForTR65Ack = 0;      // Set when a message has been sent to TR-65 and we are waiting for the reply that indicates success. 
//static bool SweepTriggered = 0;
//static uint32_t RfidFreq = 0;


    // TODO  Remove all the debug stuff ------------------------------------------------------------------------------------------------------------------

    NudgeSerialTransmitters();                // Send characters from any pending queues out their selected serial port

    if (Uart4CRGot == 1)                      // If we just received a Carriage Return from Camera Serial port
    {
        Uart4RxBuf[Uart4RXpointer++] = 0;     // Add a NULL to the end of the string.
        DebugOut( sprintf(Uart5TxBuf, "Camera said %s \n", Uart4RxBuf) );
        Uart4RXpointer = 0;                   // Zero out the Receive pointer since we processed the string
        Uart4CRGot = 0;                       // Get Ready for the next detection.
    }

    if (Uart5CRGot == 1)                      // If we just received a Carriage Return from DEBUG Serial port
    {
        Uart5CRGot = 0;                       // Get Ready for the next detection.
        Uart5RxBuf[Uart5RXpointer++] = 0;     // Add a NULL to the end of the string.
        Uart5RXpointer = 0;                   // Zero out the Receive pointer since we processed the string
        strcpy(Uart3TxBuf, Uart5RxBuf);
        ReverseString(Uart3TxBuf);            // Reverse the string in place.            
        Uart3TXpointer = strlen(Uart3TxBuf);  // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out

        if( (Uart5RxBuf[0]=='S') && (Uart5RxBuf[1]=='A') )         // Permit manual commands to the Step Attenuator. Send SA in Caps and three digits; SA010
        {                                                          // 0 - 127 is useable.  The higher the number the higher the attenuation.
            AttenuatorReq = ( Uart5RxBuf[2] - 48 ) * 100;
            AttenuatorReq = AttenuatorReq + ((Uart5RxBuf[3] - 48)  * 10);
            AttenuatorReq =   AttenuatorReq + (Uart5RxBuf[4] - 48);
            SetRFStepAttenuation(AttenuatorReq); 
            DebugOut( sprintf(Uart5TxBuf, "StepAtt %lu \r\n",AttenuatorReq) );
        }

        if( (Uart5RxBuf[0]=='A') && (Uart5RxBuf[1]=='A') )         // Permit manual commands to the Analog Attenuator. Send AA in Caps and four digits; AA4050
        {                                                          // 0 - 4096 accepted, 1148 - 2785 is useable.   The higher the number the higher the attenuation.
            AttenuatorReq = ( Uart5RxBuf[2] - 48 ) * 1000;         // The attenuator provides 33dB / Volt.  1148 = .7 Volts resulting in ~1.4dB attenuation. 2785 = 1.7V resulting in ~34.4dB attenuation. 
            AttenuatorReq = AttenuatorReq + ((Uart5RxBuf[3] - 48)  * 100);
            AttenuatorReq = AttenuatorReq + ((Uart5RxBuf[4] - 48)  * 10);
            AttenuatorReq = AttenuatorReq + ( Uart5RxBuf[5] - 48);
            SetRFAnalogAttenuation(AttenuatorReq); 
            DebugOut( sprintf(Uart5TxBuf, "AnaAtt %lu \r\n",AttenuatorReq) );
        }


    }
    
    // Button 1 DEBOUNCE ----------------------------------------------------------------------------------------
    CurrentButton1State = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, PUSH1);   // Read the button 
    if(CurrentButton1State != OldButton1State)      // If the button state just changed.
        Button1Counter = 128;                       // Set the counter to the center of the range.
    OldButton1State = CurrentButton1State;          // Save the value so that we can compare next time thru the loop.
    
    if (!CurrentButton1State)                       // If button is pressed
    {
        //PushSwRunStop = 1;
        //FCounter = 0;
        //SetRFAttenuation(0);   
        //RfidFreq = 86000;        
       
        if(Button1Counter < 255)      // Debounce
            Button1Counter++;         // If not already maxed out, then increment
        if(Button1Counter == 250)     // Just before we hit the top.
            Button1State = 1;         // 0 = Released, 1 = Just Pressed, 2 = Pressed, 3 = Just Released.
    }
    else                              // button is not pressed.
    {
        if(Button1Counter > 1)        // Debounce
            Button1Counter--;         // If not already at the bottom, then decrement
        if(Button1Counter == 2)       // Just before we hit the bottom
            Button1State = 3;         // 0 = Released, 1 = Just Pressed, 2 = Pressed, 3 = Just Released.
    }


    if(Button1State == 1)             // the button was just pressed
    {
        Button1State = 2;             // Now we are processing the press.
        //TestModeState = INITTEST0X10;
        DipSwitchVal = ReadDipSwitch();
        
        //SweepFreq = 89000;
        
//        if(DipSwitchVal == 0x05)
//            EraseW25Q128FV();         // Performs CHIPERASE on the W25q128FV 128Mb 16MBx8 Serial Flash.  This will erase CALIBRATION Data     
        
        if(DipSwitchVal == 0x0F)
        {
            Loop32Counter=0;    
            DumpFlash = 1;
        }
    }

    if(Button1State == 3)             // the button was just Released
        Button1State = 0;             // Now we are processing the release.
        
    // Button 2 DEBOUNCE ----------------------------------------------------------------------------------------
    CurrentButton2State = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_E, PUSH2);   // Read the button 
    if(CurrentButton2State != OldButton2State)      // If the button state just changed.
        Button2Counter = 128;                       // Set the counter to the center of the range.
    OldButton2State = CurrentButton2State;          // Save the value so that we can compare next time thru the loop.
    
    if (!CurrentButton2State)         // If button is pressed
    {
        if(Button2Counter < 255)      // Debounce
            Button2Counter++;         // If not already maxed out, then increment
        if(Button2Counter == 250)     // Just before we hit the top.
            Button2State = 1;         // 0 = Released, 1 = Just Pressed, 2 = Pressed, 3 = Just Released.
    }
    else                              // button is not pressed.
    {
        if(Button2Counter > 1)        // Debounce
            Button2Counter--;         // If not already at the bottom, then decrement
        if(Button2Counter == 2)       // Just before we hit the bottom
            Button2State = 3;         // 0 = Released, 1 = Just Pressed, 2 = Pressed, 3 = Just Released.
    }


    if(Button2State == 1)             // the button was just pressed
    {
        Button2State = 2;             // Now we are processing the press.
        //PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_E, RFID_ENABLE, REGULATOR_OFF );
        //appCmd14Data.enable = 1;    // Enable the entire tester.
        //TriggertheTest();           // Toggle GPI1 on the TR-65
        //JustGotNewLabelTrigger();     // fiber optic detector or Camera just detected a new label.
        
//        if(SweepEnable)
//            SweepEnable = 0;
//        else
//            SweepEnable = 1;
//        
        
        //DebugOut( sprintf(Uart5TxBuf, "Test 1 \n\r") );
        //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, HIGH);    // Set TR-65s GPI pin to trigger a read
        //TR65TriggerLen = 10;                                                  // Hardware trigger pulse is reset upon zero as it decrements to zero in the 1mS ISR.
    }

    if(Button2State == 3)             // the button was just Released
    {
        Button2State = 0;             // Now we are processing the release.
        //PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_E, RFID_ENABLE, REGULATOR_ON );
    }
    
   
    
    // **************************************************************************
    //  Tenth second Tasks      Runs each tenth second after things get rolling.
    // **************************************************************************   
    if ( Counter1mS == 0 )     // Decremented in the Timer3 ISR.
    {
        //DebugOut( sprintf(Uart5TxBuf, "Test 1 \n\r") );

        Counter1mS = 100;      // Set to trigger again in a tenth of a second
        SecondCounter++;       // Counts mS to find a second.

        //ControlTP(31,1);                              // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
        //ControlTP(31,0);                              // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
        
//        if(SweepEnable)
//        {
//
//            SweepFreq += 10;
//            if(SweepFreq > 93000)
//                SweepFreq = 90000;
//
//            sprintf(Uart3TxBuf,"RF%lu\r\n",SweepFreq);   // Send the 5 most significant digits
//            ReverseString(Uart3TxBuf);                   // Reverse the string in place.            
//            Uart3TXpointer = strlen(Uart3TxBuf);         // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
//        
//        }
        
        CalculateMediaVelocity();                          // Uses Global variables to refresh Global uint16_t VelocityCentiInchPerSecond
        if(VelocityCentiInchPerSecond > 2400)
            Send0XE5EventNoticeToHost(0x02);               // Send USB Event Notice to HOST.   0x02   Web velocity is faster than 20 FPS
                                                           // it fails arount 24FPS with no other interrupts running.  It looses accuracy when USB traffic increases.
        // This calculates the number of TICS that the punch should fire early due to the velocity of the web.  
        // the punch diameter is .25 inch, we can be late up to .125 inch and still hit the chip.  
        // Inch per second / Tics per inch / Punch Flight time.  Then we round the result by (adding 4999) to the nearest integer.   
        WebVelocityEncoderTicCorrection =  ((VelocityCentiInchPerSecond * Cmd21_TicsPerInch * appCmd1dData.punchflight) + 4999 ) / 10000;    // Num Tics to subtract from the TIC offset for Punch.
        
        // DebugOut( sprintf(Uart5TxBuf, " CentiInchPerSec = %lu %lu\r\n",VelocityCentiInchPerSecond,WebVelocityEncoderTicCorrection) );
        //CurrentFAD = GetAD(0);  // TODO   Add Filtering.   // Pass in selected channel; 0 = Forward, 1 = Reverse; 
        //CurrentRAD = GetAD(1);  // TODO   Add Filtering.   // Pass in selected channel; 0 = Forward, 1 = Reverse; 
        //DebugOut( sprintf(Uart5TxBuf, "FAD %lu  RAD %lu\r\n",CurrentFAD,CurrentRAD) );
        
        if(DumpFlash)         // If enabled by Push switch 
        { 
            if(Loop32Counter < 208928)    // Dumps out the CAL data for temperature 0
            {
                GetCalRecordFromFlash(Loop32Counter);
                DebugOut( sprintf(Uart5TxBuf, "%lu %u %u %lu %lu %lu\r\n",Loop32Counter,ACalRecord_SA,ACalRecord_AA,ACalRecord_FAD,ACalRecord_RAD,ACalRecord_PwrError) );
                Loop32Counter += 8;
            }  
            else
                DumpFlash = 0;
        }
    }

    //**************************************************************************
    // One Second Tasks       Runs each second after things get rolling.
    //**************************************************************************
    if (SecondCounter > 10)                // If more than 10  10mS ticks passed, then a second passed.
    {
        SecondCounter = 0;
        
        if(InitTr65Once)                   // Set to 3 on powerup.  The main line code will perform the init of the TR-65 three seconds after the unit comes out of reset.
        {
            InitTr65Once --;               // Decrement the counter.
            if(InitTr65Once == 0)          // If we just decremented from 1 to 0 then it's time to init the TR-65 RFID reader.
                TR65InitStateMachine = 1;  // 0 = Idle.   Anything else is part of the init routine.
        }
    }
    return;
}



 
void ChangedTestModeState(void)    // DEBUG ONLY.   Remove all traces of this function before use.
{
static uint8_t counter = 0;

    if(TestModeState == TESTMODEIDLE)  // Stop everything and goto the test IDLE mode.  
        counter++;

    if(TestModeState == INITTEST0X10)         // 00 Requestable States for TestModeState: Init a new test 0x10
       counter++;

    if(TestModeState == RUNTEST0X10)           // 01 Requestable States for TestModeState: Running test 0x10
       counter++;

    if(TestModeState == INITSTATICTESTS)           // 02 Requestable States for TestModeState: Init new static test
       counter++;

    if(TestModeState == RUNSTATICTESTS)          // 03 Requestable States for TestModeState: running Static Test
       counter++;

    if(TestModeState == INITDEBUGMODE0x6A)           // 04 Requestable States for TestModeState: Init Debug Mode for command 0x6A
       counter++;

    if(TestModeState == RUNDEBUGMODE0x6A)           // 05 Requestable States for TestModeState: Running tasks of Debug Mode for command 0x6A
       counter++;

    if(TestModeState == WAS_HS_GPIOMODE)          // 06 Requestable States for TestModeState: Unused
       counter++;

    if(TestModeState == WAS_HS_READERTEST)          // 07 Requestable States for TestModeState: Unused
       counter++;

    if(TestModeState == INITRFIDCAL)          // 08 Requestable States for TestModeState: Get ready to calibrate the RFID Interface
       counter++;

    if(TestModeState == RUNRFIDCAL)         // 09 Requestable States for TestModeState: Perform the calibration of the RFID Interface
       counter++;

    if(TestModeState == TESTMODEIDLE)          // 0A Requestable States for TestModeState: No user requested tests or user requested tasks running.   Immediate mode tasks from USB are permitted in this mode. 
       counter++;

    if(TestModeState == RUNDEBUGMODE0x1E)          // 0B Requestable States for TestModeState: Running tasks of Debug Mode for command 0x1E
       counter++;

    if(TestModeState == WAITFOR0X10TRIG)         // 0C Requestable States for TestModeState: We are waiting for the 0x10 test to be launched
       counter++;

    if(TestModeState == INITTEST0X0B)         // 0D Requestable States for TestModeState: RF Test Mode:   Init a new test 0x0B
       counter++;
}












// Calculate media Velocity ****************************************************************************
// There are 28 encoder ticks per inch
// Timer ticks runs at 188,000 ticks per second.
// inches per second = Number of 1mS timer ticks * 32 / 1000.
// Centi inches per second = Number of 1mS timer ticks * 32 / 10.

void CalculateMediaVelocity(void) // Uses Global variables to refresh Global uint16_t VelocityCentiInchPerSecond
{
static float TempFloat = 0.0; // Just for temporary use during calculations.          
static uint8_t temp;
//static uint32_t Temp32;

    //Temp32 = GlobalTimerTicksPerEncoderTick * EncoderTicksPerInch;          // Calculate the number of timer ticks in a full inch of media to get "# Timer ticks per inch"
    //TempFloat = (float)Temp32;                                              // Make a float

    TempFloat = (float) (GlobalTimerTicksPerEncoderTick * EncoderTicksPerInch); // Calculate the number of timer ticks in a full inch of media to get "# Timer ticks per inch"
    TempFloat = 188000 / TempFloat; // Divide by the number of tics per second to get inches per second.
    TempFloat = TempFloat * 10; // Multiply by 10 to get Centi Inches per second.
    VelocityCentiInchPerSecond = (uint16_t) TempFloat; // Save in a Global as a uint16_t       
    if(VelocityCentiInchPerSecond>100)
        temp = 1;
}

void TuneRFID(uint32_t WhatFreq) 
{
    sprintf(Uart3TxBuf, "RF%lu\r\n", WhatFreq);
    ReverseString(Uart3TxBuf); // Reverse the string in place.            
    Uart3TXpointer = strlen(Uart3TxBuf); // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
}




void ControlTP(uint8_t Which, uint8_t Operation)      // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 64 65 72 73 79 81 82 84 86  
{                                                     // OP; 0 = Low, 1 = Hi, 2 = Toggle (FIRST 16 ONLY) 3 = All Low.  4 = All High
static uint16_t LastStates;

    if(Operation == 3)
    {
        LastStates = 0;
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP10, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP12, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP13, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP16, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP17, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP24, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP30, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP31, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP32, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP33, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP40, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP45, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP46, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP47, LOW);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP48, LOW);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP52, LOW);        
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP64, LOW);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, LOW);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP72, LOW); 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP73, LOW);        
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, TP79, LOW);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP81, LOW);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP82, LOW); 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP84, LOW);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP86, LOW); 
    }

    if(Operation == 4)
    {
        LastStates = 0XFFFF;
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP10, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP12, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP13, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP16, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP17, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP24, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP30, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP31, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP32, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP33, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP40, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP45, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP46, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP47, HIGH);    
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP48, HIGH);
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP52, HIGH);        
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP64, HIGH);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, HIGH);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP72, HIGH); 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP73, HIGH);        
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, TP79, HIGH);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP81, HIGH);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP82, HIGH); 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP84, HIGH);         
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP86, HIGH); 
    }

    if(Which == 10)                       // We are effecting change to TP10.
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0001)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }        
        if(Operation == 0)                // Set Low
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP10, LOW);
            LastStates &= 0xFFFE;
        }
        if(Operation == 1)                // Set High
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP10, HIGH);
            LastStates |= 0x0001;
        }
    }

    if(Which == 12)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0002)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP12, LOW);    
            LastStates &= 0xFFFC;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP12, HIGH);
            LastStates |= 0x0002;
        }
    }

    if(Which == 13)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0004)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }  
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP13, LOW);
            LastStates &= 0xFFFB;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP13, HIGH);
            LastStates |= 0x0004;
        }
    }

    if(Which == 16)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0008)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP16, LOW);
            LastStates &= 0xFFF7;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP16, HIGH);
            LastStates |= 0x0008;
        }
    }

    if(Which == 17 )
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0010)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP17, LOW); 
            LastStates &= 0xFFEF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP17, HIGH);
            LastStates |= 0x0010;
        }
    }

    if(Which == 24)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0020)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP24, LOW);  
            LastStates &= 0xFFCF;
        }        
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP24, HIGH); 
            LastStates |= 0x0020;
        }
    }

    if(Which == 30)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0040)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP30, LOW);
            LastStates &= 0xFFBF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP30, HIGH);
            LastStates |= 0x0040;
        }
    }

    if(Which == 31)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0080)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP31, LOW);
            LastStates &= 0xFF7F;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP31, HIGH);
            LastStates |= 0x0080;
        }
    }

    if(Which == 32)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0100)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP32, LOW);
            LastStates &= 0xFEFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP32, HIGH);
            LastStates |= 0x0100;
        }
    }

    if(Which == 33)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0200)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP33, LOW);
            LastStates &= 0xFCFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, TP33, HIGH);
            LastStates |= 0x0200;
        }
    }

    if(Which == 40)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0400)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP40, LOW);
            LastStates &= 0xFBFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP40, HIGH);
            LastStates |= 0x0400;
        }
    }

    if(Which == 45)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x0800)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP45, LOW);
            LastStates &= 0xF7FF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP45, HIGH);
            LastStates |= 0x0800;
        }
    }

    if(Which == 46)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x1000)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP46, LOW);
            LastStates &= 0xEFFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP46, HIGH);
            LastStates |= 0x1000;
        }
    }

    if(Which == 47)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x2000)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP47, LOW);
            LastStates &= 0xCFFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP47, HIGH);
            LastStates |= 0x2000;
        }
    }

    if(Which == 48)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x4000)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP48, LOW);
            LastStates &= 0xBFFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, TP48, HIGH);
            LastStates |= 0x4000;
        }
    }

    if(Which == 52)
    {
        if(Operation == 2)                // Toggle
        {
            if(LastStates & 0x8000)       // If it was High last time
                Operation = 0;            // Set it low
            else                          // It must have been low last time
                Operation = 1;            // Set it high
        }
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP52, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP52, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 64)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP64, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP64, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 65)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 72)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP72, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP72, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 73)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP73, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, TP73, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 79)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, TP79, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, TP79, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 81)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP81, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP81, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 82)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP82, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, TP82, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 84)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP84, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_E, TP84, HIGH);
            LastStates |= 0x8000;
        }
    }

    if(Which == 86)
    {
        if(Operation == 0)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP86, LOW);
            LastStates &= 0x7FFF;
        }
        if(Operation == 1)
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP86, HIGH);
            LastStates |= 0x8000;
        }
    }

}






void ToggleMark(void) // Simply toggle the Mark Peripheral
{
static bool Toggler;

    if (Toggler) 
    {
        Toggler = 0;
        Mark(0); // Disable the peripheral / Set marker to inactive          
    }
    else 
    {
        Toggler = 1;
        Mark(1); // Enable the peripheral / Set marker to Active.
    }
}


void NudgeInit_RFID(uint8_t WhichToSend) // send sets of instructions to the Thinkify TR-65 RFID Interface.  Pass in which string to send.
{ // Global variable specifies which mode is requested and therefore which set of setup strings to send.

    // RfidMode Global uint8_t  Used to select which set of TR-65 Strings to send. Mode 0 = CW Cal Mode.    Mode 1 = Single Trigger              

    switch (WhichToSend) 
    {
        case 2:
            if (RfidMode == 1) sprintf(Uart3TxBuf, "RF86000\r\n "); // build a string in the transmit buffer for the RFID CW tone generator frequency.
            if (RfidMode == 0) sprintf(Uart3TxBuf, "RF86000\r\n "); // build a string in the transmit buffer for the RFID CW tone generator frequency.
            break;

        case 1:
            if (RfidMode == 2) sprintf(Uart3TxBuf, "RO0\r\n "); // build a string in the transmit buffer for the RFID CW tone generator mode; RO0 = Tone OFF   RO1= TONE Idle    RO3 = Tone enabled
            if (RfidMode == 1) sprintf(Uart3TxBuf, "RO3\r\n "); // build a string in the transmit buffer for the RFID CW tone generator mode; RO0 = Tone OFF   RO1= TONE Idle    RO3 = Tone enabled
            if (RfidMode == 0) sprintf(Uart3TxBuf, "RA10\r\n "); // build a string in the transmit buffer for the RFID CW tone generator TX attenuator    RA1 is max power, RA19 is min power.
            break;

        case 0:
            if (RfidMode == 2) sprintf(Uart3TxBuf, "T1\r\n "); // build a string in the transmit buffer for the RFID CW tone generator mode; RO0 = Tone OFF   RO1= TONE Idle    RO3 = Tone enabled
            if (RfidMode == 1) sprintf(Uart3TxBuf, "RA10\r\n "); // build a string in the transmit buffer for the RFID CW tone generator TX attenuator    RA1 is max power, RA19 is min power.
            if (RfidMode == 0) sprintf(Uart3TxBuf, "RO3\r\n "); // build a string in the transmit buffer for the RFID CW tone generator mode; RO0 = Tone OFF   RO1= TONE Idle    RO3 = Tone enabled
            break;
    }

    ReverseString(Uart3TxBuf);              // Reverse the string in place.            
    Uart3TXpointer = strlen(Uart3TxBuf);    // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out

}







//***************************************************************************************************
//  Writes a 16 bit value to RF Step Attenuator U10 on the RF Subsystem board.   Pass in a 7 bit (0..127) value
//  Address bits are fixed at Address 0 to match IC U13 on the main board.
//***************************************************************************************************

void SetStepAttenuator(uint16_t RequestedAttenuation)    // Was SetRFAttenuation
{
//uint8_t temp;
static uint16_t DesiredAttenuation = 0;
static uint8_t LoopCounter;

    DesiredAttenuation = 0;                       // Ensure the value starts at 0 so we can "or" some bits in.
    DesiredAttenuation = RequestedAttenuation;    // Put the desired level into the bottom 8 bits
    // Upper 8 bits contain the Address and are already set to 0 to match the address of U10 on the PCB

    for (LoopCounter = 0; LoopCounter < 16; LoopCounter++)                     // Clock out 16 Bits. MSB first
    {
        if (DesiredAttenuation & 0x0001)
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, HIGH);    // Set the Bit
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, LOW);     // Reset the bit

        DesiredAttenuation = DesiredAttenuation >> 1;                          // Shift the word to the the next bit into the firing tube.

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, HIGH);        // Raise the clock
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);         // Then drop the clock to get a new bit.
    }

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, ATT_LE, HIGH);             // Attenuator Latch Enable.   Rising edge sets the new value into the attenuator
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, ATT_LE, LOW);              // Set it back low to get ready for the next setting.

    return;

}




//***************************************************************************************************
//  Writes a 24 bit value to the D/A converter that controls the Analog Attenuator on the RF Subsystem board.   
//  Drives Linear Technology LTC2630   Vout = ( Val / 4095 ) * 2.500V.
//  4 CMD bits.       0000 = Write command register. 0110 = Select internal Reference (power on default)
//  4 don't care bits
//  12 bit (0..4095) value for ratio request.
//  4 don't care bits
//***************************************************************************************************
void SetDAC(uint16_t RequestedAttenuation)
{
static uint16_t DesiredAttenuation = 0;                       
static uint8_t LoopCounter;

    DesiredAttenuation = 0;                                                    // Ensure the value starts at 0.
    DesiredAttenuation = RequestedAttenuation << 4;                            // Shift the requested value 4 places (4 LSB are zeros) and put in the working variable.

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, DA_LOAD, LOW);             // Put DAC Chip select low to enable the chip
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, LOW);             // Put MOSI low so we send zeros with each clock.

    for (LoopCounter = 0; LoopCounter < 8; LoopCounter++)                      // Clock out 8 Bits; All zeros to form the command that writes to the command register.
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, HIGH);        // Raise the clock
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);         // Then drop the clock to get put the the bit.
    }

    for (LoopCounter = 0; LoopCounter < 16; LoopCounter++)                     // Clock out 16 Bits. MSB first
    {
        if (DesiredAttenuation & 0x8000)
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, HIGH);    // Set the Bit
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_MOSI, LOW);     // Reset the bit

        DesiredAttenuation = DesiredAttenuation << 1;                          // Shift the word to the the next bit into the firing tube.

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, HIGH);        // Raise the clock to latch the bit
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);         // Then drop the clock to get ready for a new bit.
    }

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, DA_LOAD, HIGH);            // Set DAC Chip select High to latch the last command in and de-select the chip.

    return;

}




void ReverseString(char *InString) // reverse an ASCII string and send it back.
{ // Like function REVERSE from page 59 K&R
static uint8_t i;
static uint8_t j;
static char c;

    for (i = 0, j = strlen(InString) - 1; i < j; i++, j--) {
        c = InString[i];
        InString[i] = InString[j];
        InString[j] = c;
    }
    return;
}




//  Checks each transmit buffer.  It sends the character if there's a character to send

void NudgeSerialTransmitters(void) 
{

    // UART 3 RFID ///////////////////////////////////////////////
    if (Uart3TXpointer)                                                                    // If there is a character that needs to be sent.
    {
        if (PLIB_USART_TransmitterIsEmpty(USART_ID_3))                                     // If transmitter is empty
        {
            PLIB_USART_TransmitterByteSend(USART_ID_3, Uart3TxBuf[(Uart3TXpointer - 1)]);  // Send the next character
            Uart3TXpointer--; // decrement the pointer
        }
    }


    // UART 4 Camera /////////////////////////////////////////////
    if (Uart4TXpointer)                                                                    // If there is a character that needs to be sent.
    {
        if (PLIB_USART_TransmitterIsEmpty(USART_ID_4))                                     // If transmitter is empty
        {
            PLIB_USART_TransmitterByteSend(USART_ID_4, Uart4TxBuf[(Uart4TXpointer - 1)]);  // Send the next character
            Uart4TXpointer--; // decrement the pointer
        }
    }

    // DEBUG Port on Connector J14   //////////////////////////////
    if(Uart5Tailpointer != Uart5Headpointer)                                               // If the pointers are not equal then there are characters to send.
    {
        if (PLIB_USART_TransmitterIsEmpty(USART_ID_5)) // If transmitter is empty
        {
            //ControlTP(49,1); // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
            //ControlTP(49,0); // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

            PLIB_USART_TransmitterByteSend(USART_ID_5, Uart5CircBuf[Uart5Tailpointer]);    // Send the oldest character in the ring.
            if( Uart5Tailpointer == (MAXSERBUF-1) )                                        // if we are at the last character in the ring then go to the first character in the ring.
                Uart5Tailpointer = 0;                                                      // then go to the first character in the ring.
            else                                                                           // if not
                Uart5Tailpointer++;                                                        // then point to the next char in the ring for next time.
        }               
    }
    return;
}

//***************************************************************************************************
//  FRAM Write:  Writes a 8 bit value from the selected (16 bit) address to the FRAM memory
//***************************************************************************************************

void FRAMWrite8(uint16_t Address, uint8_t WhatToWrite) // pass in uint16_t Address and uint8_t WhatToWrite.  For use with Cypress FM25V01A   Addresses 0000 - 1FFF
{ // FM25V01 is 16K X 8
    SPI_Transaction8(1, Address, WhatToWrite); // Pass in bool RW; 0 = Read, 1 = Write, uint16_t WhereToWrite, uint8_t WhatToWrite.
}


//***************************************************************************************************
//  Big FRAM Write:  Writes a 8 bit value from the selected (24 bit) address to the FRAM memory
//***************************************************************************************************

void BFRAMWrite8(uint32_t Address, uint8_t WhatToWrite) // pass in uint32_t Address and uint8_t WhatToWrite.  For use with Cypress FM25V20A
{ // FM25V20 is 256K X 8 
    BSPI_Transaction8(1, Address, WhatToWrite); // Pass in bool RW; 0 = Read, 1 = Write, uint32_t WhereToWrite, uint8_t WhatToWrite
}




//***************************************************************************************************
//  FRAM Read:  Reads a 8 bit value from the selected (16 bit) address from the FRAM memory
//***************************************************************************************************

uint8_t FRAMRead8(uint16_t Address) // pass in uint16_t Address.  For use with Cypress FM25V01 (16K X 8)
{    
    uint8_t ReturnVal;

    ReturnVal = SPI_Transaction8(0, Address, 0); // Pass in bool RW; 0 = Read, 1 = Write, uint16_t WhereToWrite, uint8_t WhatToWrite, bool WhichDevice; 0 = MAC, 1 = FRAM
    return (ReturnVal); // WhatToWrite is ignored during reads.
}


//***************************************************************************************************
//  Big FRAM Read:  Reads a 8 bit value from the selected (24 bit) address from the FRAM memory
//***************************************************************************************************

uint8_t BFRAMRead8(uint32_t Address) // pass in uint32_t Address.  For use with Cypress FM25V20 
{ // FM25V20 is 256K X 8 
    uint8_t ReturnVal;

    ReturnVal = BSPI_Transaction8(0, Address, 0); // Pass in bool RW; 0 = Read, 1 = Write, uint32_t WhereToWrite, uint8_t WhatToWrite
    return (ReturnVal); // WhatToWrite is ignored during reads.
}

//***************************************************************************************************
//  Reads a 48 bit MAC address from the Windbond W25q128FV 128Mb 16MBx8 Serial Flash
//***************************************************************************************************

void GetMAC(void) // Gets MAC address from W25q128FV 128Mb 16MBx8 Serial Flash
{
    uint8_t DatToSend;
    uint8_t WhatWasRead;
    uint8_t LoopCounter;

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW); // Set FLASH Chip select LOW to select it.
    DatToSend = 0x4B; // Set the command to read the 64 bit unique (MAC address) ID
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Starting address of the MAC Address as Byte 1
    DatToSend = 0; // These next bytes are ignored during a READ
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Dummy Byte as Byte 2
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Dummy Byte as Byte 3
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Dummy Byte as Byte 4
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Dummy Byte as Byte 5
    for (LoopCounter = 0; LoopCounter < 8; LoopCounter++) // get 64 bits (8 sets of 8 bits) of MAC Address                               
    { // MSB comes in first.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // when these bits are sent, 8 bits are shifted in.
        MacArray[7 - LoopCounter] = WhatWasRead; // LSB is in MacArray[0]
    }
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH); // Set EE MAC Chip select back high to un-select it

    return;
}


//***************************************************************************************************
//  Erases the entire Windbond W25q128FV 128Mb 16MBx8 Serial Flash with one command.  
//***************************************************************************************************

void EraseW25Q128FV(void)       // Performs CHIPERASE on the W25q128FV 128Mb 16MBx8 Serial Flash.   It sets all bits to 1s.  All bytes will be FFs.
{                               // This process takes between 40 and 200 Seconds.    Addresses run from 0x000000 to 0xFFFFFF
    uint8_t DatToSend;
    uint8_t WhatWasRead;
    uint16_t LoopCounter;
    uint8_t ReturnedData[9]; // Debug use.  Simple place to hold all the data that comes back from the FLASH

    // Set write protect bit.
    // Perform the erase
    // Wait until status register reports not busy

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW); // Set FLASH Chip select LOW to select it.
    DatToSend = 0x90; // Read ID.  Byte 2 = xx, Byte 3 = XX, Byte 4 = 00, Byte 5 = 0xEF, Byte 6 = 0x17
    for (LoopCounter = 0; LoopCounter < 6; LoopCounter++) // get 64 bits (8 sets of 8 bits) of the data starting at the address passed in.                             
    {                                                     // MSB comes in first.  We expect 0xEF17
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // when these bits are sent, 8 bits are shifted in.
        DatToSend = 0x00; // Now send the 24 bit address 0, and 0 filled dummy bytes.
        ReturnedData[LoopCounter] = WhatWasRead; // LSB is in MacArray[0]
    }
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH); // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 0x05;                                                // Read Status Register 1
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // Bits 2-7 are Block Protect.  All should be 0 (Unprotected) Bit 1 = Write Enable Latch (WEL), Bit 0 = Busy
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 0x35;                                                // Read Status Register 2
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 0x15;                                                // Read Status Register 3
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it
    
    
    
    
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 6;                                                   // Create Write Enable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // Send the command.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 0x05;                                                // Read Status Register 1
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // Bits 2-7 are Block Protect.  All should be 0 (Unprotected) Bit 1 = Write Enable Latch (WEL), Bit 0 = Busy
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // 
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.
    DatToSend = 0xC7;                                                // Set CHIP ERASE Command   -----------------------
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);        // Send the command
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH);    // Set Chip select back high to un-select it

    All_LEDS_ON(); 
    
    DatToSend = 0x05;                                                // Read Status Register 1
    WhatWasRead = 0x01;                                              // Pretend we are busy for the entry into the test
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);     // Set FLASH Chip select LOW to select it.    
    while (WhatWasRead & 0x01)                                       // Start Reading the Status register at address 0x05. Bottom bit is the Busy Flag.  1 = busy
    {                                                                // Wait here until the FLASH is done erasing the entire device.   40 - 200 seconds.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // 8 bits are shifted in when 8 bits are sent.         

        LoopCounter++;
        if (LoopCounter == 32000)
            All_LEDS_OFF();
        if (LoopCounter == 0)
            All_LEDS_ON();
    }

    All_LEDS_OFF();

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH); // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW); // Set FLASH Chip select LOW to select it.
    DatToSend = 4; // Create Write Disable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send the command.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, HIGH); // Set Chip select back high to un-select it

    Send0XE5EventNoticeToHost(0x03);    // Send USB Event Notice to HOST.   0x03 = Flash Erase Complete. 04 Command 0x10 setup complete.

    return;

}





//***************************************************************************************************
//  Returns a 12 bit, right justified, (2.048 / 2e12 ) * N in volts, MSB First. from the selected channel; 0 = Forward, 1 = Reverse
//***************************************************************************************************

uint16_t GetAD(uint8_t WhichChannel) // Pass in selected channel; 0 = Forward, 1 = Reverse
{
    uint16_t DaVal; // Temp storage to build the return value in.
    uint16_t WhatWasRead;
    uint8_t LoopCounter;
    uint8_t DatToSend;

    if (WhichChannel) // The Reverse channel is Selected
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, LOW);   // Reset chip select to be able to trigger the conversion. 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK,HIGH);  // Wake from Sleep
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK,LOW);   // Wake the AD converter from Sleep by pulsing clock once here.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);  // Set High to start a conversion.  1400nS minimum conversion time.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, LOW);   // Put the chip select low to select it and start clocking out data.
    }
    else  // The Forward channel is Selected
    {
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, LOW);   // Reset chip select to be able to trigger the conversion. 
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK,HIGH);  // Wake from Sleep
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK,LOW);   // Wake the AD converter from Sleep by pulsing clock once here.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, LOW);   // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH);  // NOP
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, LOW);   // Put the chip select low to select it and start clocking out data.
    }

    DaVal = 0; // Zero out the Value.    
    for (LoopCounter = 0; LoopCounter < 12; LoopCounter++) // Read the AD converter
    {
        DaVal = DaVal << 1; // Shift the bit to make room for the new one

        if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, RF_MISO) == 1)
            DaVal |= 0x001;

        //if( PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, RF_MISO) )            // Read the ADs output pin
        //    DaVal |= 0x001;                                                     // if the pin is high then set the LSB.   If not, then leave it a zero

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, HIGH);           // Raise the clock
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);            // Then drop the clock to get a new bit.
    }

    DaVal = DaVal & 0x0FFF; // Save only the bottom 12 bits 

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RAD_CS, HIGH);                // Set Reverse channel chip select back high to deselect it.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, FAD_CS, HIGH);                // Set Forward channel chip select back high to deselect it.    

    return (DaVal);
}


//***************************************************************************************************
//  Reads and writes a value to the FM25V01A SPI device
//  RW (Read/Write).  Pass in 1 for Write, 0 to read.
//  Where is the 16 bit address
//  WhattoWrite is the 8 bit value to put there
//***************************************************************************************************

uint8_t SPI_Transaction8(bool RW, uint16_t Where, uint8_t WhatToWrite) 
{
    uint8_t DatToSend;
    uint8_t WhereLSB;
    uint8_t WhereMSB;
    uint8_t WhatWasRead = 0;

    WhereLSB = (uint8_t) (Where & 0x00FF);
    WhereMSB = (uint8_t) ((Where >> 8) & 0x00FF);

//    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.
//    DatToSend = 5; // Read Status Register command.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send the read status register command.
//    DatToSend = 0; // Empty Byte.    
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.    
//    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it
//    
//    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.
//    DatToSend = 0x9F; // Read Device ID    Should be 7F7F7F7F7F7FC22108
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DatToSend = 0; // Empty Byte.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.    
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
//    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it
    

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.    
    
    if (RW) 
    {
        DatToSend = 6; // Create Write enable command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write enable command.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.
        DatToSend = 2; // Create Write command.                                                         
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write command.

        DatToSend = WhatToWrite; // Create local variable that can be pointerized.
        DRV_SPI0_BufferAddWriteRead(&WhereMSB, &WhatWasRead, 1); // Send MSB of Address.
        DRV_SPI0_BufferAddWriteRead(&WhereLSB, &WhatWasRead, 1); // Send LSB of Address.
        DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1); // Send the data to write.

        DatToSend = 4; // Create Write disable command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write disable command.
    }
    else 
    {
        DatToSend = 3; // Create Read command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Read command.
        
        DatToSend = WhatToWrite; // Create local variable that can be pointerized.
        DRV_SPI0_BufferAddWriteRead(&WhereMSB, &WhatWasRead, 1); // Send MSB of Address.
        DRV_SPI0_BufferAddWriteRead(&WhereLSB, &WhatWasRead, 1); // Send LSB of Address.
        DRV_SPI0_BufferAddWriteRead(&DatToSend,&WhatWasRead, 1); // Generate 8 clocks to shift the data in.
    }

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it

    return (WhatWasRead);
}
//***************************************************************************************************
//  Big SPI Transaction
//  Reads and writes a value to the large FRAM SPI device  256K X 8 FM25V20A
//  RW (Read/Write).  Pass in 1 for Write, 0 to read.
//  Where is the 16 bit address
//  WhattoWrite is the 8 bit value to put there
//***************************************************************************************************

uint8_t BSPI_Transaction8(bool RW, uint32_t Where, uint8_t WhatToWrite) {
    uint8_t DatToSend;
    uint8_t WhereLSB; // Least  significant  Bits
    uint8_t WhereCSB; // Center significant  Bits
    uint8_t WhereMSB; // Most   significant  Bits
    uint8_t WhatWasRead;

    WhereLSB = (uint8_t) (Where & 0x000000FF);
    WhereCSB = (uint8_t) ((Where >> 8) & 0x000000FF);
    WhereMSB = (uint8_t) ((Where >> 16) & 0x000000FF);

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.

    if (RW) // We are writing
    {

        DatToSend = 6; // Create Write enable command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write enable command.

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it        
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, LOW); // Set FRAM Chip select LOW to select it.

        DatToSend = 2; // Create Write command.                                                         
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write command.

        DRV_SPI0_BufferAddWriteRead(&WhereMSB, &WhatWasRead, 1); // Send MSB of Address.     Most   significant  Bits of Address
        DRV_SPI0_BufferAddWriteRead(&WhereCSB, &WhatWasRead, 1); // Send CSB of Address.     Center significant  Bits of Address
        DRV_SPI0_BufferAddWriteRead(&WhereLSB, &WhatWasRead, 1); // Send LSB of Address.     Least  significant  Bits of Address

        DRV_SPI0_BufferAddWriteRead(&WhatToWrite, &WhatWasRead, 1); // Send the data to write.

        DatToSend = 4; // Create Write disable command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Write disable command.
    } else {
        DatToSend = 3; // Create Read command.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1); // Send Read command.

        DRV_SPI0_BufferAddWriteRead(&WhereMSB, &WhatWasRead, 1); // Send MSB of Address.     Most   significant  Bits of Address
        DRV_SPI0_BufferAddWriteRead(&WhereCSB, &WhatWasRead, 1); // Send CSB of Address.     Center significant  Bits of Address
        DRV_SPI0_BufferAddWriteRead(&WhereLSB, &WhatWasRead, 1); // Send LSB of Address.     Least  significant  Bits of Address

        DRV_SPI0_BufferAddWriteRead(&WhatToWrite, &WhatWasRead, 1); // Generate 8 clocks to shift the data in.
    }

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, FRAM_CS, HIGH); // Set FRAM Chip Select back high to un-select it

    return (WhatWasRead);
}







//***************************************************************************************************
// Refreshes a Global variable; AverageTemperature  as a uint8 in degrees C.
// Reads a Microchip TC77 located near the RF Attenuators.  This function is limited to temperatures from 1 Degree C to +125 Degrees C.  
// A return of 0 means the temp is less than 1 degree.  A return of 126 means the temp is greater than 125 degrees C.
//***************************************************************************************************

void Get_Temp(void) {
    uint16_t DaTemperature;              // Simple storage to build the return value in.
    uint8_t LoopCounter;
    bool BelowZero;                      // 1 if below 0 degrees C, and 0 if above Zero degrees c.
    float NewTemperature = 0.0;
    static float FAvgTemp = 20.0;        // Start at 20 degrees C to speed up the settling time at the expected room temperature.
    //float SystemTemperatureF = 20.0;   // The temperature converted to Degrees F.

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TEMP_CS, LOW);         // Reset the temperature sensors Chip select to select it.

    BelowZero = PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, RF_MISO);    // the first bit bit on the MISO pin after CS goes low is the sign bit.

    DaTemperature = 0;                                                     // Zero out the Value.    
    for (LoopCounter = 0; LoopCounter < 12; LoopCounter++)                 // Read the 12 new bits from the Temperature Sensor
    {
        DaTemperature = DaTemperature << 1;                                // Shift the bit to make room for the new one

        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, HIGH);    // Raise the clock
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, RF_SCLK, LOW);     // Then drop the clock to get a new bit.

        if (PLIB_PORTS_PinGet(PORTS_ID_0, PORT_CHANNEL_D, RF_MISO))        // Read the Sensors output pin
            DaTemperature |= 1;                                            // if the pin is high then set the LSB.   If not, then leave it a zero

    }

    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TEMP_CS, HIGH);        // Set the temperature sensors Chip select to Deselect it.   

    if (BelowZero)                                                         // If temperature is below 0 degree C 
        AverageTemperature = 0;                                            // Just return a 0.
    else {

        NewTemperature = (float) DaTemperature * .0625;                    // Convert to degrees C. 
        FAvgTemp = (FAvgTemp * 4) + NewTemperature;                        // Running average. 
        FAvgTemp = FAvgTemp / 5;

        //SystemTemperatureF = (float) 1.8 * FAvgTemp + 32;                // Convert to F 

        AverageTemperature = (uint8_t) FAvgTemp;

        if (AverageTemperature >= 120)                                     // If TC77 is near the upper range of it's useful value.
            AverageTemperature = 126;
    }

    // Calculated each second,          // Holds which temperature range is used.  0 = < 25.0.  1 = 25.0 to 29.9.  2 = 30.0 to 35.0  3 = > 35.0
    CurrentTemperatureNum = 3;          // we can start by saying the temperature is high

    if (AverageTemperature < 35)        // If the temperature is 30 to 35
        CurrentTemperatureNum = 2;

    if (AverageTemperature < 30)        // If the temperature is 25 to 30
        CurrentTemperatureNum = 1;

    if (AverageTemperature < 25)        // If the temperature is below 25 degrees.
        CurrentTemperatureNum = 0;

    
    
// DEBUG ONLY !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
CurrentTemperatureNum = 0;    // DEBUG ONLY !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// DEBUG ONLY !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!    
// TODO Remove to be able to calibrate all the temperature ranges.    
    

    return;

}

uint8_t GetTemp(void) 
{
    return (AverageTemperature);
}

void MarkLabel(void) // Stuff the Mark array so that the label will be processed per the Mark settings.
{
    uint8_t LoopCounter;

    if(!MarkPunchActive)               // The pass/fail indication will be stuffed into the Mark & Punch arrays when set.  
        return;                        // Set (1) for moving label banner triggerd tests, and reset (0) for Firmware triggered tests.

    //DebugOut( sprintf(Uart5TxBuf, "1> %d %d %d %d %d %d %d %d %d %d \n\r",MarkArray[0],MarkArray[1],MarkArray[2],MarkArray[3],MarkArray[4],MarkArray[5],MarkArray[6],MarkArray[7],MarkArray[8],MarkArray[9]) );
    
    for (LoopCounter = 0; LoopCounter < 255; LoopCounter++)    // Search all the Mark / Punch trigger counters
    {
        if (!MarkArray[LoopCounter])                           // If this counter is not being used.
        {
            MarkArray[LoopCounter] = appCmd11Data.position;    // The number of labels between the antenna and the Mark Peripheral
            return;                                            // we are done as soon as we stuff the first one.
        }
    }   
}


void PunchLabel(void) // Stuff the Punch array so that the label will be processed per the punch settings.
{
    uint8_t LoopCounter;

    if(!MarkPunchActive)               // The pass/fail indication will be stuffed into the MarkPunch array when set.
        return;                        // Set (1) for moving label banner triggerd tests, and reset (0) for Firmware triggered tests.

    
    //DebugOut( sprintf(Uart5TxBuf, "1> %d %d %d %d %d %d %d %d %d %d \n\r",PunchArray[0],PunchArray[1],PunchArray[2],PunchArray[3],PunchArray[4],PunchArray[5],PunchArray[6],PunchArray[7],PunchArray[8],PunchArray[9]) );
    
    for (LoopCounter = 0; LoopCounter < 255; LoopCounter++)    // Search all the Mark / Punch trigger counters
    {
        if (!PunchArray[LoopCounter])                          // If this counter is not being used.
        {
            PunchArray[LoopCounter] = appCmd20Data.position;   // Number of labels between the Punch on web and the antenna.
             return;                                           // we are done as soon as we stuff the first one.
        }
    }   
}

void InitMarkPunchArray(void) // Zero out both of the Arrays
{
    uint8_t LoopCounter;      // Simple counter

    for (LoopCounter = 0; LoopCounter < 255; LoopCounter++)     // Clear out the 
    {
        MarkArray[LoopCounter] = 0;                             // Mark  trigger counter.   
        PunchArray[LoopCounter] = 0;                            // Punch trigger counter.   
    }
}

void MaintainMarkPunchArray(void) // Checks to see if it's time to mark or punch.  This function is called each time a new label is detected.
{
    uint8_t LoopCounter; // Simple counter

    // Basic explanation of operation to get started.   Punch Flight adjustment is explained in the next paragraph.
    // We need to know the number of labels that are between the Measurement Antenna and the Mark and Punch peripherals.  
    // If a bad label is detected and the controller is configured to mark bad labels, then an unused MARK counter is located and the number of labels between the antenna and the 
    // Mark peripheral is put into that counter.   Same for punch, the number of labels between the antenna and the Punch peripheral is put into an unused Punch counter.
    // Each time a label is detected then all the counters that are in use are decremented and the values are compared to see if it is time to initiate a mark or punch operation.
    // For instance.  Consider that there are 22 labels between the Antenna and the punch peripheral and 26 labels between the Antenna and the Mark peripheral.
    // When we detect a bad label, we search all the MARK counters for one that is zero (unused).  We set it to 26 (the number of labels between the antenna and the Mark peripheral.    
    // Same for the punch.... We search all the PUNCH counters for one that is zero (unused).  We set it to 22 (the number of labels between the antenna and the Punch peripheral.)
    // Now when each new label is detected, we decrement all the counters that are in use.  We compare each used counter to see if it just decremented from one to zero.  If it did, then 
    // we start a process that will eventually enable that peripheral.  The peripherals will get deactivated in the 1mS Timer ISR as a separate task.  

    // Punch Flight Adjustment.
    // The punch peripheral is slow.  There is a finite amount of time for the punch to get moving and then travel the distance from its rest position 
    // to the contact point on the label and the small amount of time for the Solid State Relay to energise.   This time is relatively long when you consider that the labels can be 
    // moving 25 feet per second (.3 inch per millisecond).  We know the number of encoder tics between the new label detector and the chip, the velocity of the web,
    // and the time the punch needs between its trigger and the strike.  We can subtract some encoder pulses from the punch offset to pretrigger.   We increase the number of encoder
    // tics that we subtract as the speed increases.  Typically the position of the IC in the label and the width of the label is such that we need more adjustment than the standard
    // encoder tic offset.   The operator inputs the number of TICS that will be produced between two labels.   We subract a label from the number of labels between the antenna and punch 
    // and add the number of tics between two labels so that there will be plenty of tics to adjust with.  We do this regardless of the web speed so that we don't have a crossover problem 
    // when the web increases above or drops below the speed when the adjustment is needed and there are adjacent labels in the pipeline that need to be pounded.

    // We have this data available
    // MarkPunchHdwConfig;                // Bit 0: Mark Enable.  Bit 1: Punch Enable,  Bit 2: 0 = Mark then punch, 1 = Punch then mark. 
    // appCmd11Data.position              // Mark Position
    // appCmd20Data.position              // Punch Position
    // Cmd21_LabelPitchTics               // The Nominal pitch of the labels in tics.( Num tics from the leading edge of one label to the leading edge of the next label)
    // Cmd21_NomLabelTics;                // The Nominal tics that are expected per Label (edge to edge of the label portion)
    // Cmd21_TicsPerInch;                 // The exact number of tics that will be sent for each 1.000 inch of Web length
    // WebVelocityEncoderTicCorrection    // Num Tics to subtract from the TIC offset for Punch.
    // appCmd20Data.OffsetSel             // What causes the Punchoffset:  0 = 0x1D Punch offset Tics, 1 = 0x20 Punch offset mS

    //ControlTP(17,1);                      // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

    //DebugOut( sprintf(Uart5TxBuf, "1> %d %d %d %d %d %d %d %d %d %d \n\r",PunchArray[0],PunchArray[1],PunchArray[2],PunchArray[3],PunchArray[4],PunchArray[5],PunchArray[6],PunchArray[7],PunchArray[8],PunchArray[9]) );
    //DebugOut( sprintf(Uart5TxBuf, "1> %d %d %d %d %d %d %d %d %d %d \n\r",MarkArray[0],MarkArray[1],MarkArray[2],MarkArray[3],MarkArray[4],MarkArray[5],MarkArray[6],MarkArray[7],MarkArray[8],MarkArray[9]) );
    
    for (LoopCounter = 0; LoopCounter < 255; LoopCounter++)     // test all the of Mark trigger counters to see if any are ready to trigger it's mark process.
    {                                                           // We can keep up with 255 labels between the Antenna and the Mark Peripheral.
        if (MarkArray[LoopCounter])                             // If this counter is currently counting a label that needs to be marked.
        {
            MarkArray[LoopCounter]--;                           // Decrement it.

            if (MarkArray[LoopCounter] == 0)                    // If this timer just decremented from 1 to 0 then it's time to fire off the timed Mark task.
            {                                                   // Since it's zero, then we can use it next time we need one.
                //DebugOut( sprintf(Uart5TxBuf, "MARK> %d %d %d %d %d %d %d %d %d %d \n\r",MarkArray[0],MarkArray[1],MarkArray[2],MarkArray[3],MarkArray[4],MarkArray[5],MarkArray[6],MarkArray[7],MarkArray[8],MarkArray[9]) );
                if ((!appCmd11Data.offset) && (!appCmd1dData.markeroffset)) // if both the mS and Encoder TIC offsets are both 0 then we enable it now.
                {
                    MarkActiveTimer = appCmd11Data.duration;                // The number of mS that the Mark peripheral is to be energized from Command 0x11
                    Mark(1);                                                // Pass in a 0 to untrigger and a 1 to trigger the mark peripheral.
                } 
                else 
                {                                                           // Only one of these will be non-zero and will cause a delayed trigger.
                    MarkOffsetETics = appCmd1dData.markeroffset;            // We will trigger the peripheral in the Encoder ISRs
                    MarkOffsetTimer = appCmd11Data.offset;                  // We will trigger the peripheral in the mS Timer ISRs
                }
            }
        }
    }

    for (LoopCounter = 0; LoopCounter < 255; LoopCounter++)     // Test all the of Punch trigger counters to see if any are ready to trigger it's Punch process.
    {                                                           // We can keep up with 255 labels between the Antenna and the Punch Peripheral.
        if (PunchArray[LoopCounter])                            // If this counter is currently counting a label that needs to be Punched.
        {
            PunchArray[LoopCounter]--;                          // Decrement it.
            if(appCmd20Data.OffsetSel)                          // What causes the Punchoffset:  0 = 0x1D Punch offset Tics, 1 = 0x20 Punch offset mS).
            {                                                   // We are set to mS offset, so there will be no Punch Flight adjustment
                if (PunchArray[LoopCounter] == 0)               // If this timer just decremented from 1 to 0 then it's time to fire off the timed Punch task.
                {
                    //DebugOut( sprintf(Uart5TxBuf, "Punch> %d %d %d %d %d %d %d %d %d %d \n\r",PunchArray[0],PunchArray[1],PunchArray[2],PunchArray[3],PunchArray[4],PunchArray[5],PunchArray[6],PunchArray[7],PunchArray[8],PunchArray[9]) );
                    if (!appCmd20Data.offset)                   // if the mS offset is 0 then we enable it now.
                    {
                        PunchActiveTimer = appCmd20Data.duration;    // The number of mS that the Punch peripheral is to be energized from Command 0x20
                        Punch(1);                                    // Pass in a 0 to untrigger and a 1 to trigger the Punch peripheral.
                    } 
                    else 
                    {                                                // Only one of these will be non-zero and will cause a delayed trigger.
                        PunchOffsetTimer = appCmd20Data.offset;      // We will trigger the peripheral in the mS Timer ISRs                        
                        Punch(1);                                    // Pass in a 0 to untrigger and a 1 to trigger the Punch peripheral.
                    }
                }
            }
            else                                                     // We have an Encoder TIC offset.  We must perform the Punch flight adjustment.
            {    
                if (PunchArray[LoopCounter] == 1)                    // If this timer just decremented from 2 to 1 then it's time to fire off the timed Punch task.  We fire one label early
                {                                                    // and add one labels worth of Encoder TICS so that we have plenty to subtract from to pre-fire the punch at high web speeds.
                    //DebugOut( sprintf(Uart5TxBuf, "Punch> %d %d %d %d %d %d %d %d %d %d \n\r",PunchArray[0],PunchArray[1],PunchArray[2],PunchArray[3],PunchArray[4],PunchArray[5],PunchArray[6],PunchArray[7],PunchArray[8],PunchArray[9]) ); 
                    // We will fire the Punch when the web moves enough encoder tics so that the punch hits the center of the IC.
                    // It is the sum of the encoder Tic offset from the banner sense point to the center of the IC Chip,
                    // Plus the number of encoder Tics that happen from the leading edge of one label to the leading edge of the next label,
                    // Minus the number of encoder TICS that happen in the time it takes the punch to hit after being triggered (typically 11mS).  this will change with web speed.
                    // It is calculated each tenth second in the "MainLoopStuff" function.
                    if(PunchOffsetETics)
                    {
                        DebugOut( sprintf(Uart5TxBuf, "Punch offset ETics contention"));
                        Send0XE5EventNoticeToHost(0x06);             // Send USB Event Notice to HOST.  Punch offset ETics timer is currently in use when a new offset wants to be issued.
                    }                    
                    PunchOffsetETics = appCmd1dData.punchoffset + Cmd21_LabelPitchTics - WebVelocityEncoderTicCorrection;     // Set the (16 bit) value.  The value will be decremented each time the
                }                                                                                                             // the encoder moves forward.  When it hits zero then the punch fires.
            }
        }
    }
    
    //ControlTP(17,0); // Which; 12 (13) 17 18 31 32 39 45 49 68 77 96   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
}

void Punch(int8_t Enable) // Pass in a 0 to retract the punch and a 1 to extend the punch.   This performs the inversion if required.
{
    if (Enable) {
        if (BitfieldInversions & 0x02) // 0 = Output is high impedance when resting and asserted to trigger.  1 = Asserted when resting and High impedance to trigger. 
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, LOW);
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, HIGH);
    } else {
        if (BitfieldInversions & 0x02) // 0 = Output is high impedance when resting and asserted to trigger.  1 = Asserted when resting and High impedance to trigger. 
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, HIGH);
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PUNCH, LOW);
    }
}

void Mark(int8_t Enable) // Pass in a 0 to untrigger and a 1 to trigger the mark peripheral.      This performs the inversion if required.
{
    if (Enable) {
        if (BitfieldInversions & 0x01) // 0 = Output is high impedance when resting and asserted to trigger.  1 = Asserted when resting and High impedance to trigger. 
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, LOW);
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, HIGH);
    } else {
        if (BitfieldInversions & 0x01) // 0 = Output is high impedance when resting and asserted to trigger.  1 = Asserted when resting and High impedance to trigger. 
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, HIGH);
        else
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, MARK, LOW);
    }
}


void WriteFLASH8 (uint32_t FAddress , uint8_t DatToWrite)       // Write one Byte to Flash.  Pass in 32 bit Flash Address and a 8 byte data to write
{                                                               // Supports Winbond W25Q128FV    17 Bit address to support Addresses 0x00 through 0x1FFF.
uint8_t DatToSend;
uint8_t WhatWasRead;
uint32_t BigStorage;
uint8_t AddressMSB;    // Most   significant bits.
uint8_t AddressLSB;    // Lower  significant Bits.
uint8_t AddressXLB;    // Lowest significant bits.

    DatToSend = 0x05;                                                     // Read Status Register 1   *** Check for BUSY ***
    WhatWasRead = 0x01;                                                   // Pretend we are busy for the entry into the test
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);          // Set FLASH Chip select LOW to select it.    
    while (WhatWasRead & 0x01)                                            // Start Reading the Status register at address 0x05. Bottom bit is the Busy Flag.  1 = busy
    {                                                                     // Wait here until the FLASH is done erasing the entire device.   40 - 200 seconds.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);         // 8 bits are shifted in when 8 bits are sent.  
    }
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, HIGH );     // Set Chip select back high to un-select it

    BigStorage = (FAddress & 0x00FF0000)>>16;
    AddressMSB = (uint8_t)BigStorage;
    BigStorage = (FAddress & 0x0000FF00)>>8;
    AddressLSB = (uint8_t)BigStorage;    
    BigStorage = FAddress & 0x000000FF;
    AddressXLB = (uint8_t)BigStorage;

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 6;                                                              // Create Write Enable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);                   // Send the command.
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,   HIGH );         // Set Chip select back high to un-select it

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 2;                                                              // Create Write command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Write command.
    DRV_SPI0_BufferAddWriteRead(&AddressMSB, &WhatWasRead, 1);                  // Send the Most   significant bits of the address   This takes 30 to 50uS for the FLASH to process.
    DRV_SPI0_BufferAddWriteRead(&AddressLSB, &WhatWasRead, 1);                  // Send the Lower  significant bits of the address   Additional consecutive writes take 12uS each for the FLASH to process.
    DRV_SPI0_BufferAddWriteRead(&AddressXLB, &WhatWasRead, 1);                  // Send the Lowest significant bits of the address
    DatToSend = DatToWrite;                                                     // Harmony needs a pointer to a local variable.
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the data    

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,   HIGH );         // Set Chip select back high to un-select it
        
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 4;                                                              // Create Write Disable command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);                   // Send the command.
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,   HIGH );         // Set Chip select back high to un-select it
    
    return;      
}

uint8_t ReadFLASH8(uint32_t FlashAddress)    // Read one Byte from Flash. Pass in 32 bit Address and get a 8 byte data back
{                                            // Supports Winbond W25Q128FV    17 Bit address to support Addresses 0x00 through 0x1FFF.
uint8_t DatToSend;
uint8_t WhatWasRead;
uint32_t BigStorage;
uint8_t AddressMSB;    // Most   significant bits.
uint8_t AddressLSB;    // Lower  significant Bits.
uint8_t AddressXLB;    // Lowest significant bits.

    DatToSend = 0x05;                                                     // Read Status Register 1   *** Check for BUSY ***
    WhatWasRead = 0x01;                                                   // Pretend we are busy for the entry into the test
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, EE_CS, LOW);          // Set FLASH Chip select LOW to select it.    
    while (WhatWasRead & 0x01)                                            // Start Reading the Status register at address 0x05. Bottom bit is the Busy Flag.  1 = busy
    {                                                                     // Wait here until the FLASH is done erasing the entire device.   40 - 200 seconds.
        DRV_SPI0_BufferAddWriteRead(&DatToSend, &WhatWasRead, 1);         // 8 bits are shifted in when 8 bits are sent.  
    }
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, HIGH );     // Set Chip select back high to un-select it


    BigStorage = (FlashAddress & 0x00FF0000)>>16;
    AddressMSB = (uint8_t)BigStorage;
    BigStorage = (FlashAddress & 0x0000FF00)>>8;
    AddressLSB = (uint8_t)BigStorage;    
    BigStorage = FlashAddress & 0x000000FF;
    AddressXLB = (uint8_t)BigStorage;

    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS, LOW );            // Set FLASH Chip select LOW to select it.
    DatToSend = 3;                                                              // Create Read command.
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // Send the Read command.
    DRV_SPI0_BufferAddWriteRead(&AddressMSB, &WhatWasRead, 1);                  // Send the Most   significant bits of the address
    DRV_SPI0_BufferAddWriteRead(&AddressLSB, &WhatWasRead, 1);                  // Send the Lower  significant bits of the address
    DRV_SPI0_BufferAddWriteRead(&AddressXLB, &WhatWasRead, 1);                  // Send the Lowest significant bits of the address
    DatToSend = 0;                                                              // Create Clean Dummy Byte
    DRV_SPI0_BufferAddWriteRead(&DatToSend,  &WhatWasRead, 1);                  // The read data comes back as the dummy byte is sent. 
    PLIB_PORTS_PinWrite ( PORTS_ID_0 , PORT_CHANNEL_D, EE_CS,   HIGH );         // Set Chip select back high to un-select it

    return(WhatWasRead);                                                        // Send back whatever we get
}



/*  End of File  **************************************************************/
