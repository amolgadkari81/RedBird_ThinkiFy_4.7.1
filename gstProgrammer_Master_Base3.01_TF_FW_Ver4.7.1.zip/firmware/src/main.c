//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//
//  File Name:
//    Main.c
//    State machine for the tester.  
//
//  Last Edit Date:  Sept  3 2017   JRL Updates for Rev B Board
//  Last Edit Date:  Oct   3 2016   JRL    Clean up after calibration debug.
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "system/common/sys_module.h"   // SYS function prototypes
#include "globals.h"

extern APP_CMD10 appCmd10Data;

void TestStateMachine(void);                    // orchestrates all the main loop tasks that deal with modes and tests.
void JustGotNewLabelTrigger(void);              // fiber optic detector or Camera just detected a new label.  Called from the ISRs
void EncoderJustMovedForward(void);             // Do everything that has to happen when the encoder reports a foreard movement.
void TriggertheTest(void);                      // We detected the label, waited the delay.  Now start the ReadTimout Timers and trigger the TR-65
void NudgeSensitivityTest(void);                // State machine to seek min power required to read a tag.
void TriggerOne0x18Read(void);                  // We need one read for the 0x18 test.
uint8_t TidMisMatch(void);                      // Compares the current TID with the filter version.  Returns 1 if they dont match, and 0 if they do match.
void DebugOut();                                // pushes Uart5TxBuf into it's circular buffer.

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    SYS_Initialize ( NULL );    // Initialize all MPLAB Harmony modules, including application(s).

    while ( true )              // Do this forever
        SYS_Tasks ( );          // Maintain state machines of all polled MPLAB Harmony modules.

    return ( EXIT_FAILURE );    // Execution should not come here during normal operation */
}


void TestStateMachine(void)             // All the test related tasks.   
{
static uint8_t  OldTemperature = 0;     // the temperature 
static uint8_t  ClosestFreq = 0;        // What is the closest calibrated frequency
static uint8_t  CalibrateStatus = 0;    // The return value from the Calibration function.  1 means successful completion.
static bool     LabelsMatched = 0;      // Flag that gets set to 0 if a mismatch ocurrs.  
static uint8_t  BuildDigit = 0;         // We build a digit of TAG ID into this byte during string to number conversions.
static uint8_t  Test0x18StepSize = 0;   // increment power level by this amount for each test.
static uint8_t  FilterTestFail = 0;     // 1 if the TIDs fails the Filter test.  0 if pass.

       
    //ControlTP(17,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    //ControlTP(17,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    
    if(! appCmd14Data.enable  )           // Main Enable/disable for the tester.
         TestModeState = TESTMODEIDLE;    // Just idle if not enabled.

    if(OldTestModeState != TestModeState) // Holds the mode that was active the last time thru the loop.  
    {                                     // we changed modes since last time. Do we need to do anything?      
        if(OldTestModeState == RUNTEST0X10)
        {
            InitMarkPunchArray();         // Zeros out the entire Array            
            EncoderADeafTime = 0;         // Zero all the counters and delays that could cause a trigger.
            EncoderBDeafTime = 0;
            MarkOffsetTimer = 0;
            PunchOffsetTimer = 0;
            PunchActiveTimer = 0;
            MarkActiveTimer = 0;
            Punch(0);                     // Disable the peripheral incase it was enabled.
            Mark(0);                      // Disable the peripheral incase it was enabled.
        }

        if(OldTestModeState == RUNDEBUGMODE0x1E)       // If we were running test 0x1E and we just changed tests or modes.
        {
            Cmd1E_desiredNumPulses = 0;                // Cancel any further Marker cycles.
            Cmd1E_Timer = 0;                           // Cancel any further Marker cycles.
            Mark(0);                                   // Disable the peripheral / Set marker to inactive
        }
    }

    // Pseudocode.    Save old temperature each time thru the loop.  Compare to current temperature.   
    // Add            Send new attenuator settings when the temp crosses the thresholds.               
    // TODO           Add some Hysteresis to prevent jumping back and forth between temperatures.
      
    switch(TestModeState)
    {
        // appCmd10Data.testtype                       // bitField  (MSB) ForceKill - Unused - Unused - IDFilter - TID - Unused - Write - Read (LSB))
        case INITTEST0X10:                             // Main label Test Modes:   Init a new test 0x10
            switch(InitTest0x10State)                  // All the parts of getting test 0x10 setup.
            {
                case 0:                                // All the quick and easy preliminary stuff and Set Thinkify RF                     
                    PlayPause = 0;                     // 0 = pause.  1 = Play. Host must send setup info using command 0x10 then set the mode to enable using commands 0x50 and 0x51
                    Banner1Count = 0;                  // Zero the trigger count
                    InitTest0x10State = 1;             // Next we set the Thinkify modes.    
                    InitMarkPunchArray();              // Zeros out the entire Mark/Punch Array to cancel any marks or punches that may be scheduled                 
                    NewTR65TIDAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
                    NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time

                    if(appCmd10Data.testtype & 0x80)       // If Force Kill is enabled.
                        ;
                    if(appCmd10Data.testtype & 0x10)       // If ID filter is enabled.
                        ;
                    if(appCmd10Data.testtype & 0x08)       // If TID is enabled.
                        ;
                    if(appCmd10Data.testtype & 0x04)       // Sensitivity test
                        ;
                    if(appCmd10Data.testtype & 0x02)       // If Write Test is enabled.
                        ;
                    if(appCmd10Data.testtype & 0x01)       // If Read Test is enabled.
                        ;
                break;

                case 1:                                       // Send the 5 most significant digits of the RF Frequency to the Thinkify. 
                    sprintf(Uart3TxBuf,"RF%lu\r\n",appCmd10Data.freq1/10000); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf); 
                    RfidTimeOut = 500;                        // Decremented in the 1mS ISR.
                    RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                    InitTest0x10State++;                      // Next we wait for the Thinkify
                break;                

                case 2:                                       // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                          // we timed out.
                        InitTest0x10State--;                  // Send the previous command again. 
                    if(RfidReady)                             // We received the '>' from the TR-65    
                        InitTest0x10State++;                  // go to the next step.
                    // TODO:  Check to see that the TR-65 actually confirmed the correct frequency was set.
                    // TODO:  Make sure we don't get hung in an infinite loop here if the TR-65 doesn't ever respond correctly.
                break;
                
                case 3:                                       // Set the LEN of TID to read.
                    if(appCmd10Data.testtype & 0x08)          // If the TID test is enabled. 
                        sprintf(Uart3TxBuf,"GGTL6\r\n");      // Set TR-65 to request then wait for 6 (16 bit) words of TID Data
                    else
                        //sprintf(Uart3TxBuf,"GGTL0\r\n");      // Set TR-65 to wait for 0 (16 bit) words of TID Data.   the fewer the chars the faster the read.
                    sprintf(Uart3TxBuf,"SM1\r\n");          // Change for ThinkiFy FW ver 4.7.1
                    ReverseString(Uart3TxBuf);                // Reverse the string in place.            
                    Uart3TXpointer = strlen(Uart3TxBuf);      // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
                    RfidTimeOut = 1000;                       // Decremented in the 1mS ISR.   Gets set to 20 when the '>' char is received from the TR-65
                    RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                    InitTest0x10State++;                      // Next we wait for the Thinkify
                break;

                case 4:                                       // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                          // we timed out.
                        InitTest0x10State--;                  // Send the previous command again.   
                    if(RfidReady)                             // We received the '>' from the TR-65   
                        InitTest0x10State++;                  // go to the next step.
                break;

                case 5:                                       // Set the TR-65 and the Step Attenuators  --- Re-enter here after a Sensitivity test.
                    CurrentCALChannel = FindFreqElement(appCmd10Data.freq1);    // returns number of the CalcFreq table element that is closest to the requested frequency.
                    FlashAddress =( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + ((appCmd10Data.readpower - 750) * 16) );
                    GetCalRecordFromFlash(FlashAddress);                        // Get CAL record to Flash.  pass Addr.  It updates Globals: SA, RA, AA, FAD, RAD, Err.
                    //Now these are available/useable.
                    //ACalRecord_SA;                          // Global uint8_t    Holds the Step  Attenuator setting for the requested Freq and Power level
                    //ACalRecord_AA;                          // Global uint16_t   Holds the Analog Attenuator setting for the requested Freq and Power level
                    //ACalRecord_RA;                          // Global uint8_t    Holds the TR-65 Attenuator setting used at CAL for the current Freq and Power level
                    //ACalRecord_FAD;                         // Global uint16_t   Holds the Forward AD reading that was measured at CAL verify time for the current Freq and Power level
                    //ACalRecord_RAD;                         // Global uint16_t   Holds the Reverse AD reading that was measured at CAL verify time for the current Freq and Power level
                    //ACalRecord_PwrError;                    // Global uint8_t    Holds the power error magnitude (Unsigned)
                    SetStepAttenuator(ACalRecord_SA);         // Send SPI message to Step Attenuator   
                    SetRfAttDAC(ACalRecord_AA);               // Which AA Power level is being used. 
                    sprintf(Uart3TxBuf,"RA%u\r\n",ACalRecord_RA);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);    // set TR-65 attenuator
                    RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                    InitTest0x10State++;                      // Next we wait for the Thinkify to finish
                break;                

                case 6:                                       // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                          // we timed out.
                        InitTest0x10State--;                  // Send the previous command again.                                           
                    if(RfidReady)                             // We received the '>' from the TR-65    
                        InitTest0x10State++;                  // go to the next step.
                break;

                case 7:
                    NewTR65EPCAvailable = 0;                  // We set low so we can detect a new tag
                    MainTestStatus = 0;                       // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                    GTestInProcessState = 0;                  // Reset flag that warns the HOST if we get a trigger when a label is still in process.
                    if(JustDidSensitivityTest)
                    {
                        JustDidSensitivityTest = 0;           // reset the flag so we can detect the correct path next time.
                        TestModeState = RUNTEST0X10;          // Wait for a new label to test
                        //ControlTP(68,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        //ControlTP(68,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                    }
                    else
                    {
                        TestModeState = WAITFOR0X10TRIG;          // Wait for a new label to test
                        Send0XE5EventNoticeToHost(0x04);          // Send USB Event Notice to HOST. 04 = Command 0x10 setup complete.
                    }
                    InitTest0x10State++;                      // Get off of this step to prevent troubles with re-triggers.
                break;               
            }
 
        break;
               
            
//*********************************************************************************************************************************************************************
// This is all the available setup info for this command
//
//        appCmd10Data.testtype                 // Test Type          Bitfield    1 = Test is enabled
//        appCmd10Data.tagclass                 // Tag class          Always 1.   00 = None, 01 = EPC1Gen2, 02 = Ucode, 03 = Impinj M5, 04 = Impinj R6, 05 = Impinj R6P
//        appCmd10Data.antport                  // Antenna port       Always 1.
//        appCmd10Data.readpower                // Read power         in CentidB  Is this signed?  16 bit twos compliment?
//        appCmd10Data.readtimeout              // Read timeout       in mS
//        appCmd10Data.freq1                    // Read frequency 1   32 bit
//        appCmd10Data.freq2                    // Read frequency 2   32 bit
//        appCmd10Data.freq3                    // Read frequency 3   32 bit
//        appCmd10Data.writepower               // Write power        in CentidB  Is this signed?  16 bit twos compliment?
//        appCmd10Data.writetimeout             // Write timeout      in mS
//        appCmd10Data.writetype                // Write Type         0 = Use current tag ID every time. 1 = Increment given tag ID each time. 2 = Use date and time values. 3 = Strap data.
//        appCmd10Data_startTagID[]             // Start tag ID       12 characters.
//
//*********************************************************************************************************************************************************************
       
        case RUNTEST0X10:                                       // Main Test Modes:   Running test 0x10    Do all of the command 0x10 testing here ****************************
            if(PlayPause)                                       // 0 = pause.  1 = Play. Host must send setup info using command 0x10 then set the mode to enable using commands 0x50 and 0x51
            {                                                   // exit if trigger is not enabled
                //ControlTP(24,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                //ControlTP(24,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                //DebugOut( sprintf(Uart5TxBuf, "Running RUNTEST0x10\n\r") ); // AG
                
                if(Active0x10Tests & 0x04)                      // Sensitivity test.    Do this first then do the EPC and TID Read tests.
                {
                    TestModeState = RUNSENSITIVITYTEST;         // Go and do the sensitivity test.   It will return us to RUNTEST0X10 (here) when it completes
                    // TODO   use frequency from 0x18 command.  Change back to frequency for 0x10 command when done.
                    CalPacer = 0;                               // Decremented in the 1mS ISR
                    break;                                      // Break of the current switch statement so we skip the rest of these test until the sensitivity test is complete.
                }
              
                if(Active0x10Tests & 0x80)                      // If Force Kill test is enabled.
                    ;

                if(Active0x10Tests & 0x08)                      // If TID test is enabled.
                {
                    if(GTestInProcessState == 2)                // Timeout.  Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = ReadTimeoutCounter hit 0 (Test Timeout).
                    {
                        DebugOut( sprintf(Uart5TxBuf, "TID Timeout ") );
                        //GTestInProcessState = 0;              // the test is complete.  Wait until the next new label is detected.
                        MainTestStatus |= 0x48;                 // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                        Active0x10Tests &= 0xF6;                // Indicate that EPC and TID tests are complete.
                    }

                    if(NewTR65TIDAvailable)                     // We just got a TID from the TR-65 read.  It is set in PCB Peripherals where the serial port carriage returns are handled.
                    {
                        NewTR65TIDAvailable = 0;                // Reset the flag that says that we just got a TR-65 read so we can detect one next time
                        LabelsMatched = 1;                      // This Flag gets set to 0 if a mismatch occurs. Start with a good match.
                        // TODO check for matches???????
                        Active0x10Tests &= 0xF7;                // Indicate that this test is complete.
                    }
                        
                    if(TR65TidReadFail == 1)                    // Set if a read error is detected in the TID Section.
                    {
                        MainTestStatus |= 0x08;                 // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                        Active0x10Tests &= 0xF7;                // Indicate that this test is complete.
                        DebugOut( sprintf(Uart5TxBuf, "TID Fail ") );
                    }   
                }
                
                if(Active0x10Tests & 0x02)                 // If Write Test is enabled.
                    ;

                if(Active0x10Tests & 0x01)                 // If EPC Read Test is enabled.
                {
                    if(GTestInProcessState == 2)           // Timeout.  Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = ReadTimeoutCounter hit 0 (Test Timeout).
                    {
                        MainTestStatus |= 0x41;            // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                        Active0x10Tests &= 0xE6;        //F6-->E6   // Indicate that EPC and TID read tests are complete.
                        //NewTR65EPCAvailable = 0;
                        DebugOut( sprintf(Uart5TxBuf, "EPC Timeout ") );
                        
                    }
                                 
                    if(NewTR65EPCAvailable)                // We just got a TR-65 read.  It is set in PCB Peripherals where the serial port carriage returns are handled.
                    {
                        //ControlTP(13,0); // Check the time
                        NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
                        LabelsMatched = 1;                 // This Flag gets set to 0 if a mismatch occurs. Start with a good match.
                        Active0x10Tests &= 0xFE;           // Indicate that EPC read test is complete.
                        if( Active0x10Tests & 0x10)                     // If ID filter test is enabled.
                        {      
                            if(GTestInProcessState == 2)                // Timeout.  Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = ReadTimeoutCounter hit 0 (Test Timeout).
                            {
                                MainTestStatus |= 0x41;        //50 -->0x10         // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                                Active0x10Tests &= 0xE6; //F6 -->EF               // Indicate that ID Filter test is complete.
                                //NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
                            }
                                                        
                            MainTestStatus &= 0xEF;             // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                            FilterTestFail = TidMisMatch();         // Compares the current TID with the filter.  Returns 1 if they dont match, and 0 if they do match.
                            if(FilterTestFail)                      // DEBUG ONLY -----------------
                            {    
                               //DebugOut( sprintf(Uart5TxBuf,"FT Fail %x 1 ",CurrentEPC[11]) );
                                    MainTestStatus |= 0x10;             // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                                    //DebugOut( sprintf(Uart5TxBuf,"FT Fail %x 1 ",CurrentEPC[11]) );
                                }
                                else
                                {     
                                    //DebugOut( sprintf(Uart5TxBuf, "FT Pass %x 0 ",CurrentEPC[11]) );
                                    MainTestStatus &= 0xFE;    //EF --> FE         // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                                }
                                //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_B, TP65, LOW);
                                /*AG Removed*/
                                /*if(FilterTestFail)
                            MainTestStatus |= 0x10;             // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                        */
                            Active0x10Tests &= 0xEF;   //EF --> FE             // Indicate that ID Filter test is complete.
                            //DebugOut( sprintf(Uart5TxBuf,"%u %x 1 ",MainTestStatus) );
                        }//ID filter if ends
                   } // EPC available  ends
                        //ControlTP(32,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        //ControlTP(32,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

                 
                    if(TR65EPCReadFail == 1)           // Set if a read error is detected in the EPC section 
                    {
                        MainTestStatus |= 0x01;        // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                        Active0x10Tests &= 0xEE; //  FE- EE    // Indicate that EPC read test is complete.
                        DebugOut( sprintf(Uart5TxBuf, "EPC Fail ") );
                    }
                }
                
                if(!Active0x10Tests)                        // If 0x00 then all requested tests have completed.
                {
                    //ControlTP(40,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                    //ControlTP(40,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                    
                    TestModeState = WAITFOR0X10TRIG;        // Wait for a new label to test
                    GTestInProcessState = 0;                // the test is complete.  Wait until the next new label is detected.
                    if(MainTestStatus)                      // If Non-Zero then one or more tests failed.
                    {
                        appCmd15Data.testfailcount++;       // Update Statistics.
                        DebugOut( sprintf(Uart5TxBuf, "Overall Fail\n\r") );
                        ControlTP(24,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        ControlTP(24,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        if(appCmd11Data.enable == 1)        // Marker Control    0 = disable Mark, 1 = Mark Bad labels, 2 = Mark Good labels
                            MarkLabel();                    // Stuff the Mark array so that the label will be processed per the Mark settings.
                        if(appCmd20Data.enable == 1)        // Punch Control    0 = disable Punch, 1 = Punch Bad labels.
                            PunchLabel();                   // Stuff the Punch array so that the label will be processed per the Punch settings.                        
                    }
                    else 
                    {
                        appCmd15Data.testpasscount++;       // Update Statistics  
                        DebugOut( sprintf(Uart5TxBuf, "Overall Pass\n\r") );  
                        ControlTP(65,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        ControlTP(65,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                        if(appCmd11Data.enable == 2)        // Marker Control    0 = disable Mark, 1 = Mark Bad labels, 2 = Mark Good labels
                            MarkLabel();                    // Stuff the Mark array so that the label will be processed per the Mark settings. 
                    }                          
                    Send0xE3Data();                         // unsolicited USB message sent at the completion of a 0x10 command.
                }                 
            }
        break;

        case INIT0X18TEST:                             // Set the tester into a known condition for Static, Immediate, and Debug modes. Do the setup stuff here.
            //DebugOut( sprintf(Uart5TxBuf, "\n 2* \n\r") );// AG
            switch(Test0x18State)                      // All the parts of getting test 0x18 setup.
            {
                case 0:                                // All the quick and easy preliminary stuff and Set Thinkify RF                     
                    
                    Test0x18State = 1;                 // Next we set the Thinkify RF Freq   
                    NewTR65TIDAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
                    NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time

                    CurrentCALChannel = FindFreqElement(appCmd18Data.Freq);          // returns number of the CalcFreq table element that is closest to the requested frequency.
                    FlashAddress = CurrentTemperatureNum * 0x100000;                 // Get the offset needed by the (Global) temperature.
                    FlashAddress += CurrentCALChannel * 0x4000;                      // Get the offset to the beginning of the (Global) current channel 
                                                                                                                         
                    PowerLevelNum = (appCmd18Data.MaxPower - appCmd18Data.MinPower) / 2 ;    // power levels come in as CentidB and are converted to an index by subracting the value of the first index.
                    PowerLevelNum = appCmd18Data.MaxPower - PowerLevelNum;                   // Set to the middle of the power range to be tested
                                                                                     // PowerLevelNum can be modified during use without losing info for a repeated test.
                    //DebugOut( sprintf(Uart5TxBuf, "\n C0 \n\r") );// AG
                    GetCalRecordFromFlash( FlashAddress + (PowerLevelNum * 16) );    // Get the offset to the beginning of the current power level then get a CAL record from Flash.  It updates Global Variables.
                    //DebugOut( sprintf(Uart5TxBuf, "\n CF \n\r") );// AG
                    //Now these are available/usable.
                    //ACalRecord_SA;                       // Global uint8_t    Holds the Step   Attenuator setting for the requested Freq and Power level
                    //ACalRecord_RA;                       // Global uint8_t    Holds the TR-65  Attenuator setting for the requested Freq and Power level
                    //ACalRecord_AA;                       // Global uint16_t   Holds the Analog Attenuator setting for the requested Freq and Power level
                    //ACalRecord_FAD;                      // Global uint16_t   Holds the Forward AD reading that was measured at CAL verify time for the current Freq and Power level
                    //ACalRecord_RAD;                      // Global uint16_t   Holds the Reverse AD reading that was measured at CAL verify time for the current Freq and Power level
                    //ACalRecord_PwrError;                 // Global uint16_t   Holds the power error (absolute value))
                break;
                
                case 1:                                           // Set Thinkify Tari Data rate     TARI=25.0   M=M8    LF=250
                    //sprintf(Uart3TxBuf,"P232\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);          // Send string to TR-65
                    //sprintf(Uart3TxBuf,"P033\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);          // Send string to TR-65
                    //sprintf(Uart3TxBuf,"P131\r\n"); // Org in Barry's code
                    
                    sprintf(Uart3TxBuf,"P023\r\n"); // P023 is Recommended by Curt 
                    //sprintf(Uart3TxBuf,"P232\r\n"); // P131 is barry's value 
                    ReverseString(Uart3TxBuf);
                    Uart3TXpointer = strlen(Uart3TxBuf);          // Set protocol Send string to TR-65  Changed from P033 to P131 Feb 11 2018
                    RfidTimeOut = 1000;                           // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                    RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
                    Test0x18State = 2;                            // Next we wait for the Thinkify to finish
                    //DebugOut( sprintf(Uart5TxBuf, "\n C1 \n\r") );// AG
                break;                

                case 2:                                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                              // we timed out.
                    {    Test0x18State = 1;                        // Send the previous command again.
                         //DebugOut( sprintf(Uart5TxBuf, "\nC2TO \n\r") );// AG
                    }
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                        Test0x18State = 3;                        // go to the next step.
                        CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char.
                        //DebugOut( sprintf(Uart5TxBuf, "\nC2RD \n\r") );// AG
                    }
                break;

                case 3:                                           // Set Thinkify Query = 0 to read one label per trigger.
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    {
                        sprintf(Uart3TxBuf,"IQ1\r\n");  ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);      // Changed from 0 to 1 Feb 11 2018
                        RfidTimeOut = 1000;                       // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                        Test0x18State = 4;                        // Next we wait for the Thinkify to finish
                        //DebugOut( sprintf(Uart5TxBuf, "\nC3 \n\r") );// AG
                    }
                break;                

                case 4:                                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                              // we timed out.
                        Test0x18State = 3;                        // Send the previous command again.                       
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                        Test0x18State = 5;                        // go to the next step.
                        CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char.
                        //DebugOut( sprintf(Uart5TxBuf, "\nC4P \n\r") );// AG
                    }
                break;
                
                case 5:                                           // Set Thinkify RF Frequency. 
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    {                        
                        sprintf(Uart3TxBuf,"RF%lu\r\n",appCmd18Data.Freq/10000); ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);  
                        RfidTimeOut = 2000;                       // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                        Test0x18State = 6;                       // Next we wait for the Thinkify to 
                    //DebugOut( sprintf(Uart5TxBuf, "\nC5P \n\r") );// AG
                    }
                break;                

                case 6:                                           // Wait until we get a ">" or until enough seconds have passed for the RF section to tune.
                    if(!RfidTimeOut)                              // we timed out.
                        Test0x18State = 5;                        // Send the previous command again.   
                    
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                        Test0x18State = 7;                        // go to the next step.
                        CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char. 
                        //DebugOut( sprintf(Uart5TxBuf, "\nC6P \n\r") );// AG
                    }
                    // TODO:  Check to see that the TR-65 actually confirmed the correct frequency was set.  if ok then Test0x18State = 3, if not then Test0x18State = 1.
                    // TODO:  Make sure we don't get hung in an infinite loop here if the TR-65 doesn't ever respond correctly.
                break;
                
                case 7:                                               // Set the attenuators
                    if(!CalPacer)                                     // Wait here until the delay is expired
                    { 
                        SetStepAttenuator(ACalRecord_SA);             // Send SPI message to Step Attenuator  
                        SetRfAttDAC(ACalRecord_AA);                   // Which AA Power level is being used. 
                        LastRequestedRA = ACalRecord_RA;              // Save the RA value for the next time.  If may save time if we already set it to the current needed value already.
                        sprintf(Uart3TxBuf,"RA%u\r\n",ACalRecord_RA);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);    
                        RfidTimeOut = 2000;                           // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
                        Test0x18State = 8;                            // Next we wait for the Thinkify to set the RF attenuator
                    //DebugOut( sprintf(Uart5TxBuf, "\nC7P \n\r") );// AG
                    }
                break;

                case 8:                                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                              // we timed out.
                        Test0x18State = 7;                        // Send the previous command again.   
                    
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                        Test0x18State = 9;                        // go to the next step.
                        CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char. 
                        //DebugOut( sprintf(Uart5TxBuf, "\nC8P \n\r") );// AG
                    }
                break;

                case 9:                                           // Trigger and memory read
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    {  
                        sprintf(Uart3TxBuf,"GT110401\r\n");       // TRIGGERTYPE=POSEDGE PORT1,  TRIGGERACTION=T 01   
                        //sprintf(Uart3TxBuf,"GT112401\r\n");     // TRIGGERTYPE=LEVEL PORT1,  TRIGGERACTION=T 01   
                        ReverseString(Uart3TxBuf);                // Reverse the string in place.            
                        Uart3TXpointer = strlen(Uart3TxBuf);      // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
                        RfidTimeOut = 1000;                       // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                        Test0x18State = 10;                       // Next we wait for the Thinkify to set the RF attenuator
                        //DebugOut( sprintf(Uart5TxBuf, "\nC9P \n\r") );// AG
                    }
                break;

                case 10:                                          // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!RfidTimeOut)                              // we timed out.
                        Test0x18State = 9;                        // Send the previous command again.                       
                    
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                        Test0x18State = 11;                       // go to the next step. 
                        CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char.
                    //DebugOut( sprintf(Uart5TxBuf, "\nC10P \n\r") );// AG
                    }
                break;
                
                case 11:                                          // Granularity on Trigger interval
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    { 
                        sprintf(Uart3TxBuf,"GG0A\r\n");  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf);
                        RfidTimeOut = 1000;                       // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                        CalPacer = 1000;                          // Wait for 1 second to let the TR-65 finish up
                        Test0x18State = 12;                       // go to the next step. 
                        //TestModeState = TESTMODEIDLE;           // We are setup and stable, go to the idle mode until HOST PC triggers the test.
                        //DebugOut( sprintf(Uart5TxBuf, "\nC11P \n\r") );// AG
                    }
                break;
    
                case 12:                                          // discard the > chars for a specified time.                
                    if(CalPacer)
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                    else                                          // when we have been tossing them for long enough.
                        Test0x18State = 13;                       // Pulse the hardware trigger until we get a > char.                       
                    //DebugOut( sprintf(Uart5TxBuf, "\nC12P \n\r") );// AG
                case 13:                                          // Prime the pump.   This step and the next fix a problem with the TR-65 where it does not accept the first 25 
                    if(!CalPacer)                                 // or so hardware read triggers.
                    { 
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, HIGH);    // Set TR-65s GPI pin to trigger a read.   
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, HIGH);    // Set TR-65s GPI pin to trigger a read.
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH);           // Enable the AUX output on J3 pins 1&2
                        //DebugOut( sprintf(Uart5TxBuf, "\nRHi \n\r") );// AG
                        CalPacer = 20;                                                        // set about 20mS high time.
                        Test0x18State = 14;                                                   // put pin back low and check to see if we need to send another
                        SetFrontPanelLEDs(3, 2);                  // Pulse the TR-65 Trigger LED
                       // DebugOut( sprintf(Uart5TxBuf, "\nC13P \n\r") );// AG
                    }
                break;

                case 14:                                          // Prime the pump.   This step fixes a problem with the TR-65 where it does not accept the first 25 
                    //DebugOut( sprintf(Uart5TxBuf, "\nC14S \n\r") );// AG
                    if(!CalPacer)                                 // or so hardware read triggers.
                    {
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, LOW);     // reset the pin so that it can be triggered again later.    
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, LOW);     // Set TR-65s GPI pin to get ready for the next trigger
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, LOW);            // Disable the AUX output on J3 pins 1&2
                        CalPacer = 20;   //10                         // Set about a 10mS low time
                        //DebugOut( sprintf(Uart5TxBuf, "\nRLo \n\r") );// AG       
                        if(RfidReady)                             // Set to 1 when the > is received from the TR-65
                        {   
                            Uart3RxBuf[0] = 0x00;                 // Prevent retrigger
                            LoopCounter = 100;                    // We got a read, so we don't need any more pulses.   Nuke the counter so it exits as usual.
                            NewTR65EPCAvailable = 0;              // send it back low so we can detect a new tag
                            DebugOut( sprintf(Uart5TxBuf, "\nC14M2 \n\r") );// AG
                        }
                        //DebugOut( sprintf(Uart5TxBuf, "\nC14M3 %u \n\r", LoopCounter) );// AG
                                                
                        if(TempCounter < 50)  //if(LoopCounter++ < 50)                  // Increment until we make 50 triggers or get a > char
                        {   Test0x18State = 13;  
                            TempCounter++;
                            //DebugOut( sprintf(Uart5TxBuf, "\nC14M3 %u \n\r", TempCounter) );// AG
                        }
                        else
                        {    Test0x18State = 15; 
                            DebugOut( sprintf(Uart5TxBuf, "\nC14M4 \n\r") );// AG
                        }
                    }
                break;
                
                case 15:
                    FlushLabelData();                       // Delete the EPC and TID data from the last read.
                    NewTR65EPCAvailable = 0;                // send it back low so we can detect a new tag
                    TestModeState = TESTMODEIDLE;           // We are setup and stable, go to the idle mode until HOST PC triggers the test.
                    DebugOut( sprintf(Uart5TxBuf, "*3* waiting for 0x54 \n\r") );// AG
                break;                              
            }                  
        break;
    
        case RUNSENSITIVITYTEST:                            // Stay here until HOST PC requests a change or test completes.
            if(!CalPacer)                                   // CalPacer is decremented in the 1mS ISR.
                NudgeSensitivityTest();                     // state machine to seek the min power required to read a tag.
        break;
    
        case INITDEBUGMODE0x6A:                             // Main Test Modes:   Init Set Antenna Frequency Power (Command 0x6A)
//            
//            switch(Test0x6AState)                         // All the parts of getting test 0x6A setup.
//            {
//                case 0:                                                         // All the quick and easy preliminary stuff and Set Thinkify RF                     
//                    Test0x6AState = 1;                                          // Next we set the Thinkify RF Freq
//                    CurrentCALChannel = FindFreqElement(appCmd6AData.freq1);    // returns number of the CalcFreq table element that is closest to the requested frequency.
//                    FlashAddress = CurrentTemperatureNum * 0x100000;            // Get the offset needed by the temperature.
//                    FlashAddress += CurrentCALChannel * 0x4000;                 // Get the offset to the beginning of the current channel
//                                                                                // appCmd6AData.readpower comes in as CentidB; -25dB to +30dB.  Add 100dB and multiply by 10.  -12.3dB is sent as 877, +22.4dB sent as 1224.  
//                    PowerLevelNum = 1250 - appCmd6AData.readpower;              // Cal Table starts at 1250 (+25.0dB) and goes down to 750 (-25.0dB))
//                    FlashAddress += (PowerLevelNum * 16);                        // Get the offset to the beginning of the current power level.  Table has the highest power first.            
//                    GetCalRecordFromFlash(FlashAddress);                        // Get a CAL record from Flash.  It updates Global Variables.
//                break;
//                
//                case 1:                                           // Set Thinkify RF Frequency.     
//                    sprintf(Uart3TxBuf,"RF%lu\r\n",appCmd6AData.freq1);
//                    ReverseString(Uart3TxBuf);                    // Reverse the string in place.            
//                    Uart3TXpointer = strlen(Uart3TxBuf);          // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
//                    CalPacer = 2000;                              // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
//                    Test0x6AState = 2;                            // Next we wait for the Thinkify to 
//                break;                
//
//                case 2:
//                    if(!CalPacer)                                 // Wait until we get a ">" or until 2 seconds have passed.
//                        Test0x6AState = 3;                        // Next we set the Thinkify RF RA attenuator
//                    // Pseudocode:  Check to see that the TR-65 actually confirmed the correct frequency was set.  if ok then Test0x6AState = 3, if not then Test0x6AState = 1.
//                    // Pseudocode:  Make sure we don't get hung in an infinite loop here if the TR-65 doesn't ever respond correctly.
//                break;
//                
//                case 3:                                                   // Set the attenuators
//                    SetStepAttenuator(ACalRecord_SA);                     // Send SPI message to Step Attenuator
//                    sprintf(Uart3TxBuf,"RA%ul\r\n",ACalRecord_AA);
//                    ReverseString(Uart3TxBuf);                    // Reverse the string in place.            
//                    Uart3TXpointer = strlen(Uart3TxBuf);          // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
//                    CalPacer = 2000;                              // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
//                    Test0x6AState = 4;                            // Next we wait for the Thinkify to set the RF attenuator
//                break;
//
//                case 4:
//                    if(!CalPacer)                                 // Wait until we get a ">" fron the TR-65 or until 2 seconds have passed.
//                        TestModeState = RUNDEBUGMODE0x6A;         // The inits are done.  Now do the test. 
//                break;
//
//            }
        break;
    
        case RUNDEBUGMODE0x6A:            // Main Test Modes:   Running Command 0x6A.
                                          // Wait here until the Host PC changes our task
        break;
    
        case RUNDEBUGMODE0x1E:            // Everything runs in the 1mS ISR
                                          // Wait here until the Host PC changes our task
        break;   
        
        case RUNLSRFIDCAL:                             // Perform the calibration of the RFID Interface.  Power levels -25dB to 0dB
            if (!PMPacer)                              // we nudge it thru all the tasks as the pacer timer expires.  Some tasks take quite a long time such as setting frequency on the TR-65
            {
                //ControlTP(18,2);                     // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                CalibrateRFID(2);                      // Pass in 0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
            }
        break;        

        case RUNHSRFIDCAL:                             // Perform the calibration of the RFID Interface.  Power levels -15dB to +30dB
            if (!PMPacer)                              // we nudge it thru all the tasks as the pacer timer expires.  Some tasks take quite a long time such as setting frequency on the TR-65
            {
                //ControlTP(18,2);                     // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                CalibrateRFID(4);                      // Pass in 0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
            }
        break;        

        case VERIFYRFIDCAL:                             // Perform the calibration of the RFID Interface.  Power levels -15dB to +30dB
            if (!PMPacer)                              // we nudge it thru all the tasks as the pacer timer expires.  Some tasks take quite a long time such as setting frequency on the TR-65
            {
                //ControlTP(18,2);                     // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                CalibrateRFID(9);                      // Pass in 0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
            }
        break;        


        
        case PERFORMTEST0X0B:                          // RF Test Mode:   Init a new test 0x0B
            switch(Init0x0BState)                      // Sets the TR-65 to CW Mode, Freq and Pwr as requested with USB command 0x0B
            {
                case 0:                                // Set Thinkify Freq.     Global CAL Record variables have just been recalled from FLASH 
                    
                    CurrentCALChannel = FindFreqElement(Freq0x0B);           // returns 8 bit number of the CalcFreq table element that is closest to the requested 32 bit frequency.
                    FlashAddress =( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + ((CurrentPowerSought-750) * 16) );
                    GetCalRecordFromFlash(FlashAddress);                     // Get CAL record to Flash.  pass Addr.  It updates Globals: SA, RA, AA, FAD, RAD, Err.
                    sprintf(Uart3TxBuf,"RF%lu\r\n",Freq0x0B/10000);  ReverseString(Uart3TxBuf);  Uart3TXpointer = strlen(Uart3TxBuf); 
                    CalPacer = 2000;                              // Timeout.  Resends when decremented to zero.   1000 = one second
                    RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
                    Init0x0BState = 1;                            // Next we wait for the Thinkify to tune to the requested frequency.
                break;                

                case 1:                                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!CalPacer)                                 // we timed out.
                        Init0x0BState = 0;                        // Send the previous command again. 
                    
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                         CalPacer = 50;                           // Wait 20mS after we receive the  '>' char from the TR-65  1 = 1mS, 10 = 10mS,
                         Init0x0BState = 2;                       // go to the next step.
                    }    
                    // TODO:  Check to see that the TR-65 actually confirmed the correct frequency was set.  if ok then InitTest0x10State = 3, if not then InitTest0x10State = 1.
                    // TODO:  Make sure we don't get hung in an infinite loop here if the TR-65 doesn't ever respond correctly.
                break;
                
                case 2:                                               // Set the attenuators
                    if(!CalPacer)                                     // Wait here until the delay is expired
                    {
                        SetStepAttenuator(ACalRecord_SA);             // Send SPI message to Step Attenuator  
                        SetRfAttDAC(ACalRecord_AA);                   // Which AA Power level is being used. 
                        sprintf(Uart3TxBuf,"RA%u\r\n",ACalRecord_RA); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
                        CalPacer = 3000;                              // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
                        Init0x0BState = 3;                            // Next we wait for the Thinkify power to settle
                    }
                break;

                case 3:                                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
                    if(!CalPacer)                                 // we timed out.
                        Init0x0BState = 2;                        // Send the previous command again. 
                    
                    if(RfidReady)                                 // We received the '>' from the TR-65    
                    {
                         CalPacer = 50;                           // Wait 50mS after we receive the  '>' char from the TR-65  1 = 1mS, 10 = 10mS,
                         Init0x0BState = 4;                       // go to the next step.
                    }    
                    // TODO:  Check to see that the TR-65 actually confirmed the correct frequency was set.  if ok then InitTest0x10State = 3, if not then InitTest0x10State = 1.
                    // TODO:  Make sure we don't get hung in an infinite loop here if the TR-65 doesn't ever respond correctly.
                break;
                
                
                case 4:                                           // Set TR-65 to CW Mode
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    {
                        sprintf(Uart3TxBuf,"RO3\r\n");
                        ReverseString(Uart3TxBuf);                // Reverse the string in place.            
                        Uart3TXpointer = strlen(Uart3TxBuf);      // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
                        CalPacer = 500;                           // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        RfidReady = 0;                            // this gets set to 1 when the '>' is received from the TR-65
                        Init0x0BState = 5;                        // Next we wait for the Thinkify power to settle
                    }
                break;

                case 5:                                           // Settling time for R03 command expired.
                    if(!CalPacer)                                 // Wait here until the delay is expired
                    {
                        CalPacer = 500;                           // 1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
                        Init0x0BState = 6;                        // Next we wait for the attenuators to settle
                    }
                break;
                
                case 6:                                                // We waited for all the settling time.   Measure the Forward and Reverse AD converters.
                    if(!CalPacer)                                      // Wait here until the delay is expired
                    {
                        CurrentFAD = GetAD(0);  // TODO   Add Filtering.   // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        CurrentRAD = GetAD(1);  // TODO   Add Filtering.   // Pass in selected channel; 0 = Forward, 1 = Reverse; 
                        Send0xE2Data();                                    // unsolicited response sent at the completion of a 0x0B command.
                        TestModeState = TESTMODEIDLE;                      // We're done.
                    }
                break;
            }
        break;
            
        case TESTMODEIDLE:                             // No user requested tests, moving label tests, or user requested tasks are running. 
           TimeToBreak = 0;                            // Debug only.  Just a place to put a break point
        break;                                         // Do nothing until we get a new command from the Host.
    
       case WAITFOR0X10TRIG:                           // We are waiting for the 0x10 test to be launched.. 
           TimeToBreak = 0;                            // Debug only.  Just a place to put a break point
       break;                                          // Do nothing until we get a trigger from the new label detector.

    }
    OldTestModeState = TestModeState;                  // Holds the mode that was active the last time thru the loop.  
}


uint8_t TidMisMatch(void)                       // Compares the current TID with the filter.  
{                                               // Returns 1 if they dont match, and 0 if they do match.
uint8_t FilterTestFail = 0;                     // Start low.  If any of the nibbles fail the match then set it to 1 to indicate the failure.
//DebugOut( sprintf(Uart5TxBuf, "Running comparison\n\r") ); // AG
    if(Cmd1A_NibbleEnables & 0x00800000)        // if the top nibble is to be tested.
    {
        //DebugOut( sprintf(Uart5TxBuf, "*4*\n\r") ); // AG
        
        if ( ( CurrentEPC[0] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[0] & 0xF0 ) ) 
            FilterTestFail = 1;                 // If any of the nibbles fail the match then set it to 1 to indicate the failure.
        //if (FilterTestFail)
            //DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[0],Cmd1A_TagIdFilter[0]) );// AG
    }                    
    if(Cmd1A_NibbleEnables & 0x00400000) 
    {
        if ( ( CurrentEPC[0] & 0x0F ) !=  ( Cmd1A_TagIdFilter[0] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
            //DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[0],Cmd1A_TagIdFilter[0]) );// AG
    }                                            
    if(Cmd1A_NibbleEnables & 0x00200000)    
    {
        if ( ( CurrentEPC[1] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[1] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
        //    DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[1],Cmd1A_TagIdFilter[1]) );// AG
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00100000)    
    {
        if ( ( CurrentEPC[1] & 0x0F ) !=  ( Cmd1A_TagIdFilter[1] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[1],Cmd1A_TagIdFilter[1]) );// AG
    }

    if(Cmd1A_NibbleEnables & 0x00080000)
    {
        if ( ( CurrentEPC[2] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[2] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[2],Cmd1A_TagIdFilter[2]) );// AG
    }                    
    if(Cmd1A_NibbleEnables & 0x00040000) 
    {
        if ( ( CurrentEPC[2] & 0x0F ) !=  ( Cmd1A_TagIdFilter[2] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[2],Cmd1A_TagIdFilter[2]) );// AG
    }                                            
    if(Cmd1A_NibbleEnables & 0x00020000)    
    {
        if ( ( CurrentEPC[3] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[3] & 0xF0 ) ) 
            FilterTestFail = 1;
            //if (FilterTestFail)
            //DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[3],Cmd1A_TagIdFilter[3]) );// AG
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00010000)    
    {
        if ( ( CurrentEPC[3] & 0x0F ) !=  ( Cmd1A_TagIdFilter[3] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[3],Cmd1A_TagIdFilter[3]) );// AG
    }                   

    if(Cmd1A_NibbleEnables & 0x00008000)
    {
        if ( ( CurrentEPC[4] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[4] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[4],Cmd1A_TagIdFilter[4]) );// AG
    }                    
    if(Cmd1A_NibbleEnables & 0x00004000) 
    {
        if ( ( CurrentEPC[4] & 0x0F ) !=  ( Cmd1A_TagIdFilter[4] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[4],Cmd1A_TagIdFilter[4]) );// AG
    }                                            
    if(Cmd1A_NibbleEnables & 0x00002000)    
    {
        if ( ( CurrentEPC[5] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[5] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[5],Cmd1A_TagIdFilter[5]) );// AG    
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00001000)    
    {
        if ( ( CurrentEPC[5] & 0x0F ) !=  ( Cmd1A_TagIdFilter[5] & 0x0F ) ) 
            FilterTestFail = 1;
         //if (FilterTestFail)
           // DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[5],Cmd1A_TagIdFilter[5]) );// AG   
    }                                       

    if(Cmd1A_NibbleEnables & 0x00000800)
    {
        if ( ( CurrentEPC[6] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[6] & 0xF0 ) ) 
            FilterTestFail = 1;
         //if (FilterTestFail)
           // DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[6],Cmd1A_TagIdFilter[6]) );// AG   
    }                    
    if(Cmd1A_NibbleEnables & 0x00000400) 
    {
        if ( ( CurrentEPC[6] & 0x0F ) !=  ( Cmd1A_TagIdFilter[6] & 0x0F ) ) 
            FilterTestFail = 1;
            //if (FilterTestFail)
            //DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[6],Cmd1A_TagIdFilter[6]) );// AG
    }                                            
    if(Cmd1A_NibbleEnables & 0x00000200)    
    {
        if ( ( CurrentEPC[7] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[7] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[7],Cmd1A_TagIdFilter[7]) );// AG   
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00000100)    
    {
        if ( ( CurrentEPC[7] & 0x0F ) !=  ( Cmd1A_TagIdFilter[7] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[7],Cmd1A_TagIdFilter[7]) );// AG  
    }                                       

    if(Cmd1A_NibbleEnables & 0x00000080)
    {
        if ( ( CurrentEPC[8] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[8] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[8],Cmd1A_TagIdFilter[8]) );// AG    
    
    }                    
    if(Cmd1A_NibbleEnables & 0x00000040) 
    {
        if ( ( CurrentEPC[8] & 0x0F ) !=  ( Cmd1A_TagIdFilter[8] & 0x0F ) ) 
            FilterTestFail = 1;
         //if (FilterTestFail)
           // DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[8],Cmd1A_TagIdFilter[8]) );// AG  
    }                                            
    if(Cmd1A_NibbleEnables & 0x00000020)    
    {
        if ( ( CurrentEPC[9] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[9] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[9],Cmd1A_TagIdFilter[9]) );// AG  
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00000010)    
    {
        if ( ( CurrentEPC[9] & 0x0F ) !=  ( Cmd1A_TagIdFilter[9] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[9],Cmd1A_TagIdFilter[9]) );// AG   
    }                                       

    if(Cmd1A_NibbleEnables & 0x00000008)
    {
        if ( ( CurrentEPC[10] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[10] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[10],Cmd1A_TagIdFilter[10]) );// AG
    }                    
    if(Cmd1A_NibbleEnables & 0x00000004) 
    {
        if ( ( CurrentEPC[10] & 0x0F ) !=  ( Cmd1A_TagIdFilter[10] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[10],Cmd1A_TagIdFilter[10]) );// AG    
    }                                            
    if(Cmd1A_NibbleEnables & 0x00000002)    
    {
        if ( ( CurrentEPC[11] & 0xF0 ) !=  ( Cmd1A_TagIdFilter[11] & 0xF0 ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[11],Cmd1A_TagIdFilter[11]) );// AG    
    }                                                                    
    if(Cmd1A_NibbleEnables & 0x00000001)    
    {
        if ( ( CurrentEPC[11] & 0x0F ) !=  ( Cmd1A_TagIdFilter[11] & 0x0F ) ) 
            FilterTestFail = 1;
        //if (FilterTestFail)
          //  DebugOut( sprintf(Uart5TxBuf, "%u = %u \n\r",CurrentEPC[11],Cmd1A_TagIdFilter[11]) );// AG 
    }                                       

    return(FilterTestFail);
    
}


void DebugOut()                                // Pushes Uart5TxBuf into it's circular buffer.
{
    ReverseString(Uart5TxBuf); 
    Uart5TXpointer = (strlen(Uart5TxBuf));
    while(Uart5TXpointer)                          // If there is a string to send, then push it all into the circular buffer in one go.
    {
        Uart5CircBuf[Uart5Headpointer] = Uart5TxBuf[(Uart5TXpointer - 1)];
        Uart5TXpointer--;                          // decrement the input strings pointer.   When it hits zero then we transferred all the characters.         
        if( Uart5Headpointer == (MAXSERBUF-1) )    // if we are at the last character in the ring then go to the first character in the ring.
            Uart5Headpointer = 0;                  // then go to the first character in the ring.
        else                                       // if not
            Uart5Headpointer++;                    // then point to the next char in the ring for next time.
    }
}    
   


// Binary search for RF Sensitivity READ Test.    Set RF step size to the midpoint of the power range to test.
// Read test: perform three reads.  Pass means there were no read fails and all three reads produce the same tag number.
// If pass then decrease the power level and test again.  If fail then increase power.
// If it passes then save that power level.   If it passes at least once and we reduce power level and the power step size is 1 then we found the minimum level.
// when done, send the unsolicited 0xE4 (0x18 Sensitivity test Results) message and return to calling function... This could be a Firmware trigger or part of the 0x10 test.



void NudgeSensitivityTest(void)            // state machine to seek min power required to read a tag.
{
static uint8_t  LastEPC[12];               // Holds the tag ID that was read the last time thru the loop.
static uint16_t PwrStepSize = 0;           // how far we jump during a binary search.
       uint8_t  TestPass = 0;              // 1 = Pass, 0 = Fail
static uint8_t  LastPassingPowerLevel = 0; // Holds a power level that passes the full test.   If we get a pass and then drop power and then fail, then we are done and we use this power level number.
       
     //DebugOut( sprintf(Uart5TxBuf, "\n5* \n\r") );// AG  
    switch(Test0x18State)                  // All the parts of getting test 0x18 setup.
    {
    case 0:                                                        // Adjust attenuators for the test.                    
        GetCalRecordFromFlash( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + (PowerLevelNum * 16) );    // Send address of the CAL record. The function updates Global Variables.
        //appCmd18Data.CurrentPowerLevel = PowerLevelNum + 750;      // Keep a current copy to send back to host.
        SetRfAttDAC(ACalRecord_AA);                                // Which AA Power level is being used. 
        SetStepAttenuator(ACalRecord_SA);                          // Send SPI message to Step Attenuator   
        CalPacer = 5;                                              // Delay to give the attenuators time to switch and settle.
        if(LastRequestedRA != ACalRecord_RA)                       // if the currently needed RA is the same as this then we don't have to send it to the TR-65.
        {
            LastRequestedRA = ACalRecord_RA;                       // Save the new value for the next time.
            sprintf(Uart3TxBuf,"RA%ul\r\n",ACalRecord_RA);ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);   
            CalPacer = 1000;                                       // delay to give the TR-65 time to switch and settle.
        }
        NewTR65EPCAvailable = 0;                                   // Reset the flag that says that we just got a TR-65 read so we can detect one next time
        NumReads = 0;                                              // We need three good reads in a row to call it a pass.
        GotTheStopInventoryMsg = 0;                                // The TR-65 fails if it is triggered before getting the Stop Inventory message after a read.  this is set in the TR-65 RX ISR
        Test0x18State = 1;                                         // Wait for CALPACER to expire, then trigger a read.
    break;
                   
    case 1:                                                        // We just waited for the Attenuator and TR-65 settling time.
        NewTR65EPCAvailable = 0;                                   // Reset the flag that says that we just got a TR-65 read so we can detect one next time
        TriggerOne0x18Read();                                      // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
        TestPass = 0;                                              // 1 = Pass, 0 = Fail
        Test0x18State = 2;                                         // Wait for CALPACER to expire, then trigger a read, then change to Test0x18State 1.        
    break;

    case 2:                                                        // Test for Pass / Fail of the read that was triggered.
        DebugOut( sprintf(Uart5TxBuf, "\n GTest %u \n\r",GTestInProcessState) );// AG
        if(GTestInProcessState == 2)                               // If Timeout then we fail. Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout.
        {    TestPass = 0;                                          // Increase power and test again  
            //DebugOut( sprintf(Uart5TxBuf, "\n 6* \n\r") );// AG
        }
        if(GotTheStopInventoryMsg && NewTR65EPCAvailable)   // We just got a good TR-65 EPC read.  This flag set in the TR-65 Serial ISR
        {                                                   // the TR-65 fails if it is triggered before getting the Stop Inventory message after a read.
            GotTheStopInventoryMsg = 0;                     // this flag is set in the TR-65 RX ISR
            NewTR65EPCAvailable = 0;                        // Reset the flag that says that we just got a TR-65 read so we can detect one next time
            GTestInProcessState = 0;                        // Regardless of the compare, the test is complete.  Wait until the next new label is detected.                            
            TestPass = 1;                                   // Set to Pass since we got something.  We can set to fail later if the reads are not the same.
            DebugOut( sprintf(Uart5TxBuf, "\n7* \n\r") );// AG
            if(NumReads == 0)                                           // if this is the first read of the series.  Just getting a read is enough to call it good.
            {
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)     // Save a copy of the first good read of the three read series.
                    LastEPC[LoopCountr] = CurrentEPC[LoopCountr];       // Holds the tag ID that was just received from a TR-65 Read EPC.
                //DebugOut( sprintf(Uart5TxBuf, "GR10 ") );
                NumReads++;                                             // We got the first of three reads.
            }    
            
            if( (NumReads == 1) || (NumReads == 2) )                          // if this is the second, or third read of the series.
            {
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)           // Compare the EPC read of the previous read.
                    if( LastEPC[LoopCountr] != CurrentEPC[LoopCountr] )       // Compare the tag ID that was just received with the one from the first read.
                        TestPass = 0;                                         // Indicate a fail
                //DebugOut( sprintf(Uart5TxBuf, "GR123  ") );
                if(TestPass)
                {    NumReads++; 
                    //DebugOut( sprintf(Uart5TxBuf, "3 read itrns are passed \n\r") );// AG
                }
                                                          // Increment a counter so we know when we get three matching reads.
                else
                    NumReads = 0;  
            }
                        
            if(NumReads == 3)                  // If this is 3 then it means that we got 3 good reads on the first power level.
            {                                  // the test is complete.
                Send0xE4Data(1);               // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.                     
                DebugOut( sprintf(Uart5TxBuf, "\n8* \n\r") );// AG
                TestModeState = TESTMODEIDLE;  // We're done.   Wait for the next trigger.

                appCmd15Data.testpasscount++;  // Maintain Statistics
                //DebugOut( sprintf(Uart5TxBuf, "Complete on First Read %lu  \n\r",PowerLevelNum) );// AG
            }
        }
        
        if(TestPass)                           // If the test passed then decrease power level and test again.
        {
            LastPassingPowerLevel = PowerLevelNum;
            PwrStepSize = ( (PowerLevelNum - appCmd18Data.MinPower ) / 2 );            // Find the half way point between the current level and the min level to test.
            if(PwrStepSize < 1)                // If we are at the bottom
            {    
                ;                              //Pass  Done
            }
            else
            {
                PowerLevelNum -= PwrStepSize;  // Adjust current level.
                Test0x18State = 0;             // Set power and test again  
                DebugOut( sprintf(Uart5TxBuf, "Reduced power to half from previous step \n\r") );// AG
            }
        }
        else                                   // Test failed then increase power level and test again.
        {
            PwrStepSize = ( ( appCmd18Data.MaxPower - PowerLevelNum ) / 2 );           // Find the half way point between the current level and the max level to test.
            if(PwrStepSize < 1)                // If we are at the Bottom
            {    
                ;                              // Fail  Done
            }
            else
            {
                PowerLevelNum += PwrStepSize;                                              // Adjust current level.
                Test0x18State = 0;                                                         // Set power and test again      
                DebugOut( sprintf(Uart5TxBuf, "Increased power to half from previous step \n\r") );// AG
            }
        }
        
    break;
     
        //TestModeState = RUNTEST0X10;          // Wait for a new label to test
        //Active0x10Tests |= 0xFB;              // say that the sensitivity test is complete.

//
//    
//    case 2:                                                        // Set power to the next (increment or decrement)        
//        GetCalRecordFromFlash( (CurrentTemperatureNum * 0x100000) + (CurrentCALChannel * 0x4000) + (PowerLevelNum * 16) );    // Send address of the CAL record. The function updates Global Variables.
//        appCmd18Data.CurrentPowerLevel = PowerLevelNum + 750;      // Keep a current copy to send back to host.
//        SetRfAttDAC(ACalRecord_AA);                                // Which AA Power level is being used. 
//        SetStepAttenuator(ACalRecord_SA);                          // Send SPI message to Step Attenuator   
//        RfidTimeOut = 100;                                         // Give fast attenuators time to settle.
//        if(LastRequestedRA != ACalRecord_RA)                       // if the currently needed RA is the same as this then we don't have to send it to the TR-65.
//        {
//            LastRequestedRA = ACalRecord_RA;                       // Save the new value for the next time.
//            sprintf(Uart3TxBuf,"RA%ul\r\n",ACalRecord_RA);ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);   
//            RfidTimeOut = 1000;                       // Let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
//        }
//        RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
//        Test0x18State = 3;                            // Next we wait for the Thinkify to set the RF attenuator
//    break;

    case 3:                                           // Wait until we get a ">" from the TR-65 or until enough seconds have passed to get the job done.
        if(!RfidTimeOut)                              // we timed out.
            Test0x18State = 2;                        // Send the previous command again.   

        if(RfidReady)                                 // We received the '>' from the TR-65    
        {
            Test0x18State = 4;                        // restart the three read binary search test at the next power level.
            NumReads = 0;                             // We need three good reads in a row to call it a pass.
            CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char.   Decrements in the 1mS ISR
        }
    break;
                
    case 4:                                           // wait for the TR-65
        if(!CalPacer)                                 // we waited long enough for the TR-65
        {
            Test0x18State = 5;                        // restart the three read binary search test at the next power level.
            NewTR65EPCAvailable = 0;                  // Reset the flag that says that we just got a TR-65 read so we can detect one next time
            TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
        }
    break;
           
    // restart the three read binary search test with this new power level.
    // Increase power with a fail, decrease power with a pass.
    // Switch to fine search mode when step size is <=10 (1dB)
       
    case 5:                                    // we increased or decreased RF power, triggerd and are waiting for the read to complete.
        if(GTestInProcessState == 2)           // TR-65 Timeout Status.    0 = IDLE, 1 = Test in progress, 2 = ReadTimeoutCounter hit 0 (Test Timeout).
        {
            PwrStepSize = PwrStepSize / 2;     // find the half step
            if(PwrStepSize < 10)               // Always increase at least
                PwrStepSize = 10;              // One full dB on a fail.
            PowerLevelNum += PwrStepSize;      // Since we did not get a good read then we increase power and then...
            Test0x18State = 2;                 // restart the three read binary search test at the new power level.
            //DebugOut( sprintf(Uart5TxBuf, "TO5  ") );
            
            if(PowerLevelNum > 500)                // We are at max power and still no good read
            {
                appCmd15Data.testfailcount++;      // Maintain Statistics
                TestModeState = TESTMODEIDLE;      // We're done. FAIL  Wait for the next trigger.                
                Send0xE4Data(0);                   // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.
                //DebugOut( sprintf(Uart5TxBuf, "Fail 5A %lu \n\r",PowerLevelNum) );
                return;
            }
        }
        
        if(GotTheStopInventoryMsg && NewTR65EPCAvailable)     // We just got a TR-65 EPC read.  This flag set in the TR-65 Serial ISR
        {                                                     // the TR-65 fails if it is triggered before getting the Stop Inventory message after a read.
            GotTheStopInventoryMsg = 0;        // this flag is set in the TR-65 RX ISR
            NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
            GTestInProcessState = 0;           // Regardless of the compare, the test is complete.  Wait until the next new label is detected.             

            if( (NumReads == 1) || (NumReads == 2) )                          // if this is the second, or third read of the series.
            {
                //DebugOut( sprintf(Uart5TxBuf, "GR512 NR %d ",NumReads) );                
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)           // Save a copy of the first good read of the three read series.
                {
                    if( LastEPC[LoopCountr] != CurrentEPC[LoopCountr] )       // Compare the tag ID that was just received with the one from the first read
                    {                                                         // We got a mismatch
                        PwrStepSize = PwrStepSize / 2;                        // find the half step
                        //DebugOut( sprintf(Uart5TxBuf, "LMM512  ") ); 
                        PowerLevelNum += PwrStepSize;                         // Increase power.
                        if(PowerLevelNum > 500)                // We are at max power and still no good read
                        {
                            appCmd15Data.testfailcount++;      // Maintain Statistics
                            TestModeState = TESTMODEIDLE;      // We're done. FAIL  Wait for the next trigger.
                            Send0xE4Data(0);                   // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.
                            //DebugOut( sprintf(Uart5TxBuf, "Fail 5B %lu \n\r",PowerLevelNum) );
                            return;
                        }
                        Test0x18State = 11;    // Wait for CALPACER to expire, then trigger a read, then return here.
                        return;                // exit this case 
                    }    
                }
                                               // If we get here then we got a match.
                NumReads++;                    // Counts up so we know when we tested three reads.
                CalPacer = 10;                 // a hundreth second delay
                Test0x18State = 4;             // Delay, then trigger a new TR-65 Read, then return here. 
            }
            
            if(NumReads == 3)                      // If this is 3 then it means that we got 3 good reads at this power level.
            { 
                //DebugOut( sprintf(Uart5TxBuf, "GR53  ") ); 
                PwrStepSize = PwrStepSize / 2;     // find the half step
                if(PwrStepSize < 11)               // Switch to fine seek mode when the step size gets small.
                {
                    PowerLevelNum -= 15;           // decrease RF power 1.5dB and go to fine search mode.
                    Test0x18State = 6;             // do the first fine search mode test, then we jump to that RF power.                
                }
                else
                {    
                    PowerLevelNum -= PwrStepSize;  // Since we got a good read then we Decrease power and then...
                    Test0x18State = 2;             // restart the three read binary search test at the new power level.
                }
            }            
            
            if(NumReads == 0)                      // if this is the first read of the series.  Just getting a read is enough to call it good.
            {
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)     // Save a copy of the first good read of the three read series.
                    LastEPC[LoopCountr] = CurrentEPC[LoopCountr];       // Holds the tag ID that was just received from a TR-65 Read EPC.
                NumReads++;                    // We got the first of three reads.
                //DebugOut( sprintf(Uart5TxBuf, "GR50  ") );
                CalPacer = 100;                // a tenth second delay
                Test0x18State = 11;            // Wait for CALPACER to expire, then trigger a read, then return here. 
            }
        }      
    break;
    
    case 6:                                           // fine step search  **************************************************************************************        
        GetCalRecordFromFlash( FlashAddress + (PowerLevelNum * 16) );    // Get the offset to the beginning of the current power level then get a CAL record from Flash.  It updates Global Variables.
        appCmd18Data.CurrentPowerLevel = PowerLevelNum +750;             // Keep a current copy to send back to host.
        SetStepAttenuator(ACalRecord_SA);             // Send SPI message to Step Attenuator   
        sprintf(Uart3TxBuf,"AA%ul\r\n",ACalRecord_AA);
        ReverseString(Uart3TxBuf);                    // Reverse the string in place.            
        Uart3TXpointer = strlen(Uart3TxBuf);          // As soon as this is non-zero, then the SERIALOUT function will start squirting the chars out
        RfidTimeOut = 2000;                           // Send and then let TR-65 process and get ready for the next message.  1 = 1mS, 10 = 10mS, 100 = tenth second. 1000 = one second
        RfidReady = 0;                                // this gets set to 1 when the '>' is received from the TR-65
        Test0x18State = 7;                            // Next we wait for the Thinkify to set the RF attenuator
    break;

    case 7:                                           // Wait until we get a ">" from the TR-65 or until enough seconds have passed to get the job done.
        if(!RfidTimeOut)                              // we timed out.
            Test0x18State = 6;                        // Send the previous command again.   

        if(RfidReady)                                 // We received the '>' from the TR-65    
        {
            Test0x18State = 8;                        // restart the three read binary search test at the next power level.
            CalPacer = 10;                            // Give the TR-65 an extra few mS to process after it sends us the '>' char.   Decrements in the 1mS ISR
            NumReads = 0;                             // We need three good reads in a row to call it a pass.
        }
    break;
                
    case 8:                                           // wait for the TR-65
        if(!CalPacer)                                 // we waited long enough for the TR-65
        {
            Test0x18State = 9;                        // restart the three read binary search test at the next power level.
            NewTR65EPCAvailable = 0;                  // Reset the flag that says that we just got a TR-65 read so we can detect one next time

            TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
        }
    break;

    case 9:                                    // We increased or decreased RF power, triggered and are waiting for the read to complete.
        if(GTestInProcessState == 2)           // TR-65 Timeout Status.    0 = IDLE, 1 = Test in progress, 2 = ReadTimeoutCounter hit 0 (Test Timeout).
        {
            PowerLevelNum += 1;                // Since we did not get a good read then we increase power by a tenth dB and then...
            //DebugOut( sprintf(Uart5TxBuf, "TO9  ") );            
            if(PowerLevelNum > 500)            // We are at max power and still no good read
            {
                appCmd15Data.testfailcount++;      // Maintain Statistics
                TestModeState = TESTMODEIDLE;      // We're done. FAIL  Wait for the next trigger.
                Send0xE4Data(0);                   // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.
                //DebugOut( sprintf(Uart5TxBuf, "Fail 9A %lu\n\r",PowerLevelNum) );
                return;
            }
            
            Test0x18State = 6;                 // restart the three read binary search test at the new power level.
        }
        
        if(GotTheStopInventoryMsg && NewTR65EPCAvailable)     // We just got a TR-65 EPC read.  This flag set in the TR-65 Serial ISR
        {                                                     // the TR-65 fails if it is triggered before getting the Stop Inventory message after a read.
            GotTheStopInventoryMsg = 0;        // this flag is set in the TR-65 RX ISR
            NewTR65EPCAvailable = 0;           // Reset the flag that says that we just got a TR-65 read so we can detect one next time
            GTestInProcessState = 0;           // Regardless of the compare, the test is complete.  Wait until the next new label is detected.                            

            if( (NumReads == 1) || (NumReads == 2) )                          // if this is the second, or third read of the series.
            {
                //DebugOut( sprintf(Uart5TxBuf, "GR912  ") );
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)           // Save a copy of the first good read of the three read series.
                {
                    if( LastEPC[LoopCountr] != CurrentEPC[LoopCountr] )       // Compare the tag ID that was just received with the one from the first read
                    {                                                         // We got a mismatch
                        PowerLevelNum += 1;                                   // Increase power by a tenth dB.
                        
                        if(PowerLevelNum > 500)                // We are at max power and still no good read
                        {
                            appCmd15Data.testfailcount++;      // Maintain Statistics
                            //TestModeState = TESTMODEIDLE;      // We're done. FAIL  Wait for the next trigger.
                            Send0xE4Data(0);                   // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.                            
                            TestModeState = INITTEST0X10;      // Return to the init where the attenuators are set when complete
                            InitTest0x10State = 5;             // where the attenuators are set when complete
                            JustDidSensitivityTest = 1;        // Skip the wait for new label test when reentering test 0x10 after setting the attenuators.
                            Active0x10Tests &= 0xFB;           // Indicate that Sensitivity test is complete.                            
                            MainTestStatus |= 0x04;            // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
                            //DebugOut( sprintf(Uart5TxBuf, "Fail 9B %lu\n\r",PowerLevelNum) );
                            return;
                        }

                        Test0x18State = 6;                                    // Set the next power level.
                        return;                                               // exit this case 
                    }    
                }
                                               // If we get here then we got a match.
                NumReads++;                    // Counts up so we know when we tested three reads.
                CalPacer = 10;                 // a hundreth second delay
                Test0x18State = 12;            // Wait for CALPACER to expire, then trigger a read, then return here. 
                CalPacer = 100;   // a tenth second delay
            }
            
            if(NumReads == 3)                      // If this is 3 then it means that we got 3 good reads at this power level.
            { 
                Send0xE4Data(1);                   // unsolicited response sent at the completion of a 0x18 Sensivity test command.   Send a 1 for Pass, 0 for FAIL.
                TestModeState = TESTMODEIDLE;      // We're done.   Wait for the next trigger.
                appCmd15Data.testpasscount++;      // Maintain Statistics
                
                TestModeState = INITTEST0X10;      // Return to the init where the attenuators are set when complete
                InitTest0x10State = 5;             // where the attenuators are set when complete
                JustDidSensitivityTest = 1;        // Skip the wait for new label test when reentering test 0x10 after setting the attenuators.
                Active0x10Tests &= 0xFB;           // Indicate that Sensitivity test is complete.
                //DebugOut( sprintf(Uart5TxBuf, "Pass %lu  \n\r",PowerLevelNum) );
            }            
            
            if(NumReads == 0)                      // if this is the first read of the series.  Just getting a read is enough to call it good.
            {
                for (LoopCountr = 0; LoopCountr < 12; LoopCountr++)     // Save a copy of the first good read of the three read series.
                    LastEPC[LoopCountr] = CurrentEPC[LoopCountr];       // Holds the tag ID that was just received from a TR-65 Read EPC.
                CalPacer = 10;                 // a hundreth second delay
                Test0x18State = 12;            // Delay, then trigger a new TR-65 Read, then return here. 
                NumReads++;                    // We got the first of three reads.
                //DebugOut( sprintf(Uart5TxBuf, "GR90  ") );
                CalPacer = 100;   // a tenth second delay
            }
        }      
    break;
    
    case 10:                                      // Delay between TR-65 Triggers
    if(!CalPacer)                                 // we waited long enough for the TR-65
    {
        Test0x18State = 1;                        // restart the three read binary search test at the next power level.
        TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
    }
    break;

    case 11:                                      // Delay between TR-65 Triggers
    if(!CalPacer)                                 // we waited long enough for the TR-65
    {
        Test0x18State = 5;                        // restart the three read binary search test at the next power level.
        TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
    }
    break;
    
    case 12:                                      // Delay between TR-65 Triggers
    if(!CalPacer)                                 // we waited long enough for the TR-65
    {
        Test0x18State = 9;                        // restart the three read binary search test at the next power level.
        TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
    }
    break;
    
    case 13:                                      // Delay between TR-65 Triggers
    if(!CalPacer)                                 // we waited long enough for the TR-65
    {
        Test0x18State = 1;                        // restart the three read binary search test at the next power level.
        TriggerOne0x18Read();                     // We need one read for the 0x18 test.   Init stuff and raise the hardware trigger pin.  Sets the timeout counters value.
    }
    break;
    
    } // Switch
}


void EncoderJustMovedForward(void)    // Do everything that has to happen when the encoder reports a foreard movement.
{
 
    if(DeafEncoderTicCounter)         // Global uint8_t    The number of deaf Encoder tics that need to be expended before we can accept another trigger.
        DeafEncoderTicCounter--;      // Decrement every time we get a forward encoder TIC

    if(Enable0xE6Mode == 2)           // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.
        Send0xE6PacketHS();           // Send the message to the host.
    
    if(MarkOffsetETics)               // If we are delaying the peripheral using Encoder Tics
    {
        MarkOffsetETics--;            // Decrement each time we get a forward Encoder TIC   
        if(!MarkOffsetETics)          // If we just decremented from 1 to 0
        {
            MarkActiveTimer = appCmd11Data.duration;          // The number of mS that the Mark peripheral is to be energized from command 0x11
            Mark(1);                                          // enable the peripheral
        }
    }
 
    
    if(PunchOffsetETicsA)              // If we are delaying the peripheral using Encoder Tics,   Two counters can support consecutive failed labels.
    {
        PunchOffsetETicsA--;           // Decrement each time we get a forward Encoder TIC   
        if(!PunchOffsetETicsA)         // If we just decremented from 1 to 0
        {
            //DebugOut( sprintf(Uart5TxBuf, " A BANG!\n\r"));
            PunchActiveTimer = appCmd20Data.duration;            // The number of mS that the Punch peripheral is to be energized from command 0x20
            Punch(1);                                            // enable the peripheral
        }
    }
    
    if(PunchOffsetETicsB)              // If we are delaying the peripheral using Encoder Tics.   Two counters can support consecutive failed labels.
    {
        PunchOffsetETicsB--;           // Decrement each time we get a forward Encoder TIC   
        if(!PunchOffsetETicsB)         // If we just decremented from 1 to 0
        {
            //DebugOut( sprintf(Uart5TxBuf, " B BANG!\n\r"));
            PunchActiveTimer = appCmd20Data.duration;            // The number of mS that the Punch peripheral is to be energized from command 0x20
            Punch(1);                                            // enable the peripheral
        }
    }
    
    if(appCmd12Data.Enable == 1)             // If a test is triggered with a new label detect.
    {
        if(TestEncoderCountdownLaunch)
        {
            TestEncoderCountdownLaunch--;           // If the counter had some counts, then decrement.
            if(TestEncoderCountdownLaunch==0)       // If we just decremented from 1 to 0 then it's time to launch a test.
                TriggertheTest();                   // We detected the label, waited the delay.  Now start the ReadTimout Timers and trigger the TR-65 
        }
    }
}


void JustGotNewLabelTrigger(void)                   // fiber optic detector or Camera just detected a new label.
{

    SetFrontPanelLEDs(6, 2);      // Barry add
    
    if(DeafEncoderTicCounter)     // Global uint8_t    The number of deaf Encoder tics that need to be expended before we can accept another trigger.
    {
        return;                   // If we are in the DEAF time then we are done here. 
    } 

    if( ! ((TestModeState == RUNTEST0X10) || (TestModeState == WAITFOR0X10TRIG)) )        // if we are not waiting for the first trigger or currently running a test
    {
        return;
    }

    appCmd15Data.triggercount++;                       // Statistics.  We got a legal trigger, so Increment the label counter
    
    DeafEncoderTicCounter = appCmd12Data.deaftics;     // Reset the encoder tic Ignore counter.    
    
    MainTestStatus = 0;                                // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail

    MaintainMarkPunchArray();                          // Checks to see if it's time to mark or punch.  It initiates a delayed mark or punch if needed.
    
    NewTR65TIDAvailable = 0;
    NewTR65EPCAvailable = 0;
    
    if( TestModeState == WAITFOR0X10TRIG )             // If we were waiting for the next label when running test 0x10
    {                                                  // 0 = INITTEST0X10, 1 = RUNTEST0X10, 0x0A = TESTMODEIDLE, 0x0c = WAITFOR0X10TRIG
        
        //TestModeState = RUNTEST0X10;                 // If we are now running test 0x10.   Booger found in Ver 2.11
        
        ControlTP(81,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
        ControlTP(81,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High

        if(GTestInProcessState == 1)                       // If a test is already in process and we just got a new label trigger.
            Send0XE5EventNoticeToHost(0x05);               // Send USB Event Notice to HOST.   0x05.  Overflow:  New label detected while still processing the previous label.
        
        switch(appCmd12Data.triggeroffset)                 // 0 None, 1 time (mS) delay, 2 Encoder Delay (from 0x1D).
        {
            case 0:
                Active0x10Tests = appCmd10Data.testtype;        // The bits are reset as tests complete.  When 00 then all the tests are done.
                TriggertheTest();                               // We detected the label, there are no mS delays or Tic Offsets
            break;                                              // Just start the ReadTimout Timers and trigger the TR-65                                                              

            case 1:                                             // Add a Timed delay (in mS)
                //ControlTP(18,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                Banner1Count++;                                 // This is the number of labels that have been detected since recipt of new 0x10 command.
                GTestInProcessState = 1;                        // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout. 
                Active0x10Tests = appCmd10Data.testtype;        // intitalized each time a new label is detected.  the bits are reset as tests complete.  When 00 then all the tests are done.
                TriggerDelayTimer = appCmd12Data.testoffset;    // The number of mS that need to be expended before we trigger a test. The actual trigger happens in the ISR
                if(!TriggerDelayTimer)                          // If Trigger delay is zero
                    TriggertheTest();                           // We detected the label, there are no mS delays or Tic Offsets, so trigger the test.
            break;

            case 2:                                                          // Add a Encoder TIC delay.
                //ControlTP(18,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
                Banner1Count++;                                              // This is the number of labels that have been detected since recipt of new 0x10 command.
                GTestInProcessState = 1;                                     // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout. 
                Active0x10Tests = appCmd10Data.testtype;                     // intitalized each time a new label is detected.  the bits are reset as tests complete.  When 00 then all the tests are done.
                TestEncoderCountdownLaunch = appCmd1dData.EncoderTicoffset;  // The number of Encoder tics that need to be expended before we trigger a test. The actual trigger happens in the ISR
                //DebugOut( sprintf(Uart5TxBuf,"C2 %x %x ",Active0x10Tests,TestEncoderCountdownLaunch) );

                if(!TestEncoderCountdownLaunch)                              // If the controller is set to delay with encoder tics and that specified delay is set to zero tics, then 
                    TriggertheTest();                                        // go ahead and trigger. 

            break;

            default:                                            // If it's something else, then send a warning to the host and trigger the test.
                SendFaultNoticeToHost(0x50);                    // Build a USB message to notify the HOST that a fault Occurred.   Pass in the Fault ID
                Active0x10Tests = appCmd10Data.testtype;        // The bits are reset as tests complete.  When 00 then all the tests are done.
                TriggertheTest();                               // We detected the label, there are no mS delays or Tic Offsets
            break;                                              // Just start the ReadTimout Timers and trigger the TR-65                                                              
        }        
        //ControlTP(18,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    }  
}


void TriggertheTest(void)                   // We detected the label, waited the delay.  Now start the ReadTimout Timers and trigger the TR-65
{
    //ControlTP(13,1);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    Active0x10Tests = appCmd10Data.testtype;   // intitalized each time a new label is detected.  the bits are reset as tests complete.  When 00 then all the tests are done.
    TR65Timeout = appCmd10Data.readtimeout;    // Global uint16_t   Decremented in the 1mS timer.  If this counts down to zero then it means that the TR-65 was late reading the tag.
    GTestInProcessState = 1;                // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout.  
    TestModeState = RUNTEST0X10;            // The inits are done.  Now do the test.
    MainTestStatus = 0;                     // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
    NewTR65EPCAvailable = 0;                // Reset the flag that says that we just got a TR-65 EPC read 
    NewTR65TIDAvailable = 0;                // Reset the flag that says that we just got a TR-65 TID read 
    TR65EPCReadFail = 0;                    // Set if a read error is detected in the EPC section
    TR65TidReadFail = 0;                    // Set if a read error is detected in the TID Section.
    TimeToBreak = 0;                        // Debug only
    FlushLabelData();                       // zero out whatever label data might be in buffers from previous reads.
    Uart3RXpointer = 0;                     // Zero out the Receive pointer since we processed the string 

    if(PlayPause)
    {
        TR65TriggerLen = 9;                 // Hardware trigger pulse is reset upon zero as it decrements to zero in the 1mS ISR.
        //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, HIGH);    // Set TR-65s GPI pin to trigger a read.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, RFID_GPI_0, HIGH);    // Set TR-65s GPI pin to trigger a read.
        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH);           // Enable the AUX output on J3 pins 1&2

        SetFrontPanelLEDs(3, 2);                   // Pulse the TR-65 Trigger LED
        //sprintf(Uart3TxBuf,"T11\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);      // Send a trigger to the TR-65
        //TR65Timeout = appCmd10Data.readtimeout;    // Global uint16_t   Decremented in the 1mS timer.  If this counts down to zero then it means that the TR-65 was late reading the tag.
    }   
    
    //ControlTP(13,0);        // Which; 10 12 13 16 17 24 30 31 32 33 40 45 46 47 48 52 - 65 72 73 79 81 82 84 86   OP; 0 = Low, 1 = Hi, 2 = Toggle 3 = All Low.  4 = All High
    return;  
}


void TriggerOne0x18Read(void)               // We need one read for the 0x18 test.
{
    DebugOut( sprintf(Uart5TxBuf, "\nTR \n") );// AG
    GTestInProcessState = 1;                // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout.  
    NewTR65EPCAvailable = 0;                // Reset the flag that says that we just got a TR-65 EPC read 
    TR65EPCReadFail = 0;                    // Set if a read error is detected in the EPC section
    FlushLabelData();                       // zero out whatever label data might be in buffers from previous reads.
    //DebugOut( sprintf(Uart5TxBuf, "\n\r Trig %lu ",PowerLevelNum) );
    TR65TriggerLen = 8;                     // Hardware trigger pulse is reset upon zero as it decrements to zero in the 1mS ISR.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_A, RFID_GPI_1, HIGH);    // Set TR-65s GPI pin to trigger a read.
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, AUX, HIGH);           // Enable the AUX output on J3 pins 1&2
    //SetFrontPanelLEDs(3, 2);                // Pulse the TR-65 Trigger LED
    TR65Timeout = appCmd18Data.Timeout;     // Global uint16_t   Decremented in the 1mS timer.  If this counts down to zero then it means that the TR-65 was late reading the tag.    
    return;  
}

void InitTR65Nudge(void)                   // Sends all the commands needed to get the TR-65 initalized after a power up reset.  All LEDs will be on while in progress.
{
    switch(TR65InitStateMachine)           // Keeps up with where the state machine is.)
    {
        case 0:                            // IDLE   We should never be here.
            DebugOut( sprintf(Uart5TxBuf, "Bad news:  TR65InitStateMachine is in state 0 \n\r") );
        break;                             // This function doesn't get called unless state is something other than 0.
        
        case 1:                            // Set to Tari Data rate     TARI=25.0   M=M8    LF=250
            TestingLEDs = 45;              // Set when front panel LEDs are being manually controlled.   This prevents the power LED from staying on all the time.
            All_LEDS_ON();                 // Turn all LEDs on to indicate that Initialization is in process.
            //sprintf(Uart3TxBuf,"P232\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf); 
            sprintf(Uart3TxBuf,"P033\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf); 
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;
 
        case 2:                            // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;

        case 3:                            // Set TR-65 to RF ON (CW) mode
            sprintf(Uart3TxBuf,"RO3\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 4:                            // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;

        case 5:                            // Set TR-65 Receive gain to +9dB.
            sprintf(Uart3TxBuf,"AG6\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 6:                            // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 7:                            // Set TR-65 Low Pass Filter to 6
            sprintf(Uart3TxBuf,"FL6\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 8:                            // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
 
        case 9:                            // Set TR-65 High Pass Filter to 6.
            sprintf(Uart3TxBuf,"FH6\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 10:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 11:                           // Set TR-65 Bandpass filter disabled.
            sprintf(Uart3TxBuf,"FB0\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 12:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 13:                           // Set TR-65 GGTL.
            //sprintf(Uart3TxBuf,"GGTL0\r\n"); 
            sprintf(Uart3TxBuf,"SM1\r\n"); // Change for ThinkiFy FW ver 4.7.1
            ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 14:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 15:                           // Set TR-65 GG to 1.
            sprintf(Uart3TxBuf,"GG01\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 16:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 17:                           // Set TR-65
            sprintf(Uart3TxBuf,"RT004\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;                

        case 18:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;

        case 19:                           // Set TR-65
            sprintf(Uart3TxBuf,"RT100\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break;       
        /*Added As per Curt's*/
        
        case 20:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 21:                           // Set TR-65
            sprintf(Uart3TxBuf,"IQ0\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break; 
        
        case 22:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;

        case 23:                           // Set TR-65
            sprintf(Uart3TxBuf,"II1\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break; 
        
        case 24:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 25:                           // Set TR-65
            sprintf(Uart3TxBuf,"IW1\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break; 
        
        case 26:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.               
            if(RfidReady)                  // We received the '>' from the TR-65    
                TR65InitStateMachine++;    // go to the next step.
        break;
        
        case 27:                           // Set TR-65
            sprintf(Uart3TxBuf,"MR\r\n"); ReverseString(Uart3TxBuf); Uart3TXpointer = strlen(Uart3TxBuf);
            RfidTimeOut = 1500;             // Decremented in the 1mS ISR.
            RfidReady = 0;                 // this gets set to 1 when the '>' is received from the TR-65
            TR65InitStateMachine++;        // go to the next state.
        break; 
        
        /*End Addition*/
        
        case 28:                           // Wait until we get a ">" or until enough seconds have passed to get the job done.
            if(!RfidTimeOut)               // we timed out.
                TR65InitStateMachine--;    // Send the previous command again.       
            
            if(RfidReady)                  // We received the '>' from the TR-65    
            {
                TR65InitStateMachine = 0;  // go to the IDLE step. ******************************************************************************************
                TestingLEDs = 2;           // Set when front panel LEDs are being tested.   This prevents the power LED from staying on all the time.
                All_LEDS_OFF();            // Turn all LEDs on to indicate that Initialization is in process.
            }
        break;
    }
}

// End of File*******************************************************************************


