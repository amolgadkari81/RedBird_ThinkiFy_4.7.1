//*******************************************************************************
//  MPLAB Source File
//
//  Company:
//    Grinder Switch Technologies.
//    
//  File Name:
//    Globals.h
//    Declarations for all the Global variables.
//
//  Last Edit Date:  Oct   3 2016   JRL    Clean up after calibration debug.
//  Last Edit Date:  Sept 10 2016   JRL 
//*******************************************************************************

#ifndef _GLOBALS_H    /* Guard against multiple inclusion */
#define _GLOBALS_H

uint8_t VersionMajor;
uint8_t VersionMinor;
uint8_t VersionYear;
uint8_t VersionMonth;
uint8_t VersionDay;

//Global variables

uint8_t  LED1Timer;            // 8 bit timer.  Decremented in the tenth second maintenance main loop.   When it changes from 1 to 0 then the LED is commanded off.
uint8_t  LED2Timer;            // 
uint8_t  LED3Timer;            // 
uint8_t  LED4Timer;            // 
uint8_t  LED5Timer;            // 
uint8_t  LED6Timer;            // 
uint8_t  LED7Timer;            // 
uint8_t  LED8Timer;            // 
uint8_t  LEDCopy;              // Holds the commanded LED state.

uint8_t  DumpArray;            // used in CAL routine to dump a high speed capture.
uint16_t LPRDumpArray[10];     // used in CAL routine to dump a high speed capture.
uint8_t  NumSamples;           // used in CAL routine to dump a high speed capture.

uint16_t AnalogAttStart;       // the D/A setting that selects the voltage at which the Analog Attenuator starts to respond.  Lower the voltage the highest output signal level.  Typically .7 Volts
uint16_t AnalogAttEnd;         // the D/A setting that selects the voltage at which the Analog Attenuator stops responding.   Lower the voltage the highest output signal level.  Typically 1.7 Volts

uint8_t  PendingHostEventNotice;     // This holds an event notice that needs to be sent after the USB message that is currently being assembled is sent.

uint16_t FramAddress;     // Debug------------  Temp use only   These could be local variables.
uint8_t  FramData;        // Debug------------  Temp use only
uint32_t BuildWhole;      // Debug----------    Temp use only
uint32_t BuildPart;       // Debug-----------   Temp use only
uint16_t LoopCountr;      // Debug-----------   Temp use only   Moved from Calibrate.c  Which power level we are currently searching for.
bool     TimeToBreak;
uint8_t  NumReads;                  // For Sensitivity Test.   We need three good reads in a row for a good read.
uint32_t Cmd0x52TestCount;
uint8_t  SATable[510];              // Step   Attenuator Table for the current frequency
uint16_t AATable[510];              // Analog Attenuator Table for the current frequency
uint8_t  TR65TriggerLen;            // Timer used to fire and forget the TR-65 harware trigger pulse.
uint8_t  Counter1mS;                // Decremented in the Timer3 ISR.  Used to ensure delays between events.
uint16_t PMPacer;                   // Decremented in the Timer3 ISR.  Used to ensure delays between power meter events.
uint8_t  PMCounter;                 // Decremented in the Timer3 ISR.  Used to ensure delays between Power Meter Reads.
uint8_t  PMRunStop;                 // Power Meter RunStop button status.
uint8_t  OldPMRunStop;

uint8_t  MemoryUnlock;              // Initialized to 0 upon power on reset.  gets set upon button 1 when dip switch is set correctly.   If set, then the flash can be erased and written.
uint8_t  SelfTestEnables;           // Bit enables for PCB self test stuff.  set/reset with serial port commands.  Tests are in the Fast and Slow test functions.
uint8_t  Button1State;              // Buttons on Main Board  0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.
uint8_t  Button2State;              // Buttons on Main Board  0 = Released, 1 = Just PRessed, 2 = Pressed, 3 = Just Released.

uint8_t  Enable0xE6Mode;            // 0 = unsolicited 0xE6 messages are disabled.   1 = 0xE6 is sent each 1mS, 2 0xE6 is sent upon each foreward encoder tic.

uint8_t  status;                    // Used in USB Messages to return info about if the command was perfectly received, or what was wrong with it.
uint8_t  lastfault;
uint8_t  lastcommand;
uint8_t  RFChannel;
uint8_t  StrapTestMode;

uint8_t  MainTestStatus;            // BitField:  (80RFU  40RdrFailTimeout 20RFU 10IdFilter 08TidTestFail 04SensitivityFail 02WriteFail 01ReadFail
uint8_t  Active0x10Tests;           // intitalized with appCmd10Data.testtype each time a new label is detected.  the bits are reset as tests complete.  When 00 then all the tests are done.

//High speed timer variables
uint16_t HSReaderTMTimer, HSGPIOTMTimer;
uint8_t  HSPacketEnable;                      // 0 = Disable, 1 = Enable.  Send 0xE6 at rate specified in 0x95 when enabled.
uint16_t HSReaderCounter, HSGPIOCounter;
uint32_t Banner1Count;                        // TODO should this be replaced with appCmd15Data.triggercount ?

uint8_t AverageTemperature;               // Maintained with the Get_Temp() Function.   uint8 in degrees C.  0 means the temp is less than 0.  126 means that it's above the TC77 upper limit.
uint8_t MacArray[8];                      // Mac is stored MSB first
uint8_t CurrentTemperatureNum;            // Calculated each second,   Holds which temperature range is used.  0 = < 25.0.  1 = 25.0 to 29.9.  2 = 30.0 to 35.0.  3 = > 35.0
uint8_t CurrentCalTemperatureSet;         // Set at the start of CAL.  Holds which temperature range is being calibrated.  0 = < 25.0.  1 = 25.0 to 29.9.  2 = 30.0 to 35.0.  3 = > 35.0

uint32_t appCmd0BReqFreq;                 // Holds the frequency passed in with command 0x0B
uint16_t appCmd0BPower;                   // Holds the Power level passed in with command 0x0B

uint8_t  BitfieldInversions;              // Bit 0  Mark, Bit 1 Punch, Bit 2, Bit 3, Bit 4,  Bit 5, Bit 6,  Bit 7.   
                                          // 0 = Output high impedance when resting and asserted to trigger.  1 = Asserted when resting and High impedance to trigger.

uint8_t  PlayPause;                       // 0 = pause.  1 = Play
//uint8_t atemp;
//uint16_t adelay;

#define MAXSERBUF 250                      // Max length of all of the serial buffers
//char  Uart1RxBuf[MAXSERBUF+1];           // Holds received characters from JADAK
//char  Uart2RxBuf[MAXSERBUF+1];           // Holds received characters from WiFi
char  Uart3RxBuf[MAXSERBUF+1];             // Holds received characters from RFID
char  Uart4RxBuf[MAXSERBUF+1];             // Holds received characters from Camera
char  Uart5RxBuf[MAXSERBUF+1];             // Holds received characters from Debug Port SP5 (J14))
//char  Uart1TxBuf[MAXSERBUF+1];           // Holds characters to send to JADAK
//char  Uart2TxBuf[MAXSERBUF+1];           // Holds characters to send to WiFi
char  Uart3TxBuf[MAXSERBUF+1];             // Holds characters to send to RFID
char  Uart4TxBuf[MAXSERBUF+1];             // Holds characters to send to Camera
char  Uart5TxBuf[MAXSERBUF+1];             // Holds characters to send to  Debug Port SP5 (J14))
char  Uart5CircBuf[MAXSERBUF+1];           // Circular buffer for Debug Port SP5
//bool  Uart1CRGot;                        // True if we just received a CR on the Specified UART
//bool  Uart2CRGot;                        // True if we just received a CR on the Specified UART
bool  Uart3CRGot;                          // True if we just received a CR on the Specified UART
bool  Uart4CRGot;                          // True if we just received a CR on the Specified UART
bool  Uart5CRGot;                          // True if we just received a CR on the Specified UART
//uint8_t  Uart1RXpointer;                 // Points to the next character location available to hold a new received character
//uint8_t  Uart2RXpointer;                 // Points to the next character location available to hold a new received character
uint8_t  Uart3RXpointer;                   // Points to the next character location available to hold a new received character
uint8_t  Uart4RXpointer;                   // Points to the next character location available to hold a new received character
uint8_t  Uart5RXpointer;                   // Points to the next character location available to hold a new received character
//uint8_t  Uart1TXpointer;                 // Points to the next character to transmit
//uint8_t  Uart2TXpointer;                 // Points to the next character to transmit
uint8_t  Uart3TXpointer;                   // Points to the next character to transmit
uint8_t  Uart4TXpointer;                   // Points to the next character to transmit
uint8_t  Uart5TXpointer;                   // Points to the next character to transmit
uint8_t  Uart5Headpointer;                 // Points to the next character location available to hold an incoming character
uint8_t  Uart5Tailpointer;                 // Points to the next character that gets sent.

uint8_t  RfidReady;                        // Set to 1 when the > is received from the TR-65
uint8_t  RfidMode;                         // Used to select which set of TR-65 Strings to send to put it into the different modes of operation.
uint16_t RfidTimeOut;                      // permits up to 64 seconds of time for the TR-65 to respond to a command.
uint8_t  EncoderDeafTimeReload;            // Used to ignore pulses from the encoder if they come quicker than planned.  This is the value that is set by the PC 
uint8_t  EncoderADeafTime;                 // Used to ignore pulses from the encoder if they come quicker than planned.  This is the value that is decremented in the ISR
uint8_t  EncoderBDeafTime;                 // Used to ignore pulses from the encoder if they come quicker than planned.  This is the value that is decremented in the ISR

bool TesterEnable;                         // Command 0x14 enable
bool TriggerEnable;                        // Command 0x12 enable
bool TriggerEdge;                          // Command 0x12 trigger edge

uint16_t VelocityCentiInchPerSecond;       // uint16_t in Hundredths of an inch.  Calculated in the 1mS Timer ISR.  
float MicroSecPerEncTic;                   // How long between Encoder TICSs          
//float EncTicPerMicroSec;                 // The number of Tics per Microsecond          

uint32_t GlobalTimerTicksPerEncoderTick;   // Global uint32_t Gets refreshed each time the encoder moves.  Calculated from the Timer ticks and roll overs.
uint16_t EncoderTimerRollovers;            // Counts rollovers of the timer used to measure velocity.
uint32_t WebVelocityEncoderTicCorrection;  // The number of TICS that the punch should fire early due to the velocity of the web.  (32bit so that we can use integer math)

uint8_t  Cmd21_LabelPitchTics;             // The Nominal pitch of the labels in tics.( Num tics from the leading edge of one label to the leading edge of the next label)
uint8_t  Cmd21_NomLabelTics;               // The Nominal tics that are expected per Label (edge to edge of the label portion)
uint8_t  Cmd21_TicsPerInch;                // The exact number of tics that will be sent for each 1.000 inch of Web length

uint16_t LabelEncoderTics;                 // Counts number of encoder tics since last new label detection.

uint16_t HostTimer;                        // Increments in the 1mS ISR.  Sent to Host PC with every USB message.  Can be reset with command 0x02

bool MarkPunchActive;                      // The pass/fail indication will be stuffed into the MarkPunch array when set.  Typically reset (0) for Firmware triggered tests.


typedef struct
{
    uint8_t enable;      // 0 disable, 1 = Mark Bad with EncoderTic offset, 2 - Mark Bad with mS offset, 3 = Mark Good with EncoderTic Offset, 4 Mark Good with mS offset
    uint8_t position;  
    uint8_t duration;
    uint8_t offset;
    uint8_t OffsetSel;   // What causes the Punchoffset:  0 = 0x1D Punch offset Tics, 1 = 0x20 Punch offset mS    
} APP_MARKER;
APP_MARKER appCmd11Data;
APP_MARKER appCmd20Data;



uint8_t  TestModeState;                // Global uint8_t     Main Test Modes: States for the main test routine loop.  
#define INITTEST0X10       0           // 00 Requestable States for TestModeState: Init a new test 0x10
#define RUNTEST0X10        1           // 01 Requestable States for TestModeState: Running test 0x10
#define INIT0X18TEST       2           // 02 Requestable States for TestModeState: Init new static test
#define RUNSENSITIVITYTEST 3           // 03 Requestable States for TestModeState: running Static Test
#define INITDEBUGMODE0x6A  4           // 04 Requestable States for TestModeState: Init Debug Mode for command 0x6A
#define RUNDEBUGMODE0x6A   5           // 05 Requestable States for TestModeState: Running tasks of Debug Mode for command 0x6A
#define WAS_HS_GPIOMODE    6           // 06 Requestable States for TestModeState: Unused
#define WAS_HS_READERTEST  7           // 07 Requestable States for TestModeState: Unused
//#define INITLSRFIDCAL      8           // 08 Requestable States for TestModeState: Get ready to calibrate the LOW SIDE of the RFID Interface
#define RUNLSRFIDCAL       9           // 09 Requestable States for TestModeState: Perform the calibration for the LOW SIDE of the RFID Interface
#define TESTMODEIDLE       10          // 0A Requestable States for TestModeState: No user requested tests or user requested tasks running.   Immediate mode tasks from USB are permitted in this mode. 
#define RUNDEBUGMODE0x1E   11          // 0B Requestable States for TestModeState: Running tasks of Debug Mode for command 0x1E
#define WAITFOR0X10TRIG    12          // 0C Requestable States for TestModeState: We are waiting for the 0x10 test to be launched
#define PERFORMTEST0X0B    13          // 0D Requestable States for TestModeState: RF Test Mode:   Do test 0x0B
#define INITHSRFIDCAL      14          // 0E Requestable States for TestModeState: Get ready to calibrate the HIGH SIDE of the RFID Interface
#define RUNHSRFIDCAL       15          // 0F Requestable States for TestModeState: Perform the calibration for the High SIDE of the RFID Interface
#define VERIFYRFIDCAL      16          // 10 Requestable States for TestModeState: Perform the Calibration verification of RFID Interface at the current temperature.


uint8_t  Init0x0BState;                // Used to sequence messages to the TR-65 for command 0x0B
uint32_t Freq0x0B;                     // the requested frequency for command 0x0B
uint16_t PowerLevelNum;                // the number of power steps from the beginning of the table.
uint16_t CurrentFAD;                   // Forward AD converter Values (the 8 MSBs of the 12 Bit converter) for the current frequency
uint16_t CurrentRAD;                   // Reverse AD converter Values (the 8 MSBs of the 12 Bit converter) for the current frequency
uint8_t  PunchActiveTimer;             // Global uint8_t the number of milliseconds that the Punch peripheral will be energized.
uint8_t  MarkActiveTimer;              // Global uint8_t the number of milliseconds that the Mark  peripheral will be energized.
uint8_t  PunchOffsetTimer;             // Global uint8_t the number of milliseconds or Encoder TICS that the Punch peripheral will be delayed before being energised.
uint8_t  MarkOffsetTimer;              // Global uint8_t the number of milliseconds or Encoder TICS that the Mark peripheral will be delayed before being energised.
uint8_t  TriggerDelayTimer;            // Global uint8_t the number of milliseconds that a banner trigger will be delayed before launching a TR-65 Read.
uint8_t  EncoderStyle;                 // 0 = Disabled, 1 = Quadrature Encoder, 2 = Pulse Channel A, 3 = Enable Trigger, 4 = Reset Stats, 5 = Fail Test
uint8_t  EncoderEdgePolarity;          // 0 = Detect Falling Edge.   1 = Detect Rising edge.
uint16_t PunchOffsetETicsA;            // Global uint16_t the number of Encoder Tics that the Punch peripheral will be delayed before being energized.
uint16_t PunchOffsetETicsB;            // Two counters are used to support consecutive failed labels.
uint8_t  MarkOffsetETics;              // Global uint8_t the number of Encoder Tics that the Mark  peripheral will be delayed before being energized.
uint8_t  GTestInProcessState;          // Global uint8_t state of the test.  0 = IDLE, 1 = Test in progress, 2 = Test Timeout. 

uint8_t  InitTest0x10State;            // All the parts of getting test 0x10 setup.
uint8_t  Test0x18State;                // All the parts of getting test 0x18 setup and run.
uint8_t  Test0x6AState;                // All the parts of getting test 0x6A setup and executed.

uint8_t  InitTr65Once;                 // Set to 3 on powerup.  The main line code will perform the init of the TR-65 three seconds after the unit comes out of reset.
uint8_t  TR65InitStateMachine;         // Keeps up with where the state machine is.

bool     JustDidSensitivityTest;       // set in the Sensitivity test.  it lets us skip the wait for new label test when reentering test 0x10 after setting the attenuators.

uint32_t FlashAddress;                 // Calculated offset into the FLASH memory that points to the desired CAL record.
uint16_t CurrentPowerSought;           // Power Request in Tenth dB.   (Actual + 100) * 10.   -25.00dB = 7500

uint8_t  SaLowRange;                   // Step attenuator setting for the low power range
uint8_t  SaMidRange;                   // Step attenuator setting for the mid power range
uint8_t  SaHiRange;                    // Step attenuator setting for the high power range

typedef struct    //Holds command 0x15 data
{
    uint32_t testpasscount;    // Number of test passes.
    uint32_t testfailcount;    // Number of test failures.
    uint32_t triggercount;     // Number of test triggers.
    
} APP_SETTESTERSTATSTICS;
APP_SETTESTERSTATSTICS appCmd15Data;      //Holds application command 0x15 data.  This structure should be initialized by the APP_Initialize function.

uint8_t  OldTestModeState;               // Holds the mode that was active the last time thru the main test loop in Main.c
 
uint32_t Cmd1E_desiredNumPulses;         // Number of Marker Pulses to create for command 0x1E
uint16_t Cmd1E_desiredPulseDuration;     // Width and Spacing for the Marker Pulses created for command 0x1E
int16_t  Cmd1E_Timer;                    // Destructive counter used for Command 0x1E

typedef struct              //This structure holds the application's command 0x12 data. it should be initialized by the APP_Initialize function.
{
    uint8_t Enable;         // 0 = Disabled, 1 = Enabled.
    uint8_t edgetype;       // Denotes rising or falling edge trigger. (00 = Falling, 01 = Rising).
    uint8_t debounce;       // Debounce time in ms.
    uint8_t deaftics;       // Further to debounce, We wait at least this many Encoder TICS before accepting another New Label detector Trigger.
    uint8_t testoffset;     // Number of ms to wait from trigger being received until test starts (ms).
    uint8_t triggeroffset;  // What causes a delay between Banner and test.  0 None, 1 mS delay, 2 Encoder Delay.  Uses the Encoder TICS from 0x1D and mS offset from this command.
} APP_TRIGGERINPUTSETTINGS;
APP_TRIGGERINPUTSETTINGS appCmd12Data;    //This structure holds the application's command 0x12 data. it should be initialized by the APP_Initialize function.


typedef struct                    //  This structure Holds application command 0x1d data.  It should be initialized by the APP_Initialize function.
{
    uint16_t triggerfiltermin;
    uint16_t EncoderTicoffset;    
    uint16_t markeroffset;
    uint16_t punchoffset;    
    uint16_t punchflight;    
    uint16_t triggerfiltermax;
} APP_ENCODER;
APP_ENCODER appCmd1dData;              //  This structure Holds application command 0x1d data.  It should be initialized by the APP_Initialize function.


typedef struct
{
    uint8_t  ReadWrite;          // uint8    Requested by host PC
    uint8_t  AntPort;            // uint8    Requested by host PC
    uint32_t Freq;               // uint32   Requested by host PC
    uint16_t MinPower;           // uint16   Requested by host PC 
    uint16_t MaxPower;           // uint16   Requested by host PC 
    uint8_t  SearchDepth;        // uint8    Requested by host PC
    uint16_t Timeout;            // uint16   Requested by host PC
    uint16_t PassThreshold;      // uint16   Requested by host PC
    uint8_t  Options;            // uint8    Requested by host PC
    uint16_t CurrentPowerLevel;  // uint16   The current power level being tested.
} APP_CMD18;
APP_CMD18 appCmd18Data;

// Moved from CALIBRATE as suspect in a memory bounds error.  TODO Move them back.
uint8_t   CurrentRASetting;             // Which RA Power level is being used.
uint8_t   CurrentSASetting;             // Which SA Power level is being used.
uint16_t  CurrentAASetting;             // Which AA Power level is being used.
uint8_t   RunState;                     // Where we are in the process.
uint16_t  PwrError;
uint8_t   CalCounter;
uint8_t   TestingLEDs;                 // Set when front panel LEDs are being tested.   Num seconds to inhibit power LED This prevents the power LED from staying on all the time.  Cycle power to clear.

uint8_t  LastRequestedRA;              // if the currently needed RA is the same as this then we don't have to send it to the TR-65 again.
uint8_t  CurrentCALChannel;            // Which Frequency is being calibrated.   Actual Freq = 860 + (CurrentCALChannel*2) * 1000000
uint16_t LatestPwrReading;             // Power meter current value.  Continually refreshed by USB command 0x98 during calibration.  
                                       // Sent in hundreths with 100dB offset.  +12.55dB sent as 11255.   -12.22 dB sent as 8778.

uint32_t AveragePwrReading;            // Running average of Power meter current value.  Continually refreshed by USB command 0x98 during calibration.  

uint16_t FailTimeout;                  // used when waiting on a peripheral that might fail. prevents waiting forever.
uint8_t  CalMode;                      // Controls CAL progress.   0 = Idle CAL, 1 = Init Low Side, 2 =Run Low side, 3 = Init High Side, 4 =Run High side,  5 = Halt Cal process.
uint16_t CalPacer;                     // uint16_t Global Variable.  Decremented in the 1ms timer routine.  Used to create delays between events in Cal and Sensitivity test routines.
uint8_t  NewPowerMeterValueAvailable;  // Incremented when a new power meter value is available.
bool     NewTR65EPCAvailable;          // We just got a TR-65 EPC read.  This flag set in the TR-65 Serial ISR
bool     NewTR65TIDAvailable;          // We just got a TR-65 TID read.  This flag set in the TR-65 Serial ISR
bool     TR65EPCReadFail;              // Set if a read error is detected in the EPC section
bool     TR65TidReadFail;              // Set if a read error is detected in the TID Section.
bool     GotTheStopInventoryMsg;       // the TR-65 fails if it is triggered before getting the Stop Inventory message after a read.  this is set in the TR-65 RX ISR
uint8_t  CurrentEPC[16];               // Holds the tag ID that was just received from a TR-65 Read EPC.
uint8_t  CurrentTID[16];               // Holds the TID that was just received from a TR-65 Read TID.
uint8_t  appCmd10Data_startTagID[12];  // Holds the tag ID that was just received as part of command 0x10
uint32_t PwrLevelBeingSought;          // Which power level we are searching for.
uint16_t Temp16Variable;               // Debug use
uint8_t  LoopCounter;                  // Simple Loop Counter
uint8_t  TempCounter;                  // Simple Loop Counter

uint8_t  ACalRecord_RA;                // Global uint8_t    Holds the TR-65  Attenuator setting for the requested Freq and Power level
uint8_t  ACalRecord_SA;                // Global uint8_t    Holds the Step   Attenuator setting for the requested Freq and Power level
uint16_t ACalRecord_AA;                // Global uint16_t   Holds the Analog Attenuator setting for the requested Freq and Power level
uint16_t ACalRecord_FAD;               // Global uint16_t   Holds the Forward AD reading that was measured at CAL verify time for the current Freq and Power level
uint16_t ACalRecord_RAD;               // Global uint16_t   Holds the Reverse AD reading that was measured at CAL verify time for the current Freq and Power level
uint16_t ACalRecord_PwrError;          // Global uint16_t   Holds the power error in CentidB.  Supports -25 to +25dB.  Add 100dB and then multiply by 10. -12.3dB is sent as 877, +22.4dB sent as 1224.

uint8_t  DeafEncoderTicCounter;        // The number of deaf Encoder tics that need to be expended before we can accept another trigger.
uint16_t TestEncoderCountdownLaunch;   // The number of Encoder tics or mS that need to be expended before we trigger a test.  
 
uint16_t TR65Timeout;                  // Global uint16_t   Decremented in the 1mS timer.  If this counts down to zero then it means that the TR-65 was late reading the tag.
 
uint8_t  MarkArray[256];               // We keep an array of counters (one for each possible label between new label detector and the mark/punch unit.  They get set each time a mark or punch is needed.
uint8_t  PunchArray[256];              // We keep an array of counters (one for each possible label between new label detector and the mark/punch unit.  They get set each time a mark or punch is needed.
 
uint8_t  Cmd1A_Options;                // uint8_t     So far unused.
uint32_t Cmd1A_NibbleEnables;          // uint32_t    1 bit for each nibble of the TID filter.  1 = enabled.
uint8_t  Cmd1A_TagIdFilter[13];        // uint8_t[13] Tag ID that the filter must match.
bool     FilterTestFail;               // reset to 0 at the start of the filter test.   If any of the nibbles fail the match then set it to 1 to indicate the failure.

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */
#include "app.h"

#endif /* _EXAMPLE_FILE_NAME_H */

// End of File  *****************************************************************************
