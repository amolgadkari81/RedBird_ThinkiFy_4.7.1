Base is 3.01 for this - In 3.01 added EPC filter logic in FW

Changes

1. Added commands for ThinkiFy FW 4.4.3